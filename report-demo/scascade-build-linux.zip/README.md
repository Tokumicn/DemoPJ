# build-linux

基础组件打包部署

docker build -t skylar_postgresql -f docker_pg/Dockerfile .

docker build -t skylar_clickhouse -f docker_clickhouse/Dockerfile .

docker build -t skylar_kafka -f docker_kafka/Dockerfile .


docker load > skylar_kafka
docker load > skylar_clickhouse
docker load > skylar_postgresql
 
docker run -d --name=kafka --restart=always --net=host --privileged=true -v /data/docker/kafka_cluster/data:/data/kafka_cluster/data skylar_kafka
 
docker run -d --name=clickhouse --restart=always --net=host --privileged=true -v /data/docker/clickhouse:/var/lib/clickhouse skylar_clickhouse
 
docker run -d --name=pg --restart=always --net=host --privileged=true -v /data/docker/pg:/var/lib/postgresql/9.5/main skylar_postgresql


构建工程：
http://tq-jenkins.360es.cn:8080/job/scascade_docker_build