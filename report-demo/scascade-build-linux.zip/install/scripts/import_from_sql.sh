#!/bin/bash
set -e

pgdump_sql_dir="$PGDATA/pgdump_sql"

drop_db(){
	echo "----drop old databases----"
	dropdb -h 127.0.0.1 -p 5432 -U postgres scascade
}

create_db(){
	echo "----create databases again----"
	createdb -h 127.0.0.1 -p 5432 -U postgres scascade
}

import_sql(){
	echo "----start recover scascade----"
	psql -h 127.0.0.1 -p 5432 -U postgres scascade < $pgdump_sql_dir/scascade.sql
}

rm_sql(){
	echo "----delete backup sql----"
	rm -f "$pgdump_sql_dir"/*.sql
}


echo "----start recovering pg data----"
drop_db
create_db
import_sql
rm_sql
echo "----Done----"
