#!/bin/bash

#use a specific -v dir "/data/supervisord" on the host to get data_dir
set_data_dir()
{
    local container_name=$(docker ps -a | grep -w "postgresql\|kafka\|clickhouse"| sed -n 1p | awk '{print $NF}')
    if [ -n "$container_name" ];then
        local bind_dirs=$(docker inspect -f '{{.HostConfig.Binds}}' $container_name | sed 's/\[\|\]//g')
        data_dir=$(echo $bind_dirs | tr ' ' '\n' | grep /data/supervisord | awk -F /supervisord '{print $1}')
    fi
    [ ! -n "$data_dir" ] && data_dir="$setup_script_dir/data"
}

rm_containers()
{
    #grep skylar is not appropriate in case of an interrupted installation
    containers=$(docker ps -a|grep -w "\(postgresql\|kafka\|clickhouse\)\(_back\)\?"|awk '{print $1}')
    if [ -n "$containers" ];then
        echo "rm containers..."
        if [ $keep_skylar_data -eq 0 ];then
            docker rm -f -v $containers
        else
            docker rm -f $containers
        fi
    fi
}

rm_images()
{
    images=$(docker images|grep -w "skylar_\(postgresql\|kafka\|clickhouse\)\(_back\)\?"|awk '{print $3}')
    if [ -n "$images" ];then
        echo "rm images..."
        docker rmi -f $images
    fi

    none_images=$(docker images -f "dangling=true" -q)
    if [ -n "$none_images" ];then
        echo "rm <none> images..."
        docker rmi -f $none_images
    fi
}

rm_volumes()
{
    volumes=$(docker volume ls|grep local|awk '{print $2}')
    if [ -n "$volumes" -a $keep_skylar_data -eq 0 ];then
        echo "rm docker volumes in /var/lib/docker/volumes ... "
        docker volume rm $volumes
    fi
}

rm_skylar_data()
{
    if [ $keep_skylar_data -eq 0 ];then
        echo "rm skylar data in $data_dir ... "
        rm -rf $data_dir/supervisord \
        $data_dir/kafka_cluster \
        $data_dir/pg \
        $data_dir/clickhouse \
        $data_dir/log/skylar \

        echo "rm skylar network settings ..."
        rm -f $netscript_dir/envmgr.sh

        echo "rm backup setup scripts..."
        if [ "$data_dir" != "$setup_script_dir/data" ];then
            local setup_dir=$(dirname $data_dir)
            rm -rf $setup_dir/scripts
            rm -f $setup_dir/setup
            rm -f $setup_dir/uninst
        fi
    fi
}

rm_rc_records()
{
    echo "rm boot settings in /etc/rc.d/rc.local ..."
    sed -i '/sleep/d' /etc/rc.d/rc.local
    sed -i '/docker/d' /etc/rc.d/rc.local
    sed -i '/init_network.py/d' /etc/rc.d/rc.local
    sed -i '/envmgr.sh/d' /etc/rc.d/rc.local
}

#sync uninstall.log under $setup_script_dir with that under $data_dir
sync_uninstall_log()
{
    if [ "$data_dir" != "$setup_script_dir/data" ];then
        local tmp_log_file="$tmp_log_dir/uninstall.log"
        local real_log_file="$log_dir/uninstall.log"
        cat "$tmp_log_file" >> "$real_log_file"
        rm -f "$tmp_log_file"
    fi
}

echo "--------Start uninstalling--------" 
#init uninstall settings if not set
[ ! -n "$script_dir" ] && script_dir=$(cd `dirname $0`;pwd)
[ ! -n "$setup_script_dir" ] && setup_script_dir=$(dirname $script_dir)
[ ! -n "$netscript_dir" ] && netscript_dir="/etc/sysconfig/network-scripts"
[ ! -n "$data_dir" ] && set_data_dir

echo "uninstall setting:
keep_skylar_data : $keep_skylar_data
skylar_data_dir : $data_dir
log_dir : $data_dir/log/docker
"

rm_containers
rm_images
rm_volumes
rm_skylar_data
rm_rc_records

echo "--------Done--------" 
sync_uninstall_log
exit 0



