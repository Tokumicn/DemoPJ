#!/bin/bash

compare_version()
{
    if [[ -z "$1" || -z "$2" ]];then
        return 1
    fi
    #sort and print the lower version
    lower_version=$(echo -e "$1\n$2"|sed 's/\./-/g'|sort -t "-" -k 1n -k 2n -k 3n -k 4n|sed -n 1p|sed 's/-/\./g')
    if [ "$lower_version" == "$1" ];then
        return 1
    else
        return 0
    fi
}

check_console_ip(){
    consoleIp="/etc/console_ip"
    if [ ! -f "$consoleIp" ]; then
        echo "console_ip file does not exist！";
        exit
    else
        echo "console_ip is $(cat "$consoleIp")"; return 1
    fi
}

check_docker_version(){
    which docker >> /dev/null
    if [ $? -eq 0 ]; then
        echo "docker service already exist, check docker version..."
    else
        echo "docker service does not exist, try to install..."; return 1
    fi

    docker_version_base="1.8.2"
    docker_version_current=$(docker -v|awk '{print $3}'|awk -F , '{print $1}')
    #sort and print the lower version
    compare_version "$docker_version_base" "$docker_version_current"
    if [ $? -eq 1 ];then
        echo "docker version: $docker_version_current >= $docker_version_base, skip docker installation"; return 0
    else
        echo "docker version: $docker_version_current < $docker_version_base, please install docker manually!"; exit 5
    fi
}

install_docker(){
    dockerrpm4centos_7_0="DOCKER_RHEL_RPM/DOCKER_1_12_6_RHEL_7_0_CENTOS_7_0_1406"
    dockerrpm4centos_7_2="DOCKER_RHEL_RPM/DOCKER_1_12_6_RHEL_7_2_CENTOS_7_2_1511"
    dockerrpm4centos_7_3="DOCKER_RHEL_RPM/DOCKER_1_12_6_RHEL_7_3_CENTOS_7_3_1611"
    dockerrpm4centos_7_4="DOCKER_RHEL_RPM/DOCKER_1_12_6_RHEL_7_4_CENTOS_7_4"
    dockerrpm4centos_7_5="DOCKER_RHEL_RPM/DOCKER_1_12_6_RHEL_7_5_CENTOS_7_5"
    dockerrpm4centos_7_6="DOCKER_RHEL_RPM/DOCKER_1_12_6_RHEL_7_6_CENTOS_7_6"
    dockerrpm4centos_7_7="DOCKER_RHEL_RPM/DOCKER_1_12_6_RHEL_7_7_CENTOS_7_7"

    if [ -f /etc/redhat-release ];then
        chmod a+x /etc/redhat-release
    else
        echo "Linux version not supported! Only Support Redhat Linux."; exit 4
    fi

    for version in 7.0 7.2 7.3 7.4 7.5 7.6 7.7;do
        redhat_release=$(cat /etc/redhat-release | grep " $version")
        if [ -n "$redhat_release" ];then
            version=${version/./_}
            local rpm_dir=`eval echo '$'dockerrpm4centos_$version`
            cp -f "${script_dir}/DOCKER_RHEL_RPM/COMMON_RPMS"/*  "${script_dir}/${rpm_dir}/"
            install_rpms "${script_dir}/${rpm_dir}"
			systemctl start docker
            return 0
        fi
    done
    echo "Docker installation rpms in skylar package does not yet support $(cat /etc/redhat-release)!"
    echo "Please install the docker service yourself and then re-execute the setup script or contact customer service."
    exit 4
}

#install_rpms $dir
install_rpms(){
    [ ! -d "$1" ] && echo "Error:rpm dir $1 does not exist!" && exit 3
    for rpm_pack in `ls $1 | grep rpm`;do
        rpm -ivh "$1/$rpm_pack" --force --nodeps --nosignature
        [ $? -ne 0 ] && echo "Error:install $rpm_pack failed!" && exit 3
    done  
}

#ls images to update
images2update()
{
    local file;local name
    for name in postgresql kafka clickhouse;do
            file=$(find $tarpack_dir -maxdepth 1 -name "skylar_${name}*.tar")
            if [ -n "$file" ];then
                images="$images $name"
            fi
    done
    #strip blank space
    images=$(echo $images)

    if [ ! -n "$images" ];then
        echo -e "No images under this directory: $tarpack_dir!\n"
        exit 2
    fi
}

#use a specific -v dir "/data/supervisord" on the host to get data_dir
set_data_dir()
{
    local container_name=$(docker ps -a | grep -w "postgresql\|kafka\|clickhouse"| sed -n 1p | awk '{print $NF}')
    if [ -n "$container_name" ];then
        local bind_dirs=$(docker inspect -f '{{.HostConfig.Binds}}' $container_name | sed 's/\[\|\]//g')
        data_dir=$(echo $bind_dirs | tr ' ' '\n' | grep /data/supervisord | awk -F /supervisord '{print $1}')
    fi
    [ ! -n "$data_dir" ] && data_dir="$setup_script_dir/data"
}

#eg. get_container_id postgresql
get_container_id(){
    echo $(docker ps -a|grep -w $1|awk '{print $1}')
}

#eg. get_iamge_id postgresql
get_image_id(){
    echo $(docker images|grep -w $1|awk '{print $3}')
}

#receive full container name as parameter
#eg. stop_container postgresql
stop_container()
{
    local container_id_list; local container_id; local status
    if [ "$1" == "all" ]; then
        container_id_list=`docker ps -a|grep -w "postgresql\|kafka\|clickhouse"|awk '{print $1}'`
    else
        container_id_list=`docker ps -a|grep -w $1|awk '{print $1}'`
    fi

    if [ -n "$container_id_list" ];then
	for container_id in $container_id_list
	do
          docker stop $container_id
          status=`docker ps -a |grep -w $container_id|grep Up`
	  if [ -n "$status" ];then
             echo "stop $container_id failed, will exit setup"
	     start_container all
	     exit
	  fi
        done
    fi
}

#receive full container name as parameter
#eg. start_container postgresql
start_container()
{
    local container_id
    if [ "$1" == "all" ]; then
        container_id=`docker ps -a|grep -w "postgresql\|kafka\|clickhouse"|awk '{print $1}'`
    else
        container_id=`docker ps -a|grep -w $1|awk '{print $1}'`
    fi

    if [ -n "$container_id" ];then
        docker start $container_id
    fi
}

#receive full container name as parameter
#eg. rename_container postgresql
rename_container()
{
    local container_id
    container_id=`docker ps -a|grep -w $1|awk '{print $1}'`
    if [ -n "$container_id" ];then
        if [[ $1 =~ "back" ]];then
            docker rename $1 `echo $1|sed 's/_back//'`
        else
            docker rename $1 "$1"_back
        fi
    fi
}


#receive full containe name as parameter
#eg. rm_container postgresql
rm_container()
{
    local container_id
    container_id=`docker ps -a|grep -w $1|awk '{print $1}'`
    if [ -n "$container_id" ];then
        docker rm $1
    fi
}

#receive full image name as parameter
#eg. rm_image skylar_postgresql
rm_image()
{
    local image_id
    image_id=`docker images|grep -w $1|awk '{print $3}'`
    if [ -n "$image_id" ];then
        docker rmi $1
    fi
}

#receive full image name as parameter
#eg. rename_image skylar_postgresql
rename_image()
{
    local image_id
    image_id=`docker images|grep -w $1|awk '{print $3}'`
    if [ -n "$image_id" ];then
        if [[ $1 =~ "back" ]];then
            docker tag $1 `echo $1|sed 's/_back//'`
            docker rmi $1
        else
            docker tag $1 "$1"_back
            docker rmi $1
        fi
    fi
}

#receive full image name as parameter
#eg. import_image skylar_postgresql
import_image()
{
    local file
    file=$(find $tarpack_dir -maxdepth 1 -name "skylar_${name}*.tar" | tail -1)
    echo "import image $1 ..."
    docker load < $file
    #import failure, set rollback and return 1
    if [ $? -ne 0 ]; then
        echo "import image $1 failed, please check the tar pack manually"
        rollback=1
        return 1
    fi

    #rename imported image named none
    local none_image_id=`docker images|grep none|awk '{print $3}'`
    if [ -n "$none_image_id" ];then
        docker tag $none_image_id $1
    fi
    
    #only one backup image being grepped implies the same image named none was imported
    local total_image_count=`docker images|grep -c $1`
    local back_image_count=`docker images|grep -c "$1"_back`
    if [[ $total_image_count -eq 1 && $back_image_count -eq 1 ]];then
        docker tag "$1"_back $1
    fi
}

#receive full image name as parameter
#eg. create_container skylar_postgresql
create_container()
{   
    local image_id
    image_id=`docker images|grep -w $1|awk '{print $3}'`
    if [ ! -n "$image_id" ];then
        echo "image $1 does not exist"
        return 1
    fi

    if [ "$1" == "skylar_postgresql" ];then
        echo "#create postgresql container from image#"
        docker run -d \
        --name=postgresql  \
        --restart=always \
        --net=host \
        --privileged=true \
        -v $data_dir/pg:/var/lib/postgresql/9.5/main \
        -v $data_dir/supervisord/pg:/tmp \
        skylar_postgresql

        if [ $? -ne 0 ]; then
            echo "create container $1 failed, please check manually"
            rollback=1
            return 1
        elif [ "$pg_dump_flag" == 1 ]; then
            sleep 10    #wait 10s for postgresql service ready
            deploy_databases
        fi
    fi

    if [ "$1" == "skylar_kafka" ];then
        echo "#create kafka container from image#"
        docker run -d \
        --name=kafka \
        --restart=always \
        --net=host \
        --privileged=true \
        -v $data_dir/kafka_cluster/data:/data/kafka_cluster/data \
        -v $data_dir/kafka_cluster/logs:/data/kafka_cluster/logs \
        -v $data_dir/supervisord/kafka:/tmp \
        -v /etc/console_ip:/etc/console_ip \
        skylar_kafka

        if [ $? -ne 0 ]; then
            echo "create container $1 failed, please check manually"
            rollback=1
            return 1
        fi  
        sleep 10    #wait 10s for redis service ready   
    fi

    if [ "$1" == "skylar_clickhouse" ];then
        echo "#create clickhouse container from image#"
        docker run -d \
        --name=clickhouse \
        --restart=always \
        --net=host --privileged=true \
        -v $data_dir/clickhouse:/var/lib/clickhouse \
        -v $data_dir/supervisord/clickhouse:/tmp \
        skylar_clickhouse

        if [ $? -ne 0 ]; then
            echo "create container $1 failed, please check manually"
            rollback=1
            return 1
        else
            sleep 10    #wait 10s for clickhouse service ready
            docker exec clickhouse clickhouse-client -q "CREATE DATABASE skylar_scascade ENGINE = Ordinary;"
            docker exec clickhouse bash -c "clickhouse-client -d skylar_scascade --multiquery < /etc/clickhouse-server/scascade.sql"  
        fi     
    fi 
}

#receive full container name as parameter
#eg. check_container postgresql
check_container()
{
    local container_id; local status_up
    echo "check if $1 container start up..."
    container_id=`docker ps -a|grep -w $1|awk '{print $1}'`
    status_up=`docker ps -a | grep -w $1 | grep Up`
    if [ ! -n "$status_up" ];then
        echo "error, rollback later, see docker logs at $log_dir"
        [ -n "$container_id" ] && docker logs $1 >> "$log_dir/docker_logs_$1_$(date +%Y%m%d_%H%M%S).log"
        rollback=1
    else
        echo "pass"
    fi
}

rm_rc_records()
{
    echo "----rm old record in /etc/rc.d/rc.local----"
    sed -i '/sleep/d' /etc/rc.d/rc.local
    sed -i '/docker/d' /etc/rc.d/rc.local
    #sed -i '/init_network.py/d' /etc/rc.d/rc.local
    #sed -i '/envmgr.sh/d' /etc/rc.d/rc.local
    chmod a+x /etc/rc.d/rc.local
}

add_rc_records()
{
    local name; local container_id
    echo "----add docker start command in /etc/rc.d/rc.local----"
    #echo "python $netscript_dir/init_network.py" >> /etc/rc.d/rc.local
    #echo "$netscript_dir/envmgr.sh" >> /etc/rc.d/rc.local
    for name in postgresql kafka clickhouse;do
        container_id=$(get_container_id $name)
        if [ -n "$container_id" ];then
            echo "docker start $container_id" >> /etc/rc.d/rc.local
        fi
    done
    echo "sleep 5" >> /etc/rc.d/rc.local        #sleep 5 secs for docker service ready
    chmod a+x /etc/rc.d/rc.local
}

check_env(){
    echo "----check env by envmgr.sh----"
    cp -f "$script_dir/envmgr.sh" "$netscript_dir"
    chmod a+x "$netscript_dir/envmgr.sh"
    $netscript_dir/envmgr.sh
}


#this is an abandoned function, replaced by check_env()
empty_ifcfg()
{
    echo "----empty ip setting from ifcfg-exx----"
    ifcfg_list="$(cd /etc/sysconfig/network-scripts && ls ifcfg-*|grep -v ifcfg-lo)"
    for ifcfgx in $ifcfg_list;do
        sed -i '/ONBOOT/d' /etc/sysconfig/network-scripts/$ifcfgx
        echo "ONBOOT=yes" >> /etc/sysconfig/network-scripts/$ifcfgx
        sed -i '/BOOTPROTO/d' /etc/sysconfig/network-scripts/$ifcfgx
        echo "BOOTPROTO=static" >> /etc/sysconfig/network-scripts/$ifcfgx
        sed -i '/IPADDR/d' /etc/sysconfig/network-scripts/$ifcfgx
        sed -i '/NETMASK/d' /etc/sysconfig/network-scripts/$ifcfgx
        sed -i '/GATEWAY/d' /etc/sysconfig/network-scripts/$ifcfgx
        sed -i '/NM_CONTROLLED/d' /etc/sysconfig/network-scripts/$ifcfgx
        echo "NM_CONTROLLED=no" >> /etc/sysconfig/network-scripts/$ifcfgx
    done
    echo "----disable NetworkManager sevice----"
    systemctl stop NetworkManager
    systemctl disable NetworkManager
    systemctl enable network
    systemctl start network
}

set_arp_ignore()
{
    echo "----set arp_ignore----"
    sysctl -w net.ipv4.conf.all.arp_ignore=1
    sed -i '/net.ipv4.conf.all.arp_ignore=/d' /etc/sysctl.conf
    echo 'net.ipv4.conf.all.arp_ignore=1' >> /etc/sysctl.conf
    for ifx in $(ip addr show|grep ': eth'|awk -F : '{print $2}');do
        sysctl -w net.ipv4.conf.$ifx.arp_ignore=1
        sed -i "/net.ipv4.conf.$ifx.arp_ignore=/d" /etc/sysctl.conf
        echo "net.ipv4.conf.$ifx.arp_ignore=1" >> /etc/sysctl.conf
    done
}

set_coredump()
{
    echo "----set coredump----"
    sysctl -w kernel.core_pattern="/tmp/coredump/core.%p-%u-%s-%t-%e"
    sed -i '/kernel.core_pattern=/d' /etc/sysctl.conf
    echo 'kernel.core_pattern=/tmp/coredump/core.%p-%u-%s-%t-%e' >> /etc/sysctl.conf
}

set_ulimit()
{
    echo "----modify ulimit----"
    ulimit -n 1020000
    sed -i '/nofile/d' /etc/security/limits.conf
    echo "* hard nofile 1020000" >> /etc/security/limits.conf
    echo "* soft nofile 1020000" >> /etc/security/limits.conf
}

#copy scripts for docker update
init_docker_update()
{
    echo "----copy scripts for docker update----"
    if [ "$data_dir" != "$setup_script_dir/data" ];then
        cp -rf $script_dir $setup_dir
        cp -f $setup_script_dir/setup $setup_dir
        cp -f $setup_script_dir/uninst $setup_dir
    fi
}

#sync install.log under $setup_script_dir with that under $data_dir
sync_install_log()
{
    if [ "$data_dir" != "$setup_script_dir/data" ];then
        local tmp_log_file="$tmp_log_dir/install.log"
        local real_log_file="$log_dir/install.log"
        cat "$tmp_log_file" >> "$real_log_file"
        rm -f "$tmp_log_file"
    fi
}

#backup postgresql data
backup_databases()
{
    echo "----backup databases----"  
    [ ! -d "$pgdump_sql_dir" ] && mkdir -p "$pgdump_sql_dir"
    docker exec postgresql pg_dump -h 127.0.0.1 -p 5432 -U postgres scascade > "$pgdump_sql_dir/scascade.sql"
    if [ $? -ne 0 ];then
        rm -f "$pgdump_sql_dir"/*.sql
        echo "Error: backup postgresql data failure!"
        exit 6
    fi
}

#import postgresql data
deploy_databases()
{
    local tmp_log_file="$log_dir/pg_update_$(date +%Y%m%d_%H%M%S).log"
    echo "----deploy postgresql data from sql----"
    #move sql to -v dir
    chmod a+x "$pgdump_sql_dir"/*.sql
    mv -f "$pgdump_sql_dir" "$pg_data_dir"
    #import sql into new container
    chmod a+x "$script_dir/import_from_sql.sh"
    docker cp "$script_dir/import_from_sql.sh" "pg:/"
    docker exec postgresql bash import_from_sql.sh >> "$tmp_log_file"
    #roll back if import fails
    if [ $? -ne 0 ];then
        echo "update pg data failure, logs at $tmp_log_file, try to recover and roll back..."
        rollback=1
        stop_container postgresql
        mv -f "$pg_data_dir/pgdump_sql" "$data_dir"
        rm -f "$pg_data_dir"/*
        start_container pg_back
        sleep 10    #wait 10s for pg service ready
        mv -f "$pgdump_sql_dir" "$pg_data_dir"
        docker cp "$script_dir/import_from_sql.sh" "pg_back:/"
        docker exec pg_back bash import_from_sql.sh >> "$tmp_log_file"
        [ $? -ne 0 ] && echo "Error: recover pg data failure, backup sql file at $pgdump_sql_dir"
        stop_container pg_back
    fi
}

echo "----INSTALLING----"

check_console_ip

#cd to abs path of this shell
cd `dirname $0`

#init install settings if not set
[ ! -n "$script_dir" ] && script_dir=$(cd `dirname $0`;pwd)
[ ! -n "$setup_script_dir" ] && setup_script_dir=$(dirname $script_dir)
[ ! -n "$netscript_dir" ] && netscript_dir="/etc/sysconfig/network-scripts"
[ ! -n "$tarpack_dir" ] && tarpack_dir=$(dirname $script_dir)
[ ! -n "$force_flag" ] && force_flag=0
[ ! -n "$pg_dump_flag" ] && pg_dump_flag=0
[ ! -n "$rollback" ] && rollback=0

[ ! -n "$images" ] && images2update
[ ! -n "$data_dir" ] && set_data_dir
[ ! -n "$setup_dir" ] && setup_dir=$(dirname $data_dir)
[ ! -n "$pgdump_sql_dir" ] && pgdump_sql_dir="$data_dir/pgdump_sql"
[ ! -n "$pg_data_dir" ] && pg_data_dir="$data_dir/pg"

log_dir="$data_dir/log/docker"
[ ! -d "$log_dir" ] && mkdir -p "$log_dir"

echo "install setting:
images to install : $images
tarpack_dir : $tarpack_dir
skylar_data_dir : $data_dir
log_dir : $log_dir
force installation : $force_flag
"

check_docker_version
[ $? -ne 0 ] && install_docker

#check_env

if [ "$pg_dump_flag" == 1 ]; then
    backup_databases
fi

echo "----stop old containers----"
stop_container all

if [ "$pg_dump_flag" == 1 ]; then
    rm -rf "$pg_data_dir"/*
fi

echo "----rename old containers and images----"
for name in $images;do 
    rename_container $name
    rename_image skylar_$name
done

echo "----import/name new images from tar----"
for name in $images;do 
    import_image skylar_$name
done

echo "----create containers from new images----"
for name in $images;do 
    create_container skylar_$name
done

echo "----start stopped containers----"
for name in postgresql kafka clickhouse;do 
    start_container $name
done
sleep 10    #sleep 10 secs for container to start

echo "----check containers status----"
for name in $images;do 
    check_container $name
done

if [ "$rollback" == 0 ] || [ "$force_flag" == 1 ];then
    echo "----setup succeed or force installation, delete old containers and images----"
    for name in $images;do 
        rm_container "$name"_back
        rm_image skylar_"$name"_back
    done
else
    echo "----setup failed, roll back----"
    echo "collect data..."
    tmp_log_file="$log_dir/docker_status_$(date +%Y%m%d_%H%M%S).log"
    docker ps -a >> "$tmp_log_file"
    docker images >> "$tmp_log_file"
    ls -l "$data_dir" >> "$tmp_log_file"
    ls -R "$data_dir" >> "$tmp_log_file"
    echo "clear new containers and images..."
    for name in $images;do 
        stop_container $name
        sleep 2    #sleep 2 secs for container to stop
        rm_container $name
        rm_image skylar_$name
    done
    echo "roll back to former state..."
    for name in $images;do 
        start_container "$name"_back
        rename_container "$name"_back
        rename_image skylar_"$name"_back
    done
    echo -e "----DONE----\n"
    sync_install_log
    exit 1
fi

#rc.local settings
rm_rc_records
add_rc_records

#some other settings
set_arp_ignore
set_coredump
set_ulimit
init_docker_update

echo -e "----DONE----\n"
sync_install_log
exit 0
