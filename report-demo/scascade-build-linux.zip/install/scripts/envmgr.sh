#!/bin/bash

log_dir="/var/log/envmgr.log"
logrotate_config="/etc/logrotate.d/envmgr"
netscript_dir="/etc/sysconfig/network-scripts"

disable_docker(){
    systemctl disable docker
    systemctl stop docker
}

enable_docker(){
    which docker >> /dev/null
    if [ $? -ne 0 ]; then
        echo "Error: Docker service not installed, please install docker manually." >> $log_dir
        return 0
    fi

    systemctl status docker | grep "Active: inactive" >> /dev/null
    if [ $? -eq 0 ]; then
        echo "Docker daemon status down, try to fix..." >> $log_dir
        systemctl enable docker
        systemctl start docker
        if [ $? -ne 0 ]; then
            echo "Error: Can not start docker service, please check if docker is correctly installed." >> $log_dir
        fi
    else
        echo "OK, docker service is enabled." >> $log_dir
    fi
}

disable_netmgr(){
    systemctl status NetworkManager | grep "inactive" >> /dev/null
    if [ $? -ne 0 ]; then
        echo "Stopping NetworkManager..." >> $log_dir
        systemctl disable NetworkManager
        systemctl stop NetworkManager        
    fi

    systemctl status network | grep "inactive" >> /dev/null
    if [ $? -eq 0 ]; then
        echo "Starting network.service..." >> $log_dir
        systemctl enable network
        systemctl start network
    fi
}

#eg. disable_dhcp eth0
disable_dhcp(){
    local network_file="/etc/sysconfig/network-scripts/ifcfg-$1"
    echo "#Modify network device $1#" >> $log_dir
    if [ -f $network_file ]; then   
        cat $network_file | grep "dhcp\|DHCP" >> $log_dir
        if [ $? -eq 0 ]; then
            echo "Device $ethName uses dhcp to get ip, reconfigure it to static..." >> $log_dir
            cp -fr $network_file /etc/sysconfig/network-scripts/backup-ifcfg-$1
            sed -i 's/dhcp\|DHCP/static/g' $network_file
            if [ $? -ne 0 ]; then
                echo "ERROR: fail to disable dhcp." >> $log_dir
                mv -f /etc/sysconfig/network-scripts/backup-ifcfg-$1 $network_file
            else
                echo "OK, dhcp is disabled." >> $log_dir
            fi
        fi
    else
        echo "$network_file does not exist!" >> $log_dir
    fi
}

#eg. enable_dhcp eth0
enable_dhcp(){
    local network_file="/etc/sysconfig/network-scripts/ifcfg-$1"
    if [ -f $network_file ]; then
        sed -i 's/static/dhcp/g' $network_file
    fi
}

base10to2(){
    local num=$1; local result
    while [ $num -gt 0 ]; do
        let r=num%2
        result=$r$result
        let num=num/2
    done
    echo $result
}

base2to10(){
    local count=$(echo $1 | wc -c)
    let "count--"                      
    local n=$count; local i=0 ;local result=0
    while [ $i -lt $count ]; do
        c=$(echo $1 | cut -b $n)
        let "result+=c*2**i"
        let "i++"; let "n--"
    done
    echo $result
}

#eg. netmask2prefix 24
prefix2netmask(){  
    if [ ! -n "$1" ];then
        echo ""; return
    fi

    local prefix_cnt=$1; local bin_prefix=""
    for i in `seq 1 $prefix_cnt`; do
        bin_prefix="${bin_prefix}1"
    done
    prefix_cnt=$((32 - ${prefix_cnt}))
    for i in `seq 1 $prefix_cnt`; do
        bin_prefix="${bin_prefix}0"
    done

    local netmask=""; local tmpmask=""
    for i in `seq 0 8 31`; do
        val=${bin_prefix:${i}:8}
        tmpmask=$(base2to10 ${val})
        if [ "$netmask" = "" ];then
            netmask="${tmpmask}"
        else
            netmask="${netmask}.${tmpmask}"
        fi
    done
    echo $netmask
}

#eg. netmask2prefix 255.255.255.0
netmask2prefix(){
    local netmask2base10=`echo '$1' | awk -F '.' '{print ($1*(2^24)+$2*(2^16)+$3*(2^8)+$4)}'`
    echo `base10to2 $netmask2base10` | awk -F '0' '{print length($1)}'
}

#eg. validate_ip 127.0.0.1
validate_ip(){
    echo "$1" | grep -Eq '[^0-9.]|^\.|\.$' && return 1
    [ $(echo -e "${1//./\n}" | wc -l) -ne 4 ] && return 1
    for i in ${1//./ } ; do
        [ $((i/8)) -lt 32 ] || return 1
    done
    return 0
}

#receive netcard name as parameter
set_ip(){
    local network_file="/etc/sysconfig/network-scripts/ifcfg-$1"
    local ipaddr=`/sbin/ip addr show $1 | grep -w inet | sed -n 1p | awk '{ print $2 }' | awk -F '/' {'print $1'}`
    local netmaskprefix=`/sbin/ip addr show $1 | grep -w inet | sed -n 1p | awk '{ print $2 }' | awk -F '/' {'print $2'}`
    local netmask=`prefix2netmask $netmaskprefix`

    validate_ip $ipaddr; [ $? -ne 0 ] && ipaddr=""
    validate_ip $netmask; [ $? -ne 0 ] && netmask=""
    echo "set ip and netmask for $1 ..." >> $log_dir
    if [[ -n $ipaddr && -n $netmask && -f $network_file ]]; then
        echo "set netcard $1 ipaddr=$ipaddr" >> $log_dir
        sed -i '/ipaddr\|IPADDR/d' $network_file
        echo "IPADDR=$ipaddr" >> $network_file

        echo "set netcard $1 netmask=$netmask" >> $log_dir
        sed -i '/netmask\|NETMASK/d' $network_file
        echo "NETMASK=$netmask" >> $network_file    
    else
        echo "$network_file does not exist or can not fetch ipaddr for netcard $1!" >> $log_dir
    fi
}

#logrotate settings
set_syslog(){
    if [ ! -f $logrotate_config ]; then
        touch $logrotate_config
    fi

    cat $logrotate_config | grep "$log_dir" >> /dev/null
    if [ $? -ne 0 ]; then
        echo -e "$log_dir {\nrotate 2\nsize 1M\n}" >> $logrotate_config
    fi
}

#init syslog
set_syslog

echo `date` >> $log_dir

echo "--------Check docker status--------" >> $log_dir
enable_docker

echo "--------Disable NetworkManager sevice--------" >> $log_dir
disable_netmgr

echo "--------Disable dhcp sevice--------" >> $log_dir
#device=`ip addr | grep "<" | awk {'print $2'} | awk -F ":" {'print $1'}`
for ethName in $(ls /sys/class/net | grep -v "lo\|docker*");do
    disable_dhcp $ethName
    set_ip $ethName
done

#firewall settings
echo "----manage firewall settings----" >> $log_dir
$netscript_dir/open_firewalld.sh >> $log_dir

echo "--------Done--------" >> $log_dir
echo >> $log_dir
exit 0
