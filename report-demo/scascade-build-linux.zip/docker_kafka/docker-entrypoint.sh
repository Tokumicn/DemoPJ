#!/bin/bash
#启动服务使用
set -e

outer_ip=$(cat /etc/console_ip)
sed -i "s/kafka_host/$outer_ip/g" /data/kafka_cluster/config/server.properties.1
sed -i "s/kafka_host/$outer_ip/g" /data/kafka_cluster/config/server.properties.2
sed -i "s/kafka_host/$outer_ip/g" /data/kafka_cluster/config/server.properties.3

if [ "$1" = 'supervisord' ]; then
	chmod -R 777 /tmp
	exec supervisord -n -c /etc/supervisor/supervisord.conf
else
	exec "$@"
fi