#!/bin/bash
#启动服务使用
set -e
if [ "$1" = 'supervisord' ]; then
	chmod -R 777 /tmp
	chown -R clickhouse:clickhouse /var/log/clickhouse-server
	chown -R clickhouse:clickhouse /var/lib/clickhouse
	exec supervisord -n -c /etc/supervisor/supervisord.conf
else
	exec "$@"
fi