-- ----------------------------
-- skylar_scascade.aduit 审计日志
-- ----------------------------
CREATE TABLE IF NOT EXISTS skylar_scascade.audit
(
    `client_mid` String,
    `client_name` String,
    `client_nickname` String,
    `client_displayname` String,
    `client_reportip` String,
    `client_ip` String,
    `client_gid` String,
    `client_os` String,
    `client_mac` String,
    `client_third_login_user` String,
    `client_login_user` String,
    `client_groupname` String,
    `client_grouppath` String,
    `ccid` String,
    `type` String,
    `account` String,
    `content` String,
    `format_content` String,
    `occur_time` DateTime,
    `event_time` DateTime
)
ENGINE = MergeTree()
PARTITION BY toYYYYMMDD(event_time)
ORDER BY (event_time,ccid,type)
SETTINGS index_granularity = 8192;
 
 
-- ----------------------------
-- skylar_scascade.exam 扫描分数日志
-- ----------------------------
CREATE TABLE IF NOT EXISTS skylar_scascade.exam
(
    `client_mid` String,
    `client_name` String,
    `client_nickname` String,
    `client_displayname` String,
    `client_reportip` String,
    `client_ip` String,
    `client_gid` String,
    `client_os` String,
    `client_mac` String,
    `client_third_login_user` String,
    `client_login_user` String,
    `client_groupname` String,
    `client_grouppath` String,
    `ccid` String,
    `exam_score` Float64,
    `leak_num` Int16,
    `virus_num` Int16,
    `event_time` DateTime
)
ENGINE = MergeTree()
PARTITION BY toYYYYMMDD(event_time)
ORDER BY (event_time,ccid,exam_score)
SETTINGS index_granularity = 8192;
 
 
-- ----------------------------
-- skylar_scascade.leak_repair 漏洞分析
-- ----------------------------
CREATE TABLE IF NOT EXISTS skylar_scascade.leak_repair
(
    `client_mid` String,
    `client_name` String,
    `client_nickname` String,
    `client_displayname` String,
    `client_reportip` String,
    `client_ip` String,
    `client_gid` String,
    `client_os` String,
    `client_mac` String,
    `client_third_login_user` String,
    `client_login_user` String,
    `client_groupname` String,
    `client_grouppath` String,
    `ccid` String,
    `event_action` Int16,
    `leak_name` String,
    `kbid` String,
    `prestatus` Int16,
    `currstatus` Int16,
    `reason` Int16,
    `leak_type` Int16,
    `event_time` DateTime
)
ENGINE = MergeTree()
PARTITION BY toYYYYMMDD(event_time)
ORDER BY (event_time,ccid,leak_type,kbid)
SETTINGS index_granularity = 8192;
 
 
-- ----------------------------
-- skylar_scascade.sd 病毒分析
-- ----------------------------
CREATE TABLE IF NOT EXISTS skylar_scascade.sd
(
    `client_mid` String,
    `client_name` String,
    `client_nickname` String,
    `client_displayname` String,
    `client_reportip` String,
    `client_ip` String,
    `client_gid` String,
    `client_os` String,
    `client_mac` String,
    `client_third_login_user` String,
    `client_login_user` String,
    `client_groupname` String,
    `client_grouppath` String,
    `ccid` String,
    `md5` String,
    `op` Int16,
    `path` String,
    `sha1` String,
    `task_id` Int32,
    `virus_cat` Int16,
    `from` String,
    `type` Int16,
    `event_time` DateTime,
    `vname` String
)
ENGINE = MergeTree()
PARTITION BY toYYYYMMDD(event_time)
ORDER BY (event_time,ccid,task_id,type,vname)
SETTINGS index_granularity = 8192;
 
 
-- ----------------------------
-- skylar_scascade.secevent 告警时间
-- ----------------------------
CREATE TABLE IF NOT EXISTS skylar_scascade.secevent
(
    `client_mid` String,
    `client_name` String,
    `client_nickname` String,
    `client_displayname` String,
    `client_reportip` String,
    `client_ip` String,
    `client_gid` String,
    `client_os` String,
    `client_mac` String,
    `client_third_login_user` String,
    `client_login_user` String,
    `client_groupname` String,
    `client_grouppath` String,
    `ccid` String,
    `type` String,
    `account` String,
    `content` String,
    `format_content` String,
    `datetime` DateTime,
    `event_time` DateTime
)
ENGINE = MergeTree()
PARTITION BY toYYYYMMDD(event_time)
ORDER BY (event_time,ccid,type)
SETTINGS index_granularity = 8192;