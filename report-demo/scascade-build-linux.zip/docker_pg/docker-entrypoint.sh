#!/bin/bash
set -e
if [ "$1" = 'supervisord' ]; then
	if [ -z "$(ls -A "$PGDATA")" ]; then
		cp -r /backup_pg/main /var/lib/postgresql/9.5
	fi
	chown -R postgres:postgres "$PGDATA"
	chmod -R 0700 $PGDATA
	exec supervisord -n -c /etc/supervisor/supervisord.conf
else
	exec "$@"
fi