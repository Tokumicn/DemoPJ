CREATE OR REPLACE FUNCTION create_index_if_not_exists(table_name text, column_names anyarray, unique_str text) RETURNS void AS $BODY$
DECLARE
  full_index_name varchar;
  schema_name varchar;
BEGIN
full_index_name = table_name || '_' || array_to_string(column_names, '_') || '_idx';
full_index_name = replace(full_index_name, ' ', '');
schema_name     = 'public';
IF NOT EXISTS (
    SELECT 1
    FROM   pg_class c
    JOIN   pg_namespace n ON n.oid = c.relnamespace
    WHERE  c.relname = full_index_name
    AND    n.nspname = schema_name
    ) THEN
    execute 'CREATE ' || unique_str || ' INDEX ' || full_index_name || ' ON ' || schema_name || '.' || table_name || ' USING btree (' || array_to_string(column_names, ',') || ') ';
END IF;
END
$BODY$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION create_index_if_not_exists(table_name text, column_names anyarray, unique_str text, index_type text) RETURNS void AS $BODY$
DECLARE
  full_index_name varchar;
  schema_name varchar;
BEGIN
full_index_name = table_name || '_' || array_to_string(column_names, '_') || '_idx';
full_index_name = replace(full_index_name, ' ', '');
schema_name     = 'public';
IF NOT EXISTS (
    SELECT 1
    FROM   pg_class c
    JOIN   pg_namespace n ON n.oid = c.relnamespace
    WHERE  c.relname = full_index_name
    AND    n.nspname = schema_name
    ) THEN
    execute 'CREATE ' || unique_str || ' INDEX ' || full_index_name || ' ON ' || schema_name || '.' || table_name || ' USING '|| index_type ||' (' || array_to_string(column_names, ',') || ') ';
END IF;
END
$BODY$ LANGUAGE plpgsql;

--example
--SELECT create_index_if_not_exists('user', ARRAY['name'], 'UNIQUE');
--SELECT create_index_if_not_exists('client', ARRAY['gid'], '');
--SELECT create_index_if_not_exists('exam_trust', ARRAY['lib_id', 'mid'], 'UNIQUE');

CREATE OR REPLACE FUNCTION add_column_if_not_exists(table_name text, column_name text, column_attr_string text) RETURNS void AS $BODY$
BEGIN
IF NOT EXISTS (
	SELECT 1
  FROM   pg_attribute
  WHERE  attrelid = table_name::regclass  -- cast to a registered class (table)
  AND    attname = column_name
  AND    NOT attisdropped  -- exclude dropped (dead) columns
)THEN
    EXECUTE 'ALTER TABLE "' || table_name || '" ADD COLUMN ' || column_name || ' '|| column_attr_string;
END IF;
END
$BODY$ LANGUAGE plpgsql;

--example
--SELECT create_index_if_not_exists('group_rules', 'netfind', 'json');
--SELECT create_index_if_not_exists('test', 'name', 'integer NOT NULL DEFAULT 1');

CREATE OR REPLACE FUNCTION drop_index_if_exists(full_index_name text) RETURNS void AS $BODY$
DECLARE
  schema_name varchar;
BEGIN
schema_name = 'public';
IF EXISTS (
    SELECT 1
    FROM   pg_class c
    JOIN   pg_namespace n ON n.oid = c.relnamespace
    WHERE  c.relname = full_index_name
    AND    n.nspname = schema_name
    ) THEN
    execute 'DROP INDEX ' || full_index_name;
END IF;
END
$BODY$ LANGUAGE plpgsql;

--example
--SELECT drop_index_if_exists('user_role_id_idx');

CREATE OR REPLACE FUNCTION drop_column_if_exists(table_name text, column_name text) RETURNS void AS $BODY$
BEGIN
IF EXISTS (
  SELECT 1
  FROM   pg_attribute
  WHERE  attrelid = table_name::regclass  -- cast to a registered class (table)
  AND    attname = column_name
  AND    NOT attisdropped  -- exclude dropped (dead) columns
)THEN
    EXECUTE 'ALTER TABLE ' || table_name || ' DROP COLUMN ' || column_name;
END IF;
END
$BODY$ LANGUAGE plpgsql;

--example
--SELECT drop_column_if_exists('user', 'role_id');

CREATE OR REPLACE FUNCTION modify_column_if_exists(table_name text, column_name text, column_attr_string text) RETURNS void AS $BODY$
BEGIN
IF EXISTS (
  SELECT 1
  FROM   pg_attribute
  WHERE  attrelid = table_name::regclass  -- cast to a registered class (table)
  AND    attname = column_name
  AND    NOT attisdropped  -- exclude dropped (dead) columns
)THEN
    EXECUTE 'ALTER TABLE ' || table_name || ' ALTER COLUMN ' || column_name || ' TYPE  '|| column_attr_string;
END IF;
END
$BODY$ LANGUAGE plpgsql;

--example
--SELECT modify_column_if_exists('ip_range_filter', 'ip_end', 'inet USING (ip_end::inet)');
--SELECT modify_column_if_exists('ip_range_filter', 'ip_start', 'varchar(16)');

CREATE OR REPLACE FUNCTION array_intersect (IN a1 _int4, IN a2 _int4) RETURNS "_int4" 
    AS $BODY$
declare
    ret int[];
begin
    if a1 is null or a2 is null then
        return null;
    end if;
    select array_agg(e) into ret
    from (
        select unnest(a1)
        intersect
        select unnest(a2)
    ) as dt(e);
    return ret;
end;
$BODY$ LANGUAGE plpgsql;

--example
--select array_intersect(array[1,2,3],array[3,4,5])

CREATE OR REPLACE FUNCTION drop_constraint_if_exists(table_name text, full_constraint_name text) RETURNS void AS $BODY$
DECLARE
  schema_name varchar;
BEGIN
schema_name = 'public';
IF EXISTS (
    SELECT 1
    FROM   pg_constraint
    WHERE  pg_constraint.conname = full_constraint_name
    ) THEN
    EXECUTE 'ALTER TABLE ' || table_name || ' DROP CONSTRAINT ' || full_constraint_name ;
END IF;
END
$BODY$ LANGUAGE plpgsql;

--example
--SELECT drop_constraint_if_exists('tag_info', 'tag_info_name_key');

CREATE OR REPLACE FUNCTION create_jsonb_index_if_not_exists(table_name text, column_name text, jsonb_column_name text) RETURNS void AS $BODY$
DECLARE
  full_jsonb_constraint_name varchar;
  schema_name varchar;
BEGIN
full_jsonb_constraint_name =  jsonb_column_name || '_idx';
schema_name     = 'public';
IF NOT EXISTS (
    SELECT 1
    FROM   pg_class c
    JOIN   pg_namespace n ON n.oid = c.relnamespace
    WHERE  c.relname = full_jsonb_constraint_name
    AND    n.nspname = schema_name
    ) THEN
    execute 'create index ' || jsonb_column_name|| '_idx on ' || schema_name || '.' || table_name || ' using btree(' || '( '|| column_name || '->>''' || jsonb_column_name || ''' )' || ') ';
END IF;
END
$BODY$ LANGUAGE plpgsql;

 -- example 
 --- select count_estimate( ' select count(*) as cnt from rptsvc_leak_event WHERE gid > ''0'' ' )

CREATE OR REPLACE FUNCTION count_estimate(query text) RETURNS INTEGER AS $BODY$
DECLARE
    rec   record;
    ROWS  INTEGER;
BEGIN
    FOR rec IN EXECUTE 'EXPLAIN ' || query LOOP
        ROWS := SUBSTRING(rec."QUERY PLAN" FROM ' rows=([[:digit:]]+)');
        EXIT WHEN ROWS IS NOT NULL;
    END LOOP;
    RETURN ROWS;
END
$BODY$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION create_type_if_not_exists(type_name text, sub_type text) RETURNS void AS $BODY$
BEGIN
IF NOT EXISTS (
    SELECT 1
    FROM   pg_type c
    WHERE  typname = type_name
    ) THEN
    execute 'CREATE TYPE ' || type_name || ' AS RANGE (  SUBTYPE = ' || sub_type || ');';
END IF;
END
$BODY$ LANGUAGE plpgsql;

--- custom type for ip range  by junru 
select create_type_if_not_exists('iprange', 'inet'); 


--- fix https://tqwiki.intra.legendsec.com/issues/5729
CREATE OR REPLACE FUNCTION exec_by_version(version text, command text) RETURNS void AS $BODY$
DECLARE
BEGIN
IF  EXISTS (
    SELECT 1 from (select version() v ) tbl where  v like '%' || version || '%'
    ) THEN
    execute command;
END IF;
END
$BODY$ LANGUAGE plpgsql;

create or replace function inet_larger(inet, inet)
returns inet language sql as $$
    select case when network_gt($1, $2) then $1 else $2 end
$$;

create or replace function inet_smaller(inet, inet)
returns inet language sql as $$
    select case when network_lt($1, $2) then $1 else $2 end
$$;


select exec_by_version('9.4','
DROP AGGREGATE IF EXISTS max(inet);
CREATE AGGREGATE max(inet) (
  SFUNC=inet_larger,
  STYPE=inet,
  SORTOP=">"
);');


select exec_by_version('9.4','
DROP AGGREGATE if exists min(inet);
CREATE AGGREGATE min(inet) (
  SFUNC=inet_smaller,
  STYPE=inet,
  SORTOP="<"
);');

CREATE OR REPLACE FUNCTION ver2int(text) RETURNS bigint AS $$
SELECT split_part($1,'.',1)::bigint*16777216 + split_part($1,'.',2)::bigint*65536 +
 split_part($1,'.',3)::bigint*256 + split_part($1,'.',4)::bigint;
$$ LANGUAGE SQL  IMMUTABLE RETURNS NULL ON NULL INPUT;

CREATE OR REPLACE FUNCTION create_leaklib_ver_idx_if_not_exists(table_name text, column_names text) RETURNS void AS $BODY$
DECLARE
  full_index_name varchar;
  schema_name varchar;
BEGIN
full_index_name = table_name || '_' || column_names  || '_idx';
schema_name     = 'public';
IF NOT EXISTS (
    SELECT 1
    FROM   pg_class c
    JOIN   pg_namespace n ON n.oid = c.relnamespace
    WHERE  c.relname = full_index_name
    AND    n.nspname = schema_name
    ) THEN
    execute 'CREATE INDEX ' || full_index_name || ' ON ' || schema_name || '.' || table_name || ' (ver2int('|| column_names ||')) ';
END IF;
END
$BODY$ LANGUAGE plpgsql;


