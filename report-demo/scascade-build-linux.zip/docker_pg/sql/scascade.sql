
-- ----------------------------
-- Table structure for cron_task 定时任务表
-- ----------------------------
CREATE TABLE IF NOT EXISTS cron_task (
  "id" SERIAL NOT NULL,
  "name" varchar(50) NOT NULL DEFAULT ''::character varying,
  "job_name" varchar(32) NOT NULL DEFAULT ''::character varying,
  "business" varchar(16) NOT NULL DEFAULT ''::character varying,
  "report_types" varchar(128) NOT NULL DEFAULT ''::character varying,
  "cron_type" varchar(16) NOT NULL DEFAULT ''::character varying,
  "top_ccid" varchar(64) NOT NULL DEFAULT ''::character varying,
  "ccids_tree" varchar(5120) NOT NULL DEFAULT ''::character varying,
  "raw_tree" varchar(5120) NOT NULL DEFAULT ''::character varying,
  "data_cover" bool NOT NULL DEFAULT false,
  "day" int2 NOT NULL DEFAULT 0,
  "hours" int2 NOT NULL DEFAULT 0,
  "minutes" int2 NOT NULL DEFAULT 0,
  "time_scale" varchar(32) NOT NULL DEFAULT ''::character varying,
  "time_range" varchar(32) NOT NULL DEFAULT ''::character varying,
  "start_time" varchar(32) NOT NULL DEFAULT ''::character varying,
  "end_time" varchar(32) NOT NULL DEFAULT ''::character varying,
  "create_time" timestamp(6) NOT NULL DEFAULT now(),
  "update_time" timestamp(6) NOT NULL DEFAULT now(),
  CONSTRAINT "cron_task_pkey" PRIMARY KEY ("id")
);

-- ----------------------------
-- Table structure for cron_task_result 定时任务查询结果记录表
-- ----------------------------
CREATE TABLE IF NOT EXISTS cron_task_result (
  "id" SERIAL NOT NULL,
  "task_id" int4 NOT NULL DEFAULT 0,
  "task_name" varchar(128) NOT NULL DEFAULT ''::character varying,
  "cron_expr" varchar(128) NOT NULL DEFAULT ''::character varying,
  "condition" varchar(512) NOT NULL DEFAULT ''::character varying,
  "raw_tree" varchar(5120) NOT NULL DEFAULT ''::character varying,
  "plan_start_time" timestamp(6) NOT NULL DEFAULT now(),
  "real_start_time" timestamp(6) NOT NULL DEFAULT now(),
  "finish_time" timestamp(6) NOT NULL DEFAULT now(),
  CONSTRAINT "cron_task_result_pkey" PRIMARY KEY ("id")
);
SELECT create_index_if_not_exists('cron_task_result', ARRAY['task_id'], '');

-- ----------------------------
-- Table structure for query_condition_tlp
-- ----------------------------
CREATE TABLE IF NOT EXISTS query_condition_tlp (
  "id" SERIAL NOT NULL,
  "name" varchar(128) NOT NULL DEFAULT ''::character varying,
  "business_code" varchar(128) NOT NULL DEFAULT ''::character varying,
  "conditions" varchar(5120) NOT NULL DEFAULT ''::character varying,
  "relation_tlp" varchar(512) NOT NULL DEFAULT ''::character varying,
  "create_time" timestamp(6) NOT NULL DEFAULT now(),
  "update_time" timestamp(6) NOT NULL DEFAULT now(),
  CONSTRAINT "query_condition_tlp_pkey" PRIMARY KEY ("id")
);

-- ----------------------------
-- Table structure for query_custom_column 自定义列
-- ----------------------------
CREATE TABLE IF NOT EXISTS query_custom_column (
  "id" SERIAL NOT NULL,
  "business_code" varchar(128) NOT NULL DEFAULT ''::character varying,
  "table_name" varchar(128) NOT NULL DEFAULT ''::character varying,
  "custom_column" varchar(2048) NOT NULL DEFAULT ''::character varying,
  "optional_column" varchar(2048) NOT NULL DEFAULT ''::character varying,
  "all_column_map" varchar(5120) NOT NULL DEFAULT ''::character varying,
  "create_time" timestamp(6) NOT NULL DEFAULT now(),
  "update_time" timestamp(6) NOT NULL DEFAULT now(),
  CONSTRAINT "query_custom_column_pkey" PRIMARY KEY ("id")
);
-- ----------------------------
-- Table structure for scascade_alert_summarize 告警事件-汇总统计
-- ----------------------------
CREATE TABLE IF NOT EXISTS scascade_alert_summarize (
   "id" SERIAL NOT NULL,
   "result_id" int4 NOT NULL DEFAULT 0,
   "data_type" int2 NOT NULL DEFAULT 0,
   "top_ccid" varchar(64) NOT NULL DEFAULT ''::character varying,
   "ext" varchar(5120) NOT NULL DEFAULT ''::character varying,
   "create_time" timestamp(6) NOT NULL DEFAULT now(),
   CONSTRAINT "scascade_alert_summarize_pkey" PRIMARY KEY ("id")
);
SELECT create_index_if_not_exists('scascade_alert_summarize', ARRAY['result_id','top_ccid'], '');

-- ----------------------------
-- Table structure for scascade_leak_ccid 漏洞分析-按控制中心统计
-- ----------------------------
CREATE TABLE IF NOT EXISTS scascade_leak_ccid (
  "id" SERIAL NOT NULL,
  "result_id" int4 NOT NULL DEFAULT 0,
  "data_type" int2 NOT NULL DEFAULT 0,
  "ccid" varchar(128) NOT NULL DEFAULT ''::character varying,
  "ccid_name" varchar(255) NOT NULL DEFAULT ''::character varying,
  "cli_count" int4 NOT NULL DEFAULT 0,
  "founds" int4 NOT NULL DEFAULT 0,
  "fixs" int4 NOT NULL DEFAULT 0,
  "ignores" int4 NOT NULL DEFAULT 0,
  "ext" varchar(512) NOT NULL DEFAULT ''::character varying,
  "create_time" timestamp(6) NOT NULL DEFAULT now(),
  CONSTRAINT "scascade_leak_ccid_pkey" PRIMARY KEY ("id")
);
SELECT create_index_if_not_exists('scascade_leak_ccid', ARRAY['result_id'], '');

-- ----------------------------
-- Table structure for scascade_leak_client 漏洞分析-按终端统计
-- ----------------------------
CREATE TABLE IF NOT EXISTS scascade_leak_client (
  "id" SERIAL NOT NULL,
  "result_id" int4 NOT NULL DEFAULT 0,
  "data_type" int2 NOT NULL DEFAULT 0,
  "client_mid" varchar(128) NOT NULL DEFAULT ''::character varying,
  "client_name" varchar(255) NOT NULL DEFAULT ''::character varying,
  "client_third_login_user" varchar(255) NOT NULL DEFAULT ''::character varying,
  "client_ip" varchar(128) NOT NULL DEFAULT ''::character varying,
  "client_mac" varchar(128) NOT NULL DEFAULT ''::character varying,
  "ccid" varchar(128) NOT NULL DEFAULT ''::character varying,
  "ccid_name" varchar(255) NOT NULL DEFAULT ''::character varying,
  "founds" int4 NOT NULL DEFAULT 0,
  "fixs" int4 NOT NULL DEFAULT 0,
  "ignores" int4 NOT NULL DEFAULT 0,
  "ext" varchar(512) NOT NULL DEFAULT ''::character varying,
  "create_time" timestamp(6) NOT NULL DEFAULT now(),
  CONSTRAINT "scascade_leak_client_pkey" PRIMARY KEY ("id")
);
SELECT create_index_if_not_exists('scascade_leak_client', ARRAY['result_id'], '');

-- ----------------------------
-- Table structure for scascade_leak_patch 漏洞分析-按漏洞统计
-- ----------------------------
CREATE TABLE IF NOT EXISTS scascade_leak_patch (
  "id" SERIAL NOT NULL,
  "result_id" int4 NOT NULL DEFAULT 0,
  "data_type" int2 NOT NULL DEFAULT 0,
  "kbid" varchar(128) NOT NULL DEFAULT ''::character varying,
  "leak_name" varchar(255) NOT NULL DEFAULT ''::character varying,
  "ccid" varchar(128) NOT NULL DEFAULT ''::character varying,
  "ccid_name" varchar(128) NOT NULL DEFAULT ''::character varying,
  "leak_type" int2 NOT NULL DEFAULT 0,
  "leak_type_desc" varchar(255) NOT NULL DEFAULT ''::character varying,
  "founds" int4 NOT NULL DEFAULT 0,
  "fixs" int4 NOT NULL DEFAULT 0,
  "ignores" int4 NOT NULL DEFAULT 0,
  "ext" varchar(512) NOT NULL DEFAULT ''::character varying,
  "create_time" timestamp(6) NOT NULL DEFAULT now(),
  CONSTRAINT "scascade_leak_patch_pkey" PRIMARY KEY ("id")
);
SELECT create_index_if_not_exists('scascade_leak_patch', ARRAY['result_id'], '');

-- ----------------------------
-- Table structure for scascade_leak_summarize 漏洞分析-汇总统计
-- ----------------------------
CREATE TABLE IF NOT EXISTS scascade_leak_summarize (
  "id" SERIAL NOT NULL,
  "result_id" int4 NOT NULL DEFAULT 0,
  "data_type" int2 NOT NULL DEFAULT 0,
  "top_ccid" varchar(64) NOT NULL DEFAULT ''::character varying,
  "ext" varchar(5120) NOT NULL DEFAULT ''::character varying,
  "create_time" timestamp(6) NOT NULL DEFAULT now(),
  CONSTRAINT "scascade_leak_summarize_pkey" PRIMARY KEY ("id")
);
SELECT create_index_if_not_exists('scascade_leak_summarize', ARRAY['result_id','top_ccid'], '');

-- ----------------------------
-- Table structure for scascade_score_ccid 扫描分数-按控制中心统计
-- ----------------------------
CREATE TABLE IF NOT EXISTS scascade_score_ccid (
  "id" SERIAL NOT NULL,
  "result_id" int4 NOT NULL DEFAULT 0,
  "data_type" int2 NOT NULL DEFAULT 0,
  "ccid" varchar(128) NOT NULL DEFAULT ''::character varying,
  "ccid_name" varchar(255) NOT NULL DEFAULT ''::character varying,
  "cli_count" int4 NOT NULL DEFAULT 0,
  "avg_score" float8 NOT NULL DEFAULT 0,
  "ext" varchar(512) NOT NULL DEFAULT ''::character varying,
  "create_time" timestamp(6) NOT NULL DEFAULT now(),
  CONSTRAINT "scascade_score_ccid_pkey" PRIMARY KEY ("id")
);
SELECT create_index_if_not_exists('scascade_score_ccid', ARRAY['result_id'], '');

-- ----------------------------
-- Table structure for scascade_score_summarize 扫描分数-汇总统计
-- ----------------------------
CREATE TABLE IF NOT EXISTS scascade_score_summarize (
  "id" SERIAL NOT NULL,
  "result_id" int4 NOT NULL DEFAULT 0,
  "top_ccid" varchar(64) NOT NULL DEFAULT ''::character varying,
  "data_type" int2 NOT NULL DEFAULT 0,
  "ext" varchar(5120) NOT NULL DEFAULT ''::character varying,
  "create_time" timestamp(6) NOT NULL DEFAULT now(),
  CONSTRAINT "scascade_score_summarize_pkey" PRIMARY KEY ("id")
);

SELECT create_index_if_not_exists('scascade_score_summarize', ARRAY['result_id','top_ccid'], '');

-- ----------------------------
-- Table structure for scascade_virus_ccid 病毒分析-按控制中心统计
-- ----------------------------
CREATE TABLE IF NOT EXISTS scascade_virus_ccid (
  "id" SERIAL NOT NULL,
  "result_id" int4 NOT NULL DEFAULT 0,
  "data_type" int2 NOT NULL DEFAULT 0,
  "ccid" varchar(128) NOT NULL DEFAULT ''::character varying,
  "ccid_name" varchar(255) NOT NULL DEFAULT ''::character varying,
  "cli_count" int4 NOT NULL DEFAULT 0,
  "all_kills" int4 NOT NULL DEFAULT 0,
  "monitor_kills" int4 NOT NULL DEFAULT 0,
  "user_kills" int4 NOT NULL DEFAULT 0,
  "admin_kills" int4 NOT NULL DEFAULT 0,
  "ext" varchar(512) NOT NULL DEFAULT ''::character varying,
  "create_time" timestamp(6) NOT NULL DEFAULT now(),
  CONSTRAINT "scascade_virus_ccid_pkey" PRIMARY KEY ("id")
);
SELECT create_index_if_not_exists('scascade_virus_ccid', ARRAY['result_id'], '');

-- ----------------------------
-- Table structure for scascade_virus_client 病毒分析-按终端统计
-- ----------------------------
CREATE TABLE IF NOT EXISTS scascade_virus_client (
  "id" SERIAL NOT NULL,
  "result_id" int4 NOT NULL DEFAULT 0,
  "data_type" int2 NOT NULL DEFAULT 0,
  "client_mid" varchar(128) NOT NULL DEFAULT ''::character varying,
  "client_name" varchar(255) NOT NULL DEFAULT ''::character varying,
  "client_third_login_user" varchar(255) NOT NULL DEFAULT ''::character varying,
  "client_ip" varchar(128) NOT NULL DEFAULT ''::character varying,
  "client_mac" varchar(128) NOT NULL DEFAULT ''::character varying,
  "ccid" varchar(128) NOT NULL DEFAULT ''::character varying,
  "ccid_name" varchar(255) NOT NULL DEFAULT ''::character varying,
  "all_kills" int4 NOT NULL DEFAULT 0,
  "monitor_kills" int4 NOT NULL DEFAULT 0,
  "user_kills" int4 NOT NULL DEFAULT 0,
  "admin_kills" int4 NOT NULL DEFAULT 0,
  "ext" varchar(512) NOT NULL DEFAULT ''::character varying,
  "create_time" timestamp(6) NOT NULL DEFAULT now(),
  CONSTRAINT "scascade_virus_client_pkey" PRIMARY KEY ("id")
);
SELECT create_index_if_not_exists('scascade_virus_client', ARRAY['result_id'], '');

-- ----------------------------
-- Table structure for scascade_virus_name 病毒分析-按病毒名统计
-- ----------------------------
CREATE TABLE IF NOT EXISTS scascade_virus_name (
  "id" SERIAL NOT NULL,
  "result_id" int4 NOT NULL DEFAULT 0,
  "data_type" int2 NOT NULL DEFAULT 0,
  "vname" varchar(255) NOT NULL DEFAULT ''::character varying,
  "virus_cat" int2 NOT NULL DEFAULT 0,
  "virus_cat_desc" varchar(255) NOT NULL DEFAULT ''::character varying,
  "cli_count" int4 NOT NULL DEFAULT 0,
  "all_kills" int4 NOT NULL DEFAULT 0,
  "monitor_kills" int4 NOT NULL DEFAULT 0,
  "user_kills" int4 NOT NULL DEFAULT 0,
  "admin_kills" int4 NOT NULL DEFAULT 0,
  "ccid" varchar(128) NOT NULL DEFAULT ''::character varying,
  "ext" varchar(512) NOT NULL DEFAULT ''::character varying,
  "create_time" timestamp(6) NOT NULL DEFAULT now(),
  CONSTRAINT "scascade_virus_name_pkey" PRIMARY KEY ("id")
);
SELECT create_index_if_not_exists('scascade_virus_name', ARRAY['result_id'], '');

-- ----------------------------
-- Table structure for scascade_virus_summarize 病毒分析-汇总统计
-- ----------------------------
CREATE TABLE IF NOT EXISTS scascade_virus_summarize (
  "id" SERIAL NOT NULL,
  "result_id" int4 NOT NULL DEFAULT 0,
  "top_ccid" varchar(64) NOT NULL DEFAULT ''::character varying,
  "data_type" int2 NOT NULL DEFAULT 0,
  "ext" varchar(5120) NOT NULL DEFAULT ''::character varying,
  "create_time" timestamp(6) NOT NULL DEFAULT now(),
  CONSTRAINT "scascade_virus_summarize_pkey" PRIMARY KEY ("id")
);
SELECT create_index_if_not_exists('scascade_virus_summarize', ARRAY['result_id'], '');
SELECT create_index_if_not_exists('scascade_virus_summarize', ARRAY['result_id','top_ccid'], '');


-- ----------------------------
-- Table structure for assets 资产汇总
-- ----------------------------
CREATE TABLE IF NOT EXISTS assets (
  "id" SERIAL NOT NULL,
  "client_mid" varchar(64) NOT NULL DEFAULT ''::character varying,
  "client_name" varchar(255) NOT NULL DEFAULT ''::character varying,
  "client_ip" inet,
  "client_report_ip" inet,
  "client_mac" varchar(64) NOT NULL DEFAULT ''::character varying,
  "client_gid" int4 NOT NULL DEFAULT 0,
  "client_group_name" varchar(128) NOT NULL DEFAULT ''::character varying,
  "client_group_path" text NOT NULL DEFAULT ''::text,
  "ccid" varchar(128) NOT NULL DEFAULT ''::character varying,
  "last_time" timestamp(6),
  "ext_main_ver" varchar(64),
  "ext_virus_lib_date" int4,
  "ext_leaklib_ver" varchar(64),
  "client_os" varchar(64),
  "nac_user_user_name" varchar(255),
  "nac_user_full_name" varchar(255),
  "client_login_user" varchar(255),
  "client_os_domain_name" varchar(255),
  "client_type" int4,
  "client_os_small_version" text,
  "client_os_edition_id" text,
  "client_os_small_version_edition_id" text,
  "hardware_summary_device_type" int4,
  "hardware_summary_description" text,
  "hardware_summary_cpu" text,
  "hardware_summary_memory" text,
  "hardware_summary_harddisk" text,
  "hardware_summary_displaycard" text,
  "hardware_summary_monitor" text,
  "hardware_harddisk_serial_number" text,
  "hardware_summary_serial_number" text,
  "os_lang" varchar(255),
  "os_osspa" varchar(255),
  "os_install_date" timestamp(6),
  "hardware_summary_device_use" varchar(255) DEFAULT ''::character varying,
  "hardware_summary_username" varchar(255) DEFAULT ''::character varying,
  "hardware_summary_user_number" varchar(255) NOT NULL DEFAULT ''::character varying,
  "hardware_summary_mobile" varchar(128) NOT NULL DEFAULT ''::character varying,
  "hardware_summary_email" varchar(255) DEFAULT ''::character varying,
  "hardware_summary_location" text DEFAULT ''::text,
  "hardware_summary_telephone" varchar(128) DEFAULT ''::character varying,
  "hardware_summary_memo" text DEFAULT ''::text,
  "client_hardware_cpu_core_count" int4 NOT NULL DEFAULT 0,
  "client_hardware_cpu_frequency" float4 NOT NULL DEFAULT 0,
  "client_hardware_harddisk_size" int4 NOT NULL DEFAULT 0,
  "client_hardware_memory_size" int4 NOT NULL DEFAULT 0,
  "client_hardware_monitor_size" float4 NOT NULL DEFAULT 0,
  CONSTRAINT "assets_pkey" PRIMARY KEY ("id")
);
SELECT create_index_if_not_exists('assets', ARRAY['ccid'], '');