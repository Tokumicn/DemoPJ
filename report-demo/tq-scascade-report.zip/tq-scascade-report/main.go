package main

import (
	"errors"
	"fmt"
	"git-biz.qianxin-inc.cn/eps/skylar/apps/libs/tianqing.git/logs"
	"log"
	"os"
	"os/signal"
	"strconv"
	"sync"
	"syscall"
	"time"
	"tq-scascade-report/pkg/clickhouse"
	"tq-scascade-report/pkg/config"
	"tq-scascade-report/pkg/postgres"
	"tq-scascade-report/pkg/redis"
	"tq-scascade-report/pkg/tools"
	"tq-scascade-report/service/cascade_config"
	"tq-scascade-report/setup"
)

const (
	CONFIGPATH   = `.` + string(os.PathSeparator) + `config` + string(os.PathSeparator) + `reportjob.conf`
	ZONEINFOPATH = `.` + string(os.PathSeparator) + `config` + string(os.PathSeparator) + `zoneinfo.zip`
)

func main() {

	err := syscall.Setenv("ZONEINFO", ZONEINFOPATH)
	if err != nil {
		log.Print(err)
	}

	// 初始化配置文件
	config.InitialConfig(CONFIGPATH)

	// log Init
	// logsInit()
	logs.Init(config.Cfg().LogConfig)

	// 通过配置文件中天擎的Redis获取多级级联配置信息
	redis.InitRedis(config.Cfg().RedisConf)
	defer redis.Close()

	// 获取级联配置信息
	CascadeConfigUntilEnable()

	setup.ServerInit()
	defer postgres.Close()
	defer clickhouse.Close()

	logs.Info("报表服务启动完成,开始提供服务...")
	CascadeConfigEnableChange()
	//Exit("Scascade Report Service Exit. Bye...")
}

func Exit(msg string) {
	chExit := make(chan os.Signal, 1)
	signal.Notify(chExit, syscall.SIGINT, syscall.SIGTERM, syscall.SIGKILL)
	select {
	case <-chExit:
		logs.Info(msg)
	}
}

var (
	once sync.Once
)

func CascadeConfigUntilEnable() {
	once.Do(func() {
		interval := config.Cfg().ServerConf.Interval
		tick := time.Tick(time.Duration(interval) * time.Second)
		for {
			// 通过级联配置接口获取配置信息
			ascadeConf, err := cascade_config.GetCascadeConfig()
			if err != nil {
				logs.Debugf("获取级联配置信息失败, 服务无法正常启动. [err: %s]", err.Error())
				ascadeConf = &cascade_config.CascadeConfig{
					Enabled: 0,
				}
			}

			select {
			case <-tick:
				if ascadeConf.Enabled == 1 {

					// 最下级不使用报表服务，因此相关配置无法支持初始化完毕，需要轮空
					if ascadeConf.NodeLevel <= 1 {
						logs.Debug("当前为最下级级联节点，报表服务不开启...等待下次配置更新", time.Now())
					} else {
						err = checkConfig(ascadeConf)
						if err != nil {
							logs.Debug("级联配置检查未通过. err: %s", err.Error())
							continue
						}
						goto EnableGoto
					}
				} else {
					logs.Debug("级联功能未开启...等待下次配置更新", time.Now())
				}
			}
		}

	EnableGoto:
		logs.Debug("级联功能开启，开始初始化...")
	})
}

func checkConfig(conf *cascade_config.CascadeConfig) error {

	if conf.LogDBPort <= 0 ||
		len(conf.LogDBHost) <= 0 ||
		conf.PGPort <= 0 ||
		len(conf.PGHost) <= 0 {
		return errors.New("获取级联配置信息有误 pg clickhouse 配置为空.")
	}

	// 更新多级级联PG配置
	if config.Cfg().PGConf != nil {
		config.Cfg().PGConf.Port = strconv.Itoa(conf.PGPort)
		config.Cfg().PGConf.Host = conf.PGHost
		config.Cfg().PGConf.User = conf.PGUser

		pgPass, err := tools.Base64Decode(conf.PGPassword)
		if err == nil {
			config.Cfg().PGConf.Password = pgPass
		}

		if len(config.Cfg().PGConf.User) <= 0 {
			config.Cfg().PGConf.User = "postgres"
		}

		if len(config.Cfg().PGConf.Password) <= 0 {
			config.Cfg().PGConf.Password = "postgres"
		}
	}

	// 更新多级级联ClickHouse配置
	if config.Cfg().CHConf != nil {
		config.Cfg().CHConf.Host = fmt.Sprintf("%s:%d", conf.LogDBHost, conf.LogDBPort)
		config.Cfg().CHConf.User = conf.LogDBUser

		logDBPass, err := tools.Base64Decode(conf.LogDBPassword)
		if err == nil {
			config.Cfg().CHConf.Password = logDBPass
		}
	}
	return nil
}

func CascadeConfigEnableChange() {
	interval := config.Cfg().ServerConf.Interval
	tick := time.Tick(time.Duration(interval) * time.Second)
	for {
		// 通过级联配置接口获取配置信息
		ascadeConf, err := cascade_config.GetCascadeConfig()
		if err != nil {
			logs.Error(err)
			continue
		}

		if ascadeConf == nil {
			continue
		}

		select {
		case <-tick:
			if ascadeConf.Enabled == 0 {
				logs.Warnf("根据级联配置，正常关闭服务")
				os.Exit(1)
			}
		}
	}
}
