-- 自定义查询相关表

-- 自定义列
CREATE TABLE "public"."query_custom_column" (
   "id" SERIAL NOT NULL,
   "business_code" varchar(128) COLLATE "pg_catalog"."default" NOT NULL DEFAULT ''::character varying,
   "table_name" varchar(128) COLLATE "pg_catalog"."default" NOT NULL DEFAULT ''::character varying,
   "custom_column" varchar(5120) COLLATE "pg_catalog"."default" NOT NULL DEFAULT ''::character varying,
   "optional_column" varchar(5120) COLLATE "pg_catalog"."default" NOT NULL DEFAULT ''::character varying,
   "create_time" timestamp(0) NOT NULL DEFAULT now(),
   "update_time" timestamp(0) NOT NULL DEFAULT now(),
   CONSTRAINT "query_custom_column_pkey" PRIMARY KEY ("id")
);

ALTER TABLE "public"."query_custom_column"
    OWNER TO "postgres";

COMMENT ON COLUMN "public"."query_custom_column"."business_code" IS '所属业务标识';
COMMENT ON COLUMN "public"."query_custom_column"."table_name" IS '表名';
COMMENT ON COLUMN "public"."query_custom_column"."custom_column" IS '已选自定义列';
COMMENT ON COLUMN "public"."query_custom_column"."optional_column" IS '可选自定义列';


-- 自定义查询模板
CREATE TABLE "public"."query_condition_tlp" (
  "id" SERIAL NOT NULL,
  "name" varchar(128) COLLATE "pg_catalog"."default" NOT NULL DEFAULT ''::character varying,
  "business_code" varchar(128) COLLATE "pg_catalog"."default" NOT NULL DEFAULT ''::character varying,
  "conditions" varchar(5120) COLLATE "pg_catalog"."default" NOT NULL DEFAULT ''::character varying,
  "relation_tlp" varchar(512) COLLATE "pg_catalog"."default" NOT NULL DEFAULT ''::character varying,
  "create_time" timestamp(0) NOT NULL DEFAULT now(),
  "update_time" timestamp(0) NOT NULL DEFAULT now(),
  CONSTRAINT "query_condition_tlp_pkey" PRIMARY KEY ("id")
);

ALTER TABLE "public"."query_condition_tlp"
    OWNER TO "postgres";

COMMENT ON COLUMN "public"."query_condition_tlp"."name" IS '模板名';
COMMENT ON COLUMN "public"."query_condition_tlp"."business_code" IS '所属业务标识';
COMMENT ON COLUMN "public"."query_condition_tlp"."conditions" IS '高级搜索条件选项JSON';
COMMENT ON COLUMN "public"."query_condition_tlp"."relation_tlp" IS '高级搜索条件关系模板';