-- 告警事件报表相关

-- 汇总统计
CREATE TABLE "public"."scascade_alert_summarize" (
   "id" SERIAL NOT NULL,
   "result_id" int4 NOT NULL DEFAULT 0,
   "data_type" int2 NOT NULL DEFAULT 0,
   "top_ccid" varchar(64) COLLATE "pg_catalog"."default" NOT NULL DEFAULT ''::character varying,
   "ext" varchar(5120) COLLATE "pg_catalog"."default" NOT NULL DEFAULT ''::character varying,
   "create_time" timestamp(0) NOT NULL DEFAULT now(),
   CONSTRAINT "scascade_alert_summarize_pkey" PRIMARY KEY ("id")
);

ALTER TABLE "public"."scascade_alert_summarize"
  OWNER TO "postgres";

CREATE INDEX "alert_sum_result" ON "public"."scascade_alert_summarize" USING btree (
   "result_id" "pg_catalog"."int4_ops" ASC NULLS LAST
);

CREATE INDEX "alert_sum_topccid" ON "public"."scascade_alert_summarize" USING btree (
   "result_id" "pg_catalog"."int4_ops" ASC NULLS LAST,
   "top_ccid" COLLATE "pg_catalog"."default" "pg_catalog"."text_ops" ASC NULLS LAST
);

COMMENT ON COLUMN "public"."scascade_alert_summarize"."result_id" IS '结果集Id';
COMMENT ON COLUMN "public"."scascade_alert_summarize"."data_type" IS '数据类型标识';
COMMENT ON COLUMN "public"."scascade_alert_summarize"."top_ccid" IS '顶部节点CCId查询标识';
COMMENT ON COLUMN "public"."scascade_alert_summarize"."ext" IS '扩展字段预留';
COMMENT ON COLUMN "public"."scascade_alert_summarize"."create_time" IS '创建时间';
COMMENT ON TABLE "public"."scascade_alert_summarize" IS '数据级联-汇总统计表';