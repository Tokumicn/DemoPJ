-- 扫描分数报表相关

-- 扫描分数-汇总统计
CREATE TABLE "public"."scascade_score_summarize" (
  "id" SERIAL NOT NULL,
  "result_id" int4 NOT NULL DEFAULT 0,
  "top_ccid" varchar(64) COLLATE "pg_catalog"."default" NOT NULL DEFAULT ''::character varying,
  "data_type" int2 NOT NULL DEFAULT 0,
  "ext" varchar(5120) COLLATE "pg_catalog"."default" NOT NULL DEFAULT ''::character varying,
  "create_time" timestamp(0) NOT NULL DEFAULT now(),
  CONSTRAINT "scascade_score_summarize_pkey" PRIMARY KEY ("id")
)
;

ALTER TABLE "public"."scascade_score_summarize"
    OWNER TO "postgres";

CREATE INDEX "score_sum_result" ON "public"."scascade_score_summarize" USING btree (
  "result_id" "pg_catalog"."int4_ops" ASC NULLS LAST
);

CREATE INDEX "score_sum_topccid" ON "public"."scascade_score_summarize" USING btree (
   "result_id" "pg_catalog"."int4_ops" ASC NULLS LAST,
   "top_ccid" COLLATE "pg_catalog"."default" "pg_catalog"."text_ops" ASC NULLS LAST
);

COMMENT ON COLUMN "public"."scascade_score_summarize"."result_id" IS '结果集Id';
COMMENT ON COLUMN "public"."scascade_score_summarize"."top_ccid" IS '顶部节点CCId';
COMMENT ON COLUMN "public"."scascade_score_summarize"."data_type" IS '数据类型标识';
COMMENT ON COLUMN "public"."scascade_score_summarize"."ext" IS '扩展字段预留';
COMMENT ON COLUMN "public"."scascade_score_summarize"."create_time" IS '创建时间';
COMMENT ON TABLE "public"."scascade_score_summarize" IS '数据级联-汇总统计表';


-- 扫描分数-按控制中心统计
CREATE TABLE "public"."scascade_score_ccid" (
  "id" SERIAL NOT NULL,
  "result_id" int4 NOT NULL DEFAULT 0,
  "data_type" int2 NOT NULL DEFAULT 0,
  "ccid" varchar(128) COLLATE "pg_catalog"."default" NOT NULL DEFAULT ''::character varying,
  "ccid_name" varchar(255) COLLATE "pg_catalog"."default" NOT NULL DEFAULT ''::character varying,
  "cli_count" int4 NOT NULL DEFAULT 0,
  "avg_score" float8 NOT NULL DEFAULT 0,
  "ext" varchar(512) COLLATE "pg_catalog"."default" NOT NULL DEFAULT ''::character varying,
  "create_time" timestamp(6) NOT NULL DEFAULT now(),
  CONSTRAINT "scascade_score_ccid_pkey" PRIMARY KEY ("id")
);

ALTER TABLE "public"."scascade_score_ccid"
  OWNER TO "postgres";

CREATE INDEX "score_ccid_result" ON "public"."scascade_score_ccid" USING btree (
  "result_id" "pg_catalog"."int4_ops" ASC NULLS LAST
);

COMMENT ON COLUMN "public"."scascade_score_ccid"."result_id" IS '结果集Id';
COMMENT ON COLUMN "public"."scascade_score_ccid"."data_type" IS '数据类型标识';
COMMENT ON COLUMN "public"."scascade_score_ccid"."ccid" IS '控制中心';
COMMENT ON COLUMN "public"."scascade_score_ccid"."ccid_name" IS '控制中心名';
COMMENT ON COLUMN "public"."scascade_score_ccid"."cli_count" IS '终端数量';
COMMENT ON COLUMN "public"."scascade_score_ccid"."avg_score" IS '平均分';
COMMENT ON COLUMN "public"."scascade_score_ccid"."ext" IS '扩展字段预留，不参与排序和查询的扩展';