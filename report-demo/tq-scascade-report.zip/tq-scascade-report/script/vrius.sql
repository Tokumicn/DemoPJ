-- 病毒分析报表相关

-- 病毒分析-汇总统计
CREATE TABLE "public"."scascade_virus_summarize" (
  "id" SERIAL NOT NULL,
  "result_id" int4 NOT NULL DEFAULT 0,
  "top_ccid" varchar(64) COLLATE "pg_catalog"."default" NOT NULL DEFAULT ''::character varying,
  "data_type" int2 NOT NULL DEFAULT 0,
  "ext" varchar(5120) COLLATE "pg_catalog"."default" NOT NULL DEFAULT ''::character varying,
  "create_time" timestamp(0) NOT NULL DEFAULT now(),
  CONSTRAINT "scascade_virus_summarize_pkey" PRIMARY KEY ("id")
);

ALTER TABLE "public"."scascade_virus_summarize" OWNER TO "postgres";

CREATE INDEX "virus_sum_result" ON "public"."scascade_virus_summarize" USING btree (
  "result_id" "pg_catalog"."int4_ops" ASC NULLS LAST
);

CREATE INDEX "virus_sum_topccid" ON "public"."scascade_virus_summarize" USING btree (
   "result_id" "pg_catalog"."int4_ops" ASC NULLS LAST,
   "top_ccid" COLLATE "pg_catalog"."default" "pg_catalog"."text_ops" ASC NULLS LAST
);

COMMENT ON COLUMN "public"."scascade_virus_summarize"."result_id" IS '结果集Id';
COMMENT ON COLUMN "public"."scascade_virus_summarize"."top_ccid" IS '顶部节点CCId';
COMMENT ON COLUMN "public"."scascade_virus_summarize"."data_type" IS '数据类型标识';
COMMENT ON COLUMN "public"."scascade_virus_summarize"."ext" IS '扩展字段预留';
COMMENT ON COLUMN "public"."scascade_virus_summarize"."create_time" IS '创建时间';
COMMENT ON TABLE "public"."scascade_virus_summarize" IS '数据级联-病毒分析汇总统计表';

-- 病毒分析-按控制中心统计
CREATE TABLE "public"."scascade_virus_ccid" (
  "id" SERIAL NOT NULL,
  "result_id" int4 NOT NULL DEFAULT 0,
  "data_type" int2 NOT NULL DEFAULT 0,
  "ccid" varchar(128) COLLATE "pg_catalog"."default" NOT NULL DEFAULT ''::character varying,
  "ccid_name" varchar(255) COLLATE "pg_catalog"."default" NOT NULL DEFAULT ''::character varying,
  "cli_count" int4 NOT NULL DEFAULT 0,
  "all_kills" int4 NOT NULL DEFAULT 0,
  "monitor_kills" int4 NOT NULL DEFAULT 0,
  "user_kills" int4 NOT NULL DEFAULT 0,
  "admin_kills" int4 NOT NULL DEFAULT 0,
  "ext" varchar(512) COLLATE "pg_catalog"."default" NOT NULL DEFAULT ''::character varying,
  "create_time" timestamp(6) NOT NULL DEFAULT now(),
  CONSTRAINT "scascade_virus_ccid_pkey" PRIMARY KEY ("id")
);

ALTER TABLE "public"."scascade_virus_ccid" OWNER TO "postgres";

CREATE INDEX "virus_ccid_result" ON "public"."scascade_virus_ccid" USING btree (
  "result_id" "pg_catalog"."int4_ops" ASC NULLS LAST
);

COMMENT ON COLUMN "public"."scascade_virus_ccid"."result_id" IS '结果集Id';
COMMENT ON COLUMN "public"."scascade_virus_ccid"."data_type" IS '数据类型标识';
COMMENT ON COLUMN "public"."scascade_virus_ccid"."ccid" IS '控制中心';
COMMENT ON COLUMN "public"."scascade_virus_ccid"."ccid_name" IS '控制中心名';
COMMENT ON COLUMN "public"."scascade_virus_ccid"."cli_count" IS '终端数量';
COMMENT ON COLUMN "public"."scascade_virus_ccid"."all_kills" IS '总查杀数';
COMMENT ON COLUMN "public"."scascade_virus_ccid"."monitor_kills" IS '监控查杀数';
COMMENT ON COLUMN "public"."scascade_virus_ccid"."user_kills" IS '用户查杀数';
COMMENT ON COLUMN "public"."scascade_virus_ccid"."admin_kills" IS '管理员查杀数';
COMMENT ON COLUMN "public"."scascade_virus_ccid"."ext" IS '扩展字段预留，不参与排序和查询的扩展';


-- 病毒分析-按终端统计
CREATE TABLE "public"."scascade_virus_client" (
  "id" SERIAL NOT NULL,
  "result_id" int4 NOT NULL DEFAULT 0,
  "data_type" int2 NOT NULL DEFAULT 0,
  "client_mid" varchar(128) COLLATE "pg_catalog"."default" NOT NULL DEFAULT ''::character varying,
  "client_name" varchar(255) COLLATE "pg_catalog"."default" NOT NULL DEFAULT ''::character varying,
  "client_third_login_user" varchar(255) COLLATE "pg_catalog"."default" NOT NULL DEFAULT ''::character varying,
  "client_ip" varchar(128) COLLATE "pg_catalog"."default" NOT NULL DEFAULT ''::character varying,
  "client_mac" varchar(128) COLLATE "pg_catalog"."default" NOT NULL DEFAULT ''::character varying,
  "ccid" varchar(128) COLLATE "pg_catalog"."default" NOT NULL DEFAULT ''::character varying,
  "ccid_name" varchar(255) COLLATE "pg_catalog"."default" NOT NULL DEFAULT ''::character varying,
  "all_kills" int4 NOT NULL DEFAULT 0,
  "monitor_kills" int4 NOT NULL DEFAULT 0,
  "user_kills" int4 NOT NULL DEFAULT 0,
  "admin_kills" int4 NOT NULL DEFAULT 0,
  "ext" varchar(512) COLLATE "pg_catalog"."default" NOT NULL DEFAULT ''::character varying,
  "create_time" timestamp(6) NOT NULL DEFAULT now(),
  CONSTRAINT "scascade_virus_client_pkey" PRIMARY KEY ("id")
);

ALTER TABLE "public"."scascade_virus_client" OWNER TO "postgres";

CREATE INDEX "virus_client_result" ON "public"."scascade_virus_client" USING btree (
  "result_id" "pg_catalog"."int4_ops" ASC NULLS LAST
);

COMMENT ON COLUMN "public"."scascade_virus_client"."result_id" IS '结果集Id';
COMMENT ON COLUMN "public"."scascade_virus_client"."data_type" IS '数据类型标识';
COMMENT ON COLUMN "public"."scascade_virus_client"."client_mid" IS '终端标识';
COMMENT ON COLUMN "public"."scascade_virus_client"."client_name" IS '终端名';
COMMENT ON COLUMN "public"."scascade_virus_client"."client_third_login_user" IS '实名认证登录账号';
COMMENT ON COLUMN "public"."scascade_virus_client"."client_ip" IS '终端ip';
COMMENT ON COLUMN "public"."scascade_virus_client"."client_mac" IS '终端mac';
COMMENT ON COLUMN "public"."scascade_virus_client"."ccid" IS '控制中心';
COMMENT ON COLUMN "public"."scascade_virus_client"."ccid_name" IS '控制中心名';
COMMENT ON COLUMN "public"."scascade_virus_client"."all_kills" IS '总查杀数';
COMMENT ON COLUMN "public"."scascade_virus_client"."monitor_kills" IS '监控查杀数';
COMMENT ON COLUMN "public"."scascade_virus_client"."user_kills" IS '用户查杀数';
COMMENT ON COLUMN "public"."scascade_virus_client"."admin_kills" IS '管理员查杀数';
COMMENT ON COLUMN "public"."scascade_virus_client"."ext" IS '扩展字段预留，不参与排序和查询的扩展';



-- 病毒分析-按病毒名统计
CREATE TABLE "public"."scascade_virus_name" (
  "id" SERIAL NOT NULL,
  "result_id" int4 NOT NULL DEFAULT 0,
  "data_type" int2 NOT NULL DEFAULT 0,
  "vname" varchar(255) COLLATE "pg_catalog"."default" NOT NULL DEFAULT ''::character varying,
  "virus_cat" int2 NOT NULL DEFAULT 0,
  "virus_cat_desc" varchar(255) COLLATE "pg_catalog"."default" NOT NULL DEFAULT ''::character varying,
  "cli_count" int4 NOT NULL DEFAULT 0,
  "all_kills" int4 NOT NULL DEFAULT 0,
  "monitor_kills" int4 NOT NULL DEFAULT 0,
  "user_kills" int4 NOT NULL DEFAULT 0,
  "admin_kills" int4 NOT NULL DEFAULT 0,
  "ccid" varchar(128) COLLATE "pg_catalog"."default" NOT NULL DEFAULT ''::character varying,
  "ext" varchar(512) COLLATE "pg_catalog"."default" NOT NULL DEFAULT ''::character varying,
  "create_time" timestamp(6) NOT NULL DEFAULT now(),
  CONSTRAINT "scascade_virus_name_pkey" PRIMARY KEY ("id")
);

ALTER TABLE "public"."scascade_virus_name" OWNER TO "postgres";

CREATE INDEX "virus_name_result" ON "public"."scascade_virus_name" USING btree (
  "result_id" "pg_catalog"."int4_ops" ASC NULLS LAST
);

COMMENT ON COLUMN "public"."scascade_virus_name"."result_id" IS '结果集Id';
COMMENT ON COLUMN "public"."scascade_virus_name"."data_type" IS '数据类型标识';
COMMENT ON COLUMN "public"."scascade_virus_name"."vname" IS '病毒名';
COMMENT ON COLUMN "public"."scascade_virus_name"."virus_cat" IS '病毒类型';
COMMENT ON COLUMN "public"."scascade_virus_name"."virus_cat_desc" IS '病毒类型中文';
COMMENT ON COLUMN "public"."scascade_virus_name"."cli_count" IS '终端数';
COMMENT ON COLUMN "public"."scascade_virus_name"."all_kills" IS '总查杀数';
COMMENT ON COLUMN "public"."scascade_virus_name"."monitor_kills" IS '监控查杀数';
COMMENT ON COLUMN "public"."scascade_virus_name"."user_kills" IS '用户查杀数';
COMMENT ON COLUMN "public"."scascade_virus_name"."admin_kills" IS '管理员查杀数';
COMMENT ON COLUMN "public"."scascade_virus_name"."ccid" IS '控制中心';
COMMENT ON COLUMN "public"."scascade_virus_name"."ext" IS '扩展字段预留，不参与排序和查询的扩展';
