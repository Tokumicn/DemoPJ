-- 定时任务表
CREATE TABLE "public"."cron_task" (
  "id" SERIAL NOT NULL,
  "name" varchar(50) COLLATE "pg_catalog"."default" NOT NULL DEFAULT ''::character varying,
  "job_name" varchar(32) COLLATE "pg_catalog"."default" NOT NULL DEFAULT ''::character varying,
  "business" varchar(16) COLLATE "pg_catalog"."default" NOT NULL DEFAULT ''::character varying,
  "report_types" varchar(128) COLLATE "pg_catalog"."default" NOT NULL DEFAULT ''::character varying,
  "cron_type" varchar(16) COLLATE "pg_catalog"."default" NOT NULL DEFAULT ''::character varying,
  "top_ccid" varchar(64) COLLATE "pg_catalog"."default" NOT NULL DEFAULT ''::character varying,
  "ccids_tree" varchar(5120) COLLATE "pg_catalog"."default" NOT NULL DEFAULT ''::character varying,
  "raw_tree" varchar(5120) COLLATE "pg_catalog"."default" NOT NULL DEFAULT ''::character varying,
  "data_cover" bool NOT NULL DEFAULT false,
  "day" int2 NOT NULL DEFAULT 0,
  "hours" int2 NOT NULL DEFAULT 0,
  "minutes" int2 NOT NULL DEFAULT 0,
  "time_scale" varchar(32) COLLATE "pg_catalog"."default" NOT NULL DEFAULT ''::character varying,
  "time_range" varchar(32) COLLATE "pg_catalog"."default" NOT NULL DEFAULT ''::character varying,
  "start_time" varchar(32) COLLATE "pg_catalog"."default" NOT NULL DEFAULT ''::character varying,
  "end_time" varchar(32) COLLATE "pg_catalog"."default" NOT NULL DEFAULT ''::character varying,
  "create_time" timestamp(6) NOT NULL DEFAULT now(),
  "update_time" timestamp(6) NOT NULL DEFAULT now(),
  CONSTRAINT "cron_task_pkey" PRIMARY KEY ("id")
);

ALTER TABLE "public"."cron_task"
    OWNER TO "postgres";

COMMENT ON COLUMN "public"."cron_task"."name" IS '任务名';
COMMENT ON COLUMN "public"."cron_task"."business" IS '所属业务';
COMMENT ON COLUMN "public"."cron_task"."report_types" IS '报表类型';
COMMENT ON COLUMN "public"."cron_task"."cron_type" IS '定时类型';
COMMENT ON COLUMN "public"."cron_task"."top_ccid" IS '控制中心筛选范围';
COMMENT ON COLUMN "public"."cron_task"."ccids_tree" IS '控制中心JSON树';
COMMENT ON COLUMN "public"."cron_task"."raw_tree" IS '控制中心原始树停服Load使用';
COMMENT ON COLUMN "public"."cron_task"."day" IS '天';
COMMENT ON COLUMN "public"."cron_task"."hours" IS '小时';
COMMENT ON COLUMN "public"."cron_task"."minutes" IS '分钟';
COMMENT ON COLUMN "public"."cron_task"."data_cover" IS '是否覆盖';
COMMENT ON COLUMN "public"."cron_task"."start_time" IS '查询范围--开始时间';
COMMENT ON COLUMN "public"."cron_task"."end_time" IS '查询范围--结束时间';
COMMENT ON COLUMN "public"."cron_task"."time_scale" IS '时间刻度';
COMMENT ON COLUMN "public"."cron_task"."job_name" IS '任务执行名';



-- 定时任务查询结果记录表
CREATE TABLE "public"."cron_task_result" (
  "id" SERIAL NOT NULL,
  "task_id" int4 NOT NULL DEFAULT 0,
  "task_name" varchar(128) COLLATE "pg_catalog"."default" NOT NULL DEFAULT ''::character varying,
  "cron_expr" varchar(128) COLLATE "pg_catalog"."default" NOT NULL DEFAULT ''::character varying,
  "condition" varchar(512) COLLATE "pg_catalog"."default" NOT NULL DEFAULT ''::character varying,
  "raw_tree" varchar(5120) COLLATE "pg_catalog"."default" NOT NULL DEFAULT ''::character varying,
  "plan_start_time" timestamp(6) NOT NULL DEFAULT now(),
  "real_start_time" timestamp(6) NOT NULL DEFAULT now(),
  "finish_time" timestamp(6) NOT NULL DEFAULT now(),
  CONSTRAINT "cron_task_result_pkey" PRIMARY KEY ("id")
);

ALTER TABLE "public"."cron_task_result"
    OWNER TO "postgres";

CREATE INDEX "taskid_inx" ON "public"."cron_task_result" USING btree (
  "task_id" "pg_catalog"."int4_ops" ASC NULLS LAST
);

COMMENT ON COLUMN "public"."cron_task_result"."task_id" IS '任务id';
COMMENT ON COLUMN "public"."cron_task_result"."task_name" IS '任务名';
COMMENT ON COLUMN "public"."cron_task_result"."cron_expr" IS '定时任务表达式';
COMMENT ON COLUMN "public"."cron_task_result"."condition" IS '用户查询参数';
COMMENT ON COLUMN "public"."cron_task_result"."raw_tree" IS '控制中心树快照';


