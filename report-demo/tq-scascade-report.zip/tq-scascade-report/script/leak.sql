-- 漏洞分析报表相关

-- 漏洞分析-汇总统计
CREATE TABLE "public"."scascade_leak_summarize" (
  "id" SERIAL NOT NULL,
  "result_id" int4 NOT NULL DEFAULT 0,
  "data_type" int2 NOT NULL DEFAULT 0,
  "top_ccid" varchar(64) COLLATE "pg_catalog"."default" NOT NULL DEFAULT ''::character varying,
  "ext" varchar(5120) COLLATE "pg_catalog"."default" NOT NULL DEFAULT ''::character varying,
  "create_time" timestamp(0) NOT NULL DEFAULT now(),
  CONSTRAINT "scascade_leak_summarize_pkey" PRIMARY KEY ("id")
);

ALTER TABLE "public"."scascade_leak_summarize" OWNER TO "postgres";

CREATE INDEX "leak_sum_result" ON "public"."scascade_leak_summarize" USING btree (
  "result_id" "pg_catalog"."int4_ops" ASC NULLS LAST
);

CREATE INDEX "leak_sum_topccid" ON "public"."scascade_leak_summarize" USING btree (
   "result_id" "pg_catalog"."int4_ops" ASC NULLS LAST,
   "top_ccid" COLLATE "pg_catalog"."default" "pg_catalog"."text_ops" ASC NULLS LAST
);

COMMENT ON COLUMN "public"."scascade_leak_summarize"."result_id" IS '结果集Id';
COMMENT ON COLUMN "public"."scascade_leak_summarize"."top_ccid" IS '顶部节点CCId';
COMMENT ON COLUMN "public"."scascade_leak_summarize"."data_type" IS '数据类型标识';
COMMENT ON COLUMN "public"."scascade_leak_summarize"."ext" IS '扩展字段预留';
COMMENT ON COLUMN "public"."scascade_leak_summarize"."create_time" IS '创建时间';
COMMENT ON TABLE "public"."scascade_leak_summarize" IS '数据级联-漏洞分析汇总统计表';

-- 漏洞分析-按控制中心统计
CREATE TABLE "public"."scascade_leak_ccid" (
  "id" SERIAL NOT NULL,
  "result_id" int4 NOT NULL DEFAULT 0,
  "data_type" int2 NOT NULL DEFAULT 0,
  "ccid" varchar(128) COLLATE "pg_catalog"."default" NOT NULL DEFAULT ''::character varying,
  "ccid_name" varchar(255) COLLATE "pg_catalog"."default" NOT NULL DEFAULT ''::character varying,
  "cli_count" int4 NOT NULL DEFAULT 0,
  "founds" int4 NOT NULL DEFAULT 0,
  "fixs" int4 NOT NULL DEFAULT 0,
  "ignores" int4 NOT NULL DEFAULT 0,
  "ext" varchar(512) COLLATE "pg_catalog"."default" NOT NULL DEFAULT ''::character varying,
  "create_time" timestamp(6) NOT NULL DEFAULT now(),
  CONSTRAINT "scascade_leak_ccid_pkey" PRIMARY KEY ("id")
);

ALTER TABLE "public"."scascade_leak_ccid" OWNER TO "postgres";

CREATE INDEX "leak_ccid_result" ON "public"."scascade_leak_ccid" USING btree (
   "result_id" "pg_catalog"."int4_ops" ASC NULLS LAST
);

COMMENT ON COLUMN "public"."scascade_leak_ccid"."result_id" IS '结果集Id';
COMMENT ON COLUMN "public"."scascade_leak_ccid"."data_type" IS '数据类型标识';
COMMENT ON COLUMN "public"."scascade_leak_ccid"."ccid" IS '控制中心id';
COMMENT ON COLUMN "public"."scascade_leak_ccid"."ccid_name" IS '控制中心名';
COMMENT ON COLUMN "public"."scascade_leak_ccid"."cli_count" IS '终端数量';
COMMENT ON COLUMN "public"."scascade_leak_ccid"."founds" IS '发现漏洞数';
COMMENT ON COLUMN "public"."scascade_leak_ccid"."fixs" IS '修复漏洞数';
COMMENT ON COLUMN "public"."scascade_leak_ccid"."ignores" IS '忽略漏洞数';
COMMENT ON COLUMN "public"."scascade_leak_ccid"."ext" IS '扩展字段预留，不参与排序和查询的扩展';


-- 漏洞分析-按终端统计
CREATE TABLE "public"."scascade_leak_client" (
  "id" SERIAL NOT NULL,
  "result_id" int4 NOT NULL DEFAULT 0,
  "data_type" int2 NOT NULL DEFAULT 0,
  "client_mid" varchar(128) COLLATE "pg_catalog"."default" NOT NULL DEFAULT ''::character varying,
  "client_name" varchar(255) COLLATE "pg_catalog"."default" NOT NULL DEFAULT ''::character varying,
  "client_third_login_user" varchar(255) COLLATE "pg_catalog"."default" NOT NULL DEFAULT ''::character varying,
  "client_ip" varchar(128) COLLATE "pg_catalog"."default" NOT NULL DEFAULT ''::character varying,
  "client_mac" varchar(128) COLLATE "pg_catalog"."default" NOT NULL DEFAULT ''::character varying,
  "ccid" varchar(128) COLLATE "pg_catalog"."default" NOT NULL DEFAULT ''::character varying,
  "ccid_name" varchar(255) COLLATE "pg_catalog"."default" NOT NULL DEFAULT ''::character varying,
  "founds" int4 NOT NULL DEFAULT 0,
  "fixs" int4 NOT NULL DEFAULT 0,
  "ignores" int4 NOT NULL DEFAULT 0,
  "ext" varchar(512) COLLATE "pg_catalog"."default" NOT NULL DEFAULT ''::character varying,
  "create_time" timestamp(6) NOT NULL DEFAULT now(),
  CONSTRAINT "scascade_leak_client_pkey" PRIMARY KEY ("id")
);

ALTER TABLE "public"."scascade_leak_client" OWNER TO "postgres";

CREATE INDEX "leak_client_result" ON "public"."scascade_leak_client" USING btree (
  "result_id" "pg_catalog"."int4_ops" ASC NULLS LAST
    );

COMMENT ON COLUMN "public"."scascade_leak_client"."result_id" IS '结果集Id';
COMMENT ON COLUMN "public"."scascade_leak_client"."data_type" IS '数据类型标识';
COMMENT ON COLUMN "public"."scascade_leak_client"."client_mid" IS '终端标识';
COMMENT ON COLUMN "public"."scascade_leak_client"."client_name" IS '终端名';
COMMENT ON COLUMN "public"."scascade_leak_client"."client_third_login_user" IS '实名认证登录账号';
COMMENT ON COLUMN "public"."scascade_leak_client"."client_ip" IS '终端ip';
COMMENT ON COLUMN "public"."scascade_leak_client"."client_mac" IS '终端mac';
COMMENT ON COLUMN "public"."scascade_leak_client"."ccid" IS '控制中心';
COMMENT ON COLUMN "public"."scascade_leak_client"."ccid_name" IS '控制中心名';
COMMENT ON COLUMN "public"."scascade_leak_client"."founds" IS '发现漏洞数';
COMMENT ON COLUMN "public"."scascade_leak_client"."fixs" IS '修复漏洞数';
COMMENT ON COLUMN "public"."scascade_leak_client"."ignores" IS '忽略漏洞数';
COMMENT ON COLUMN "public"."scascade_leak_client"."ext" IS '扩展字段预留，不参与排序和查询的扩展';


-- 漏洞分析-按漏洞统计
CREATE TABLE "public"."scascade_leak_patch" (
  "id" SERIAL NOT NULL,
  "result_id" int4 NOT NULL DEFAULT 0,
  "data_type" int2 NOT NULL DEFAULT 0,
  "kbid" varchar(128) COLLATE "pg_catalog"."default" NOT NULL DEFAULT ''::character varying,
  "leak_name" varchar(255) COLLATE "pg_catalog"."default" NOT NULL DEFAULT ''::character varying,
  "leak_type" int2 NOT NULL DEFAULT 0,
  "leak_type_desc" varchar(255) COLLATE "pg_catalog"."default" NOT NULL DEFAULT ''::character varying,
  "founds" int4 NOT NULL DEFAULT 0,
  "fixs" int4 NOT NULL DEFAULT 0,
  "ignores" int4 NOT NULL DEFAULT 0,
  "ext" varchar(512) COLLATE "pg_catalog"."default" NOT NULL DEFAULT ''::character varying,
  "create_time" timestamp(6) NOT NULL DEFAULT now(),
  CONSTRAINT "scascade_leak_patch_pkey" PRIMARY KEY ("id")
);

ALTER TABLE "public"."scascade_leak_patch" OWNER TO "postgres";

CREATE INDEX "leak_patch_result" ON "public"."scascade_leak_patch" USING btree (
  "result_id" "pg_catalog"."int4_ops" ASC NULLS LAST
);

COMMENT ON COLUMN "public"."scascade_leak_patch"."result_id" IS '结果集Id';
COMMENT ON COLUMN "public"."scascade_leak_patch"."data_type" IS '数据类型标识';
COMMENT ON COLUMN "public"."scascade_leak_patch"."kbid" IS '补丁号';
COMMENT ON COLUMN "public"."scascade_leak_patch"."leak_name" IS '补丁名';
COMMENT ON COLUMN "public"."scascade_leak_patch"."leak_type" IS '漏洞类型';
COMMENT ON COLUMN "public"."scascade_leak_patch"."leak_type_desc" IS '漏洞类型描述';
COMMENT ON COLUMN "public"."scascade_leak_patch"."founds" IS '终端数';
COMMENT ON COLUMN "public"."scascade_leak_patch"."founds" IS '发现漏洞数';
COMMENT ON COLUMN "public"."scascade_leak_patch"."fixs" IS '修复漏洞数';
COMMENT ON COLUMN "public"."scascade_leak_patch"."ignores" IS '忽略漏洞数';
COMMENT ON COLUMN "public"."scascade_leak_patch"."ext" IS '扩展字段预留，不参与排序和查询的扩展';
