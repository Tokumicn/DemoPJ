package main

import (
	"flag"
	"fmt"
	"os"
)

var (
	AUTO_BUILD_VERSION     = "0.0.0.0"
	AUTO_BUILD_TIME        = "1970-01-01 00:00:00"
	AUTO_BUILD_COMMIT_SHA1 = "unknown"
	version_flag           = flag.Bool("version", false, "show version")
)

func init() {
	flag.Parse()
	if *version_flag {
		fmt.Println("Version: ", AUTO_BUILD_VERSION)
		fmt.Println("Git Tag: ", AUTO_BUILD_COMMIT_SHA1)
		fmt.Println("Build Time: ", AUTO_BUILD_TIME)
		os.Exit(0)
	}
}
