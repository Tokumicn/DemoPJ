package exporter

import (
	"fmt"
	"math/rand"
	"strconv"
	"strings"
	"time"
	"tq-scascade-report/pkg/config"
	"tq-scascade-report/pkg/def"
)

var r *rand.Rand

func init() {
	r = rand.New(rand.NewSource(time.Now().Unix()))
}

func RandString(len int) string {
	bytes := make([]byte, len)
	for i := 0; i < len; i++ {
		b := r.Intn(26) + 65
		bytes[i] = byte(b)
	}
	return string(bytes)
}

func randomKey() string {
	n := time.Now().Unix()
	return fmt.Sprintf("%d", n)
}

// 获取Cell名
func getCellName(colIndex, rowIndex int) string {
	var col string
	n := colIndex
	for n > 0 {

		m := n % 26
		if m == 0 {
			m = 26
		}

		col = string(rune(m+64)) + col
		n = (n - m) / 26
	}

	row := strconv.Itoa(rowIndex)
	return fmt.Sprintf("%s%s", col, row)
}

// 日志详情标题列
func buildTitleForLogDetail(colArr []string, bCode string) ([]string, error) {

	titles := make([]string, 0)
	colsConf, ok := ExportLogDetailColumnConfigMap[bCode]
	if !ok {
		return colArr, nil
	}

	for _, key := range colArr {
		if ti, ok := colsConf[key]; ok {
			titles = append(titles, ti)
		}
	}

	return titles, nil
}

// 文件夹名生成
func buildExportDir(dirTag, bCode, startTime, endTime string) (exportPath string, exportZipFileName, showZipFileName, timeStr string) {

	exportPath = config.Cfg().ExportConf.Path
	if exportPath[len(exportPath)-1:] != "/" {
		exportPath += "/"
	}

	business2String := convertBusiness2String(bCode)
	if len(business2String) <= 0 {
		if dirTag == REPORT {
			business2String = "报表"
		} else if dirTag == LOG_DETAIL {
			business2String = "日志"
		}
	}

	randomKeys := RandString(24)

	if len(startTime) <= 0 {
		startTime = time.Now().Format(def.YYYYMMDD)
		endTime = time.Now().Format(def.YYYYMMDD)
	}

	sTime := strings.Split(startTime, " ")[0]
	eTime := strings.Split(endTime, " ")[0]
	timeStr = fmt.Sprintf("%s-%s", sTime, eTime)

	subFolder := fmt.Sprintf("%s_%s_%s_%s", dirTag, bCode, timeStr, randomKeys)
	exportPath = fmt.Sprintf("%s%s", exportPath, subFolder)
	exportZipFileName = fmt.Sprintf("%s.zip", subFolder)

	showZipFileName = fmt.Sprintf("%s_%s.zip", business2String, timeStr)

	return
}

// 导出文件名
func buildExcelFullName(exportDir, bCode, timeStr string) string {
	var code2String = bCode
	if sheetConf, ok := ExportReportBCodeConfigMap[bCode]; ok {
		code2String = sheetConf
	}

	return fmt.Sprintf("%s/%s_%s_%s", exportDir, code2String, timeStr, randomKey())
}

func convertBusiness2String(business string) string {
	switch business {
	case def.SUMMARIZE:
		return "报表-汇总统计"
	case def.SCORE:
		return "报表-扫描分数"
	case def.VIRUS:
		return "报表-病毒分析"
	case def.LEAK:
		return "报表-漏洞分析"
	case def.ALERT:
		return "报表-告警事件"
	case LOG_SCORE:
		return "日志-扫描分数"
	case LOG_VIRUS:
		return "日志-病毒分析"
	case LOG_LEAK:
		return "日志-漏洞分析"
	case LOG_ALERT:
		return "日志-告警事件"
	case LOG_AUDIT:
		return "日志-审计"
	case LOG_ASSET:
		return "日志-资产"
	}
	return ""
}
