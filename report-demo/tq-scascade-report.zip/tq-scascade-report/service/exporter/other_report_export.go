package exporter

import (
	"errors"
	"fmt"
	"tq-scascade-report/pkg/def"
	"tq-scascade-report/pkg/model"
	"tq-scascade-report/pkg/tools"
	"tq-scascade-report/service/report_show"
)

var (
	ErrDataIsEmpty = errors.New("未查询到符合条件数据,无法正确导出数据")
)

// 返回Excel导出目录
func exportOtherReport(reqData *model.ResultQueryRequest, exportDir, timeStr, typeCode string) error {

	// 创建文件夹
	if !tools.IsExist(exportDir) {
		err := tools.Mkdir(exportDir)
		if err != nil {
			return err
		}
	}

	fullName := buildExcelFullName(exportDir, typeCode, timeStr)
	err := exportOtherDetail(reqData, typeCode, fullName)
	if err != nil {
		return err
	}
	return nil
}

// 除汇总统计外的其他类型报表导出
func exportOtherDetail(reqData *model.ResultQueryRequest, typeCode, fullName string) error {
	reqData.PageSize = 2500
	reqData.Current = 1

	exporter, err := newExcelExporterForReport(typeCode, fullName)
	if err != nil {
		return err
	}

	retry := 1
	for {
		detailData, err := report_show.GetReportDetailById(reqData)
		if err != nil {
			if retry >= 3 {
				break
			} else {
				retry++
			}
			continue
		}

		if len(detailData.Detail) <= 0 {
			return ErrDataIsEmpty
		}
		if len(detailData.Detail[0].Data) <= 0 {
			return ErrDataIsEmpty
		}

		exportData := detailData.Detail[0].Data

		err = exporter.AppendData(exportData)
		if err != nil {
			return err
		}

		// 数据获取完毕退出
		if len(exportData) <= 0 || len(exportData) < int(reqData.PageSize) {
			err = exporter.Save()
			if err != nil {
				return err
			}
			break
		}

		reqData.Current += 1
	}

	return nil
}

func newExcelExporterForReport(typeCode, fullName string) (*ExcelSplitHelper, error) {

	colsConf, ok := ExportColumnConfigMap[typeCode]
	if !ok {
		return nil, fmt.Errorf("获取导出列配置失败. [BusinessTypeCode: %s]", typeCode)
	}

	titles, customCols, err := buildReportTitleAndKeys(colsConf)
	if err != nil {
		return nil, err
	}

	spliter := &ExcelSplitHelper{
		FullName:              fullName,
		SplitFileIndex:        1,
		CurrentFileRowsLength: 0,
		SheetName:             colsConf.SheetName,
		Titles:                titles,
		Keys:                  customCols,
	}

	err = spliter.NewFile()
	if err != nil {
		return nil, err
	}

	return spliter, nil
}

func buildReportTitleAndKeys(config *DataColumnConfig) ([]string, []string, error) {

	titles := []string{}
	keys := []string{}
	for _, kt := range config.KeyNames {
		titles = append(titles, kt.title)
		keys = append(keys, kt.key)
	}

	return titles, keys, nil
}

func buildSummarizeReportTypeCode(business string) (string, error) {
	switch business {
	case def.SCORE:
		return def.SCORE_SUMMARIZE, nil
	case def.VIRUS:
		return def.VIRUS_SUMMARIZE, nil
	case def.LEAK:
		return def.LEAK_SUMMARIZE, nil
	case def.ALERT:
		return def.ALERT_SUMMARIZE, nil
	default:
		return "", fmt.Errorf("buildSummarizeReportTypeCode-- businesss [%s] 无效.", business)
	}
}

func buildOtherReportTypeCode(business, reportType string) (string, error) {
	// BusinessCode: { reportType: typeCode }
	var typeCodeMap = map[string]map[string]string{

		// 扫描分数
		def.SCORE: {
			def.CCID: def.SCORE_CCID,
		},

		// 病毒分析
		def.VIRUS: {
			def.CCID:   def.VIRUS_CCID,
			def.CLIENT: def.VIRUS_CLIENT,
			def.VIRUS:  def.VIRUS_NAME,
		},

		// 漏洞分析
		def.LEAK: {
			def.CCID:    def.LEAK_CCID,
			def.CLIENT:  def.LEAK_CLIENT,
			def.PATCHES: def.LEAK_PATCH,
		},

		// 告警事件

	}

	reportTypeMap, ok := typeCodeMap[business]
	if !ok {
		return "", errors.New("business参数有误")
	}

	typeCode, ok := reportTypeMap[reportType]
	if !ok {
		return "", errors.New("reportType参数有误")
	}

	return typeCode, nil
}
