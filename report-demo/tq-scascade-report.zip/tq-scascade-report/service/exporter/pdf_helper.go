package exporter

import (
	"bytes"
	"encoding/json"
	"errors"
	"git-biz.qianxin-inc.cn/eps/skylar/apps/libs/tianqing.git/logs"
	"io/ioutil"
	"net/http"
	"tq-scascade-report/pkg/config"
)

var ErrPdfFileNameIsEmpty = errors.New("导出报表PDF文件名无效.")

type PhantomjsRequest struct {
	WebAddr    string      `json:"web_addr"`
	OutputFile string      `json:"output_file"`
	Data       interface{} `json:"data,omitempty"`
	Tpl        string      `json:"tpl"`
}

func CreatePDF(pdfFullName string, detailData interface{}, tlp string) error {

	if len(pdfFullName) <= 0 {
		return ErrPdfFileNameIsEmpty
	}

	phantomJsServer := "http://127.0.0.1:8023"

	pdfWebAddr := config.Cfg().ExportConf.PdfWebAddr
	if len(pdfWebAddr) <= 0 {
		pdfWebAddr = "http://127.0.0.1:8080"
	}

	res := &PhantomjsRequest{
		WebAddr:    pdfWebAddr,
		OutputFile: pdfFullName,
		Data:       detailData,
		Tpl:        tlp,
	}

	jsonDetail, err := json.Marshal(res)
	if err != nil {
		return err
	}
	logs.Debugf("导出PDF报表参数: [%s]", string(jsonDetail))

	response, err := http.Post(phantomJsServer, "application/json;charset=utf-8", bytes.NewBuffer(jsonDetail))
	if err != nil {
		logs.Errorf(`PhantomJs Post Err:`, err)
		return err
	}
	responseBody, err := ioutil.ReadAll(response.Body)
	defer response.Body.Close()
	if err != nil {
		logs.Errorf(`PhantomJs Response Body Err:`, err)
		return err
	}
	if response.StatusCode != 200 {
		logs.Errorf(`PhantomJs Response StatusCode is Not 200. Body:`, string(responseBody))
		return err
	}

	logs.Debug("Phantomjs Response Body:", string(responseBody))
	return nil
}
