package exporter

import (
	"fmt"
	"tq-scascade-report/pkg/model"
	"tq-scascade-report/pkg/tools"
	"tq-scascade-report/service/report_show"

	"git-biz.qianxin-inc.cn/eps/skylar/apps/libs/tianqing.git/logs"
	"github.com/360EntSecGroup-Skylar/excelize/v2"
)

func exportSummarizeReport(reqData *model.SummarizeResultQueryRequest, exportDir, timeStr, business string) error {

	details, err := report_show.GetSummarizeReportDetailById(reqData)
	if err != nil {
		return err
	}

	if details == nil || len(details.Detail) <= 0 {
		return ErrDataIsEmpty
	}

	typeCode, err := buildSummarizeReportTypeCode(business)
	if err != nil {
		return err
	}

	excelFullName := buildExcelFullName(exportDir, typeCode, timeStr)
	//err = exportSummarizeDetail(details.Detail, exportDir, excelFullName)
	//if err != nil {
	//	return err
	//}

	// 创建文件夹
	if !tools.IsExist(exportDir) {
		err := tools.Mkdir(exportDir)
		if err != nil {
			return err
		}
	}

	// 构建pdf名称
	pdfFileName := buildPDFFileName(excelFullName)

	// 常见PDF到指定位置
	err = CreatePDF(pdfFileName, details, reqData.Tpl)
	if err != nil {
		return err
	}

	return nil
}

func buildPDFFileName(path string) string {
	return fmt.Sprintf("%s.pdf", path)
}

// queryTimeRange ==> _2020-12-15-2020-12-25_
// 生成一个Excel文件，不同类型数据分Sheet
func exportSummarizeDetail(details []*model.ReportDetail, folderName, fileFullName string) error {

	// 创建文件夹
	if !tools.IsExist(folderName) {
		err := tools.Mkdir(folderName)
		if err != nil {
			return err
		}
	}

	f := excelize.NewFile()
	f.SetDefaultFont("SimSun") // 默认字体宋体

	for _, report := range details {
		columnConfig, ok := ExportColumnConfigMap[report.Code]
		if ok {
			if columnConfig != nil {
				// 制作Excel
				err := creatSumReportExcel(f, report, columnConfig)
				if err != nil {
					continue
				}
			}
		}
	}

	f.DeleteSheet("Sheet1")
	f.SetActiveSheet(0)
	realFileFullName := fmt.Sprintf("%s.xlsx", fileFullName)
	if err := f.SaveAs(realFileFullName); err != nil {
		return err
	}

	return nil
}

// 定时报表--汇总统计生成Excel
func creatSumReportExcel(f *excelize.File, data *model.ReportDetail, colConfig *DataColumnConfig) error {
	if len(data.Data) <= 0 {
		return nil
	}

	// 每种类型一个Sheet
	var sheetName = data.Code
	if sheetConf, ok := ExportReportBCodeConfigMap[data.Code]; ok {
		sheetName = sheetConf
	}

	index := f.NewSheet(sheetName)
	f.SetActiveSheet(index)

	for idx, keyName := range colConfig.KeyNames {

		colIndex := idx + 1
		// 第一行标题
		err := f.SetCellValue(sheetName, getCellName(colIndex, 1), keyName.title)
		if err != nil {
			return err
		}

		rowIndex := 2
		// 按列写入
		for _, row := range data.Data {
			// 取值
			val, ok := row[keyName.key]
			if ok {
				err := f.SetCellValue(sheetName, getCellName(colIndex, rowIndex), val)
				if err != nil {
					logs.Errorf("creatSumReportExcel--SetCellValue err: %s", err.Error())
					continue
				}
			}
			rowIndex++
		}
	}

	return nil
}
