package exporter

import (
	"fmt"
	"os"
	"tq-scascade-report/pkg/def"
	"tq-scascade-report/pkg/model"
	"tq-scascade-report/pkg/tools"
	"tq-scascade-report/service/log_details"
	"tq-scascade-report/service/log_details/custom_column"
)

// 日志详情的导出
func ExportForLogDetail(reqData *model.QueryLogDetailsRequest) error {

	reqData.PageSize = 2500
	reqData.Current = 1
	dataCode := buildLogDetailType(reqData.BusinessCode)

	var exportFolder, timeStr, exportZipFileName, showZipFileName string
	if reqData.StartTime != nil && reqData.EndTime != nil {
		exportFolder, exportZipFileName, showZipFileName, timeStr = buildExportDir(LOG_DETAIL, dataCode, reqData.StartTime.T.Format(def.YYYYMMDD), reqData.EndTime.T.Format(def.YYYYMMDD))
	} else {
		exportFolder, exportZipFileName, showZipFileName, timeStr = buildExportDir(LOG_DETAIL, dataCode, "", "")
	}

	exporter, err := newExcelExporterForLogDetail(reqData, dataCode, exportFolder, timeStr)
	if err != nil {
		return err
	}

	retry := 1
	for {
		logData, err := log_details.QueryByFilter(reqData)
		if err != nil {
			if retry >= 3 {
				return err
			} else {
				retry++
			}
			continue
		}

		if logData == nil || len(logData.Detail) <= 0 {
			return ErrDataIsEmpty
		}

		err = exporter.AppendData(logData.Detail)
		if err != nil {
			return err
		}

		// 数据获取完毕退出
		if len(logData.Detail) <= 0 || len(logData.Detail) < int(reqData.PageSize) {
			err = exporter.Save()
			if err != nil {
				return err
			}
			break
		}

		reqData.Current += 1
	}

	// 将文件夹打包
	zipFilePath := fmt.Sprintf("%s.zip", exportFolder)
	err = CreateZip(exportFolder, zipFilePath)
	if err != nil {
		return err
	}

	err = os.RemoveAll(exportFolder)
	if err != nil {
		return err
	}

	// 发送推送
	err = NotificationToZipDownload(reqData.Uid, exportZipFileName, showZipFileName)
	if err != nil {
		return err
	}

	return nil
}

func newExcelExporterForLogDetail(reqData *model.QueryLogDetailsRequest, dataCode, exportDir, timeStr string) (*ExcelSplitHelper, error) {
	// 获取自定义列配置  获取不到则使用默认配置
	_, customCols, err := custom_column.GetCustomColumnFieldsArray(reqData.BusinessCode)
	if err != nil {
		return nil, err
	}

	titles, err := buildTitleForLogDetail(customCols, dataCode)

	// 创建文件夹
	if !tools.IsExist(exportDir) {
		err = tools.Mkdir(exportDir)
		if err != nil {
			return nil, err
		}
	}

	fullName := buildExcelFullName(exportDir, dataCode, timeStr)

	spliter := &ExcelSplitHelper{
		FullName:              fullName,
		SplitFileIndex:        1,
		CurrentFileRowsLength: 0,
		SheetName:             buildSheetNameByBCode(dataCode),
		Titles:                titles,
		Keys:                  customCols,
	}

	err = spliter.NewFile()
	if err != nil {
		return nil, err
	}

	return spliter, nil
}

// 获取日志详情数据业务标识
func buildLogDetailType(bCode string) string {
	switch bCode {
	case def.SCORE:
		return LOG_SCORE
	case def.VIRUS:
		return LOG_VIRUS
	case def.LEAK:
		return LOG_LEAK
	case def.ASSET:
		return LOG_ASSET
	case def.AUDIT:
		return LOG_AUDIT
	case def.ALERT:
		return LOG_ALERT
	default:
		return ""
	}
}

func buildSheetNameByBCode(bCode string) string {
	switch bCode {
	case LOG_SCORE:
		return "日志详情-扫描分数"
	case LOG_VIRUS:
		return "日志详情-病毒分析"
	case LOG_LEAK:
		return "日志详情-漏洞分析"
	case LOG_ASSET:
		return "日志详情-资产汇总"
	case LOG_AUDIT:
		return "日志详情-审计日志"
	case LOG_ALERT:
		return "日志详情-告警事件"
	default:
		return ""
	}
}
