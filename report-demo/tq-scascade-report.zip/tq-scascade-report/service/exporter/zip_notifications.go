package exporter

import (
	"encoding/json"
	"fmt"
	"git-biz.qianxin-inc.cn/eps/skylar/apps/libs/tianqing.git/logs"
	"tq-scascade-report/pkg/config"

	"github.com/kr/beanstalk"
)

func NotificationToZipDownload(uid int64, zipFileNameReal, zipFileNameDown string) error {

	logs.Debugf("=== [UID: %d ,导出文件:%s , 下载文件: %s] ===", uid, zipFileNameReal, zipFileNameDown)

	// 生成Zip后的下载提醒
	var msg = fmt.Sprintf(`日志报表已经导出完成，请点击 <a href="/tools/index/dlexport?real_name=report/export/%s&export_name=%s&is_download=true">下载</a>。`, zipFileNameReal, zipFileNameDown)
	err := sendNotifyToConsoleUser(uid, msg)
	if err != nil {
		return err
	}

	return nil
}

type NotifyData struct {
	Channel string        `json:"channel"`
	Data    NotifyMessage `json:"data"`
}

type NotifyMessage struct {
	Uid int    `json:"uid"`
	Msg string `json:"msg"`
}

/*
 * 向控制台管理员发送通知
 */
func sendNotifyToConsoleUser(uid int64, msg string) (err error) {

	beanstalkConnStr := config.Cfg().ExportConf.BeanstalkConn

	data := NotifyData{
		Channel: "notify_console",
		Data: NotifyMessage{
			Uid: int(uid),
			Msg: msg,
		},
	}
	jobDataJson, err := json.Marshal(data)
	if err != nil {
		return err
	}

	c, err := beanstalk.Dial("tcp", beanstalkConnStr)
	if err != nil {
		return err
	}
	defer c.Close()

	tube := beanstalk.Tube{c, "work_queue_php_internal"}
	_, err = tube.Put([]byte(jobDataJson), 0, 0, 0)
	if err != nil {
		return err
	}
	return nil
}
