package exporter

import "tq-scascade-report/pkg/def"

// 导出类型
const (
	REPORT     = "Report"
	LOG_DETAIL = "LogDetail"
)

// 导出数据业务表示
const (
	// 日志详情
	LOG_SCORE = "LOG_SCORE" // 扫描分数
	LOG_VIRUS = "LOG_VIRUS" // 病毒分析
	LOG_LEAK  = "LOG_LEAK"  // 漏洞分析
	LOG_AUDIT = "LOG_AUDIT" // 审计事件
	LOG_ALERT = "LOG_ALERT" // 告警事件
	LOG_ASSET = "LOG_ASSET" // 资产汇总
)

type DataColumnConfig struct {
	FileName  string
	SheetName string
	KeyNames  []KeyTitle
}

type KeyTitle struct {
	key   string
	title string
}

var ExportReportBCodeConfigMap = map[string]string{
	def.SCORE_SUMMARIZE: "报表-扫描分数-汇总统计",
	def.VIRUS_SUMMARIZE: "报表-病毒分析-汇总统计",
	def.LEAK_SUMMARIZE:  "报表-漏洞分析-汇总统计",
	def.ALERT_SUMMARIZE: "报表-告警事件-汇总统计",

	// 扫描分数
	def.SCORE_CCID:                   "报表-扫描分数-按控制中心统计",
	def.SCORE_SUMMARIZE_CLIENT_TOP10: "报表-扫描分数-按终端Top10",
	def.SCORE_SUMMARIZE_CCID_TOP10:   "报表-扫描分数-按控制中心Top10",

	// 病毒分析
	def.VIRUS_CCID:                   "报表-病毒分析-按控制中心统计",
	def.VIRUS_CLIENT:                 "报表-病毒分析-按终端统计统计",
	def.VIRUS_NAME:                   "报表-病毒分析-按病毒统计统计",
	def.VIRUS_SUMMARIZE_CLIENT_TOP10: "报表-病毒分析-按终端Top10",   // 汇总统计--感染病毒最多[终端] TOP 10
	def.VIRUS_SUMMARIZE_CCID_TOP10:   "报表-病毒分析-按控制中心Top10", // 汇总统计--感染最多[控制中心] TOP 10
	def.VIRUS_SUMMARIZE_VNAME_TOP10:  "报表-病毒分析-按病毒名Top10",  // 汇总统计--感染[病毒] TOP 10

	// 漏洞分析
	def.LEAK_CCID:                   "报表-漏洞分析-按控制中心统计",    // 按控制中心统计
	def.LEAK_CLIENT:                 "报表-漏洞分析-按终端统计",      // 按终端统计
	def.LEAK_PATCH:                  "报表-漏洞分析-按漏洞补丁统计",    // 按漏洞补丁统计
	def.LEAK_SUMMARIZE_CLIENT_TOP10: "报表-漏洞分析-按终端Top10",   // 汇总统计--安装漏洞补丁次数最多[终端] TOP 10
	def.LEAK_SUMMARIZE_CCID_TOP10:   "报表-漏洞分析-按控制中心Top10", // 汇总统计--安装漏洞补丁次数最多[控制中心] TOP 10
	def.LEAK_SUMMARIZE_PATCH_TOP10:  "报表-漏洞分析-按漏洞补丁Top10", // 汇总统计--安装漏洞补丁次数最多[补丁] TOP 10

	LOG_SCORE: "日志详情-扫描分数",
	LOG_VIRUS: "日志详情-病毒分析",
	LOG_LEAK:  "日志详情-漏洞分析",
	LOG_AUDIT: "日志详情-审计",
	LOG_ALERT: "日志详情-告警事件",
	LOG_ASSET: "日志详情-资产",
}

var (
	// 报表导出列配置
	ExportColumnConfigMap = map[string]*DataColumnConfig{
		// 扫描分数
		def.SCORE_CCID: {
			SheetName: "报表扫描分数_按控制中心统计",
			KeyNames: []KeyTitle{
				{
					key:   "ccid_name",
					title: "所属控制中心",
				},
				{
					key:   "cli_count",
					title: "终端数量",
				},
				{
					key:   "avg_score",
					title: "平均扫描分数",
				},
			},
		},
		def.SCORE_SUMMARIZE_CLIENT_TOP10: {
			SheetName: "报表扫描分数_汇总统计_客户端Top10",
			KeyNames: []KeyTitle{
				{
					key:   "client_name",
					title: "计算机名称",
				},
				{
					key:   "client_ip",
					title: "IP地址",
				},
				{
					key:   "client_mac",
					title: "MAC地址",
				},
				{
					key:   "client_third_login_user",
					title: "实名账号",
				},
				{
					key:   "ccid_name",
					title: "所属控制中心",
				},
				{
					key:   "avg_score",
					title: "平均扫描分数",
				},
			},
		},
		def.SCORE_SUMMARIZE_CCID_TOP10: {
			SheetName: "报表扫描分数_汇总统计_控制中心Top10",
			KeyNames: []KeyTitle{
				{
					key:   "ccid_name",
					title: "所属控制中心",
				},
				{
					key:   "avg_score",
					title: "平均扫描分数",
				},
			},
		},
		def.SCORE_SUMMARIZE_TREND: nil, //PDF

		// 病毒分析
		def.VIRUS_CCID: {
			SheetName: "报表病毒分析_按控制中心统计",
			KeyNames: []KeyTitle{
				{
					key:   "ccid_name",
					title: "所属控制中心",
				},
				{
					key:   "cli_count",
					title: "感染终端数量",
				},
				{
					key:   "all_kills",
					title: "查杀次数",
				},
				{
					key:   "monitor_kills",
					title: "实时监控查杀",
				},
				{
					key:   "user_kills",
					title: "用户查杀",
				},
				{
					key:   "admin_kills",
					title: "管理员查杀",
				},
			},
		},
		def.VIRUS_CLIENT: {
			SheetName: "报表病毒分析_按客户端统计",
			KeyNames: []KeyTitle{
				{
					key:   "client_name",
					title: "计算机名称",
				},
				{
					key:   "client_third_login_user",
					title: "实名账号",
				},
				{
					key:   "client_ip",
					title: "IP地址",
				},
				{
					key:   "client_mac",
					title: "MAC地址",
				},
				{
					key:   "ccid_name",
					title: "所属控制中心",
				},
				{
					key:   "all_kills",
					title: "查杀次数",
				},
				{
					key:   "monitor_kills",
					title: "实时监控查杀",
				},
				{
					key:   "user_kills",
					title: "用户查杀",
				},
				{
					key:   "admin_kills",
					title: "管理员查杀",
				},
			},
		},
		def.VIRUS_NAME: {
			SheetName: "报表病毒分析_按病毒名统计",
			KeyNames: []KeyTitle{
				{
					key:   "vname",
					title: "病毒名",
				},
				{
					key:   "virus_cat_desc",
					title: "病毒种类",
				},
				{
					key:   "cli_count",
					title: "感染终端数",
				},
				{
					key:   "all_kills",
					title: "查杀次数",
				},
				{
					key:   "monitor_kills",
					title: "实时监控查杀",
				},
				{
					key:   "user_kills",
					title: "用户查杀",
				},
				{
					key:   "admin_kills",
					title: "管理员查杀",
				},
			},
		},
		def.VIRUS_SUMMARIZE_CLIENT_TOP10: {
			SheetName: "报表病毒分析_汇总统计_客户端Top10",
			KeyNames: []KeyTitle{
				{
					key:   "client_name",
					title: "计算机名称",
				},
				{
					key:   "client_ip",
					title: "IP地址",
				},
				{
					key:   "client_mac",
					title: "MAC地址",
				},
				{
					key:   "client_third_login_user",
					title: "实名账号",
				},
				{
					key:   "ccid_name",
					title: "所属控制中心",
				},
				{
					key:   "all_kills",
					title: "查杀次数",
				},
			},
		},
		def.VIRUS_SUMMARIZE_CCID_TOP10: {
			SheetName: "报表病毒分析_汇总统计_控制中心Top10",
			KeyNames: []KeyTitle{
				{
					key:   "ccid_name",
					title: "所属控制中心",
				},
				{
					key:   "cli_count",
					title: "感染终端数",
				},
				{
					key:   "all_kills",
					title: "查杀次数",
				},
			},
		},
		def.VIRUS_SUMMARIZE_VNAME_TOP10: {
			SheetName: "报表病毒分析_汇总统计_病毒名Top10",
			KeyNames: []KeyTitle{
				{
					key:   "vname",
					title: "病毒名",
				},
				{
					key:   "virus_cat_desc",
					title: "病毒类型",
				},
				{
					key:   "all_kills",
					title: "查杀次数",
				},
			},
		},
		def.VIRUS_SUMMARIZE_TREND_NAME:        nil, //PDF
		def.VIRUS_SUMMARIZE_TREND_KILLCOUNT:   nil, //PDF
		def.VIRUS_SUMMARIZE_TREND_ClientCOUNT: nil, //PDF
		def.VIRUS_SUMMARIZE_CAT_PER:           nil, //PDF
		def.VIRUS_SUMMARIZE_OPTION_PER:        nil, //PDF
		def.VIRUS_SUMMARIZE_TASK_PER:          nil, //PDF

		// 漏洞分析
		def.LEAK_CCID: {
			SheetName: "报表漏洞分析_按控制中心统计",
			KeyNames: []KeyTitle{
				{
					key:   "ccid_name",
					title: "所属控制中心",
				},
				{
					key:   "cli_count",
					title: "终端数量",
				},
				{
					key:   "founds",
					title: "已发现补丁数",
				}, {
					key:   "fixs",
					title: "已安装补丁数",
				},
				{
					key:   "ignores",
					title: "忽略补丁数",
				},
			},
		},
		def.LEAK_CLIENT: {
			SheetName: "报表漏洞分析_按客户端统计",
			KeyNames: []KeyTitle{
				{
					key:   "client_name",
					title: "计算机名称",
				},
				{
					key:   "client_third_login_user",
					title: "实名账号",
				},
				{
					key:   "client_ip",
					title: "IP地址",
				},
				{
					key:   "client_mac",
					title: "MAC地址",
				},
				{
					key:   "ccid_name",
					title: "所属控制中心",
				},
				{
					key:   "founds",
					title: "已发现补丁数",
				},
				{
					key:   "fixs",
					title: "已安装补丁数",
				},
				{
					key:   "ignores",
					title: "忽略补丁数",
				},
			},
		},
		def.LEAK_PATCH: {
			SheetName: "报表漏洞分析_按补丁统计",
			KeyNames: []KeyTitle{
				{
					key:   "leak_name",
					title: "补丁名称",
				},
				{
					key:   "kbid",
					title: "补丁号",
				},
				{
					key:   "leak_type_desc",
					title: "漏洞级别",
				},
				{
					key:   "founds",
					title: "已发现补丁数",
				},
				{
					key:   "fixs",
					title: "已安装补丁数",
				},
				{
					key:   "ignores",
					title: "已忽略补丁数",
				},
			},
		},
		def.LEAK_SUMMARIZE_CLIENT_TOP10: {
			SheetName: "报表漏洞分析_汇总统计_客户端Top10",
			KeyNames: []KeyTitle{
				{
					key:   "client_name",
					title: "计算机名称",
				},
				{
					key:   "client_ip",
					title: "IP地址",
				},
				{
					key:   "client_mac",
					title: "MAC地址",
				},

				{
					key:   "client_third_login_user",
					title: "实名账号",
				},
				{
					key:   "ccid_name",
					title: "控制中心",
				},
				{
					key:   "install_count",
					title: "修复次数",
				},
			},
		},
		def.LEAK_SUMMARIZE_CCID_TOP10: {
			SheetName: "报表漏洞分析_汇总统计_控制中心Top10",
			KeyNames: []KeyTitle{
				{
					key:   "ccid_name",
					title: "控制中心",
				},
				{
					key:   "ccid_name",
					title: "安装次数",
				},
			},
		},
		def.LEAK_SUMMARIZE_PATCH_TOP10: {
			SheetName: "报表漏洞分析_汇总统计_补丁Top10",
			KeyNames: []KeyTitle{
				{
					key:   "install_count",
					title: "安装次数",
				},
				{
					key:   "kbid",
					title: "补丁号",
				},
			},
		},
		def.LEAK_SUMMARIZE_TREND:       nil, //PDF
		def.LEAK_SUMMARIZE_FAILURE_PER: nil, //PDF
		def.LEAK_SUMMARIZE_LEVEL_PER:   nil, //PDF

		// 告警事件
		def.ALERT_SUMMARIZE_TREND:      nil, //PDF
		def.ALERT_SUMMARIZE_Type_PER:   nil, //PDF
		def.ALERT_SUMMARIZE_COUNTS_PER: nil, //PDF

	}

	// 日志详情导出列配置
	ExportLogDetailColumnConfigMap = map[string]map[string]string{
		// 日志详情--扫描分数
		LOG_SCORE: {
			"event_time":              "时间",
			"client_name":             "计算机名",
			"client_ip":               "IP地址",
			"client_mac":              "MAC地址",
			"client_groupname":        "分组",
			"ccid":                    "所属控制中心",
			"client_os":               "操作系统",
			"client_third_login_user": "实名账号",
			"exam_score":              "分数", // 业务特有字段
		},

		// 日志详情--病毒分析
		LOG_VIRUS: {
			"event_time":              "时间",
			"client_name":             "计算机名",
			"client_ip":               "IP地址",
			"client_mac":              "MAC地址",
			"client_groupname":        "分组",
			"ccid":                    "所属控制中心",
			"client_os":               "操作系统",
			"client_third_login_user": "实名账号",
			"task_id":                 "触发方式", // 业务特有字段 需要特殊处理
			"from":                    "病毒来源", // 业务特有字段
			"vname":                   "病毒名称", // 业务特有字段
			"md5":                     "MD5",  // 业务特有字段
			"sha1":                    "SHA1", // 业务特有字段
			"op":                      "处理结果", // 业务特有字段 需要特殊处理
			"path":                    "文件路径", // 业务特有字段
		},

		// 日志详情--漏洞分析
		LOG_LEAK: {
			"event_time":              "时间",
			"client_name":             "计算机名",
			"client_ip":               "IP地址",
			"client_mac":              "MAC地址",
			"client_groupname":        "分组",
			"ccid":                    "所属控制中心",
			"client_os":               "操作系统",
			"client_third_login_user": "实名账号",
			"leak_name":               "补丁名",  // 业务特有字段
			"leak_type":               "漏洞级别", // 业务特有字段
			"event_action":            "操作",   // 特殊处理
			"kbid":                    "补丁号",
			"reason":                  "漏洞原因",
		},

		// 日志详情--告警事件
		LOG_ALERT: {
			"event_time":              "时间",
			"client_name":             "计算机名",
			"client_ip":               "IP地址",
			"client_mac":              "MAC地址",
			"client_groupname":        "分组",
			"ccid":                    "所属控制中心",
			"client_os":               "操作系统",
			"client_third_login_user": "实名账号",
			"type":                    "事件类型", // 业务特有字段
			"format_content":          "详细内容", // 业务特有字段
			"content":                 "事件详情",
			"datetime":                "发生时间",
			"account":                 "告警账号",
		},

		// 日志详情--审计
		LOG_AUDIT: {
			"event_time":              "时间",
			"client_name":             "计算机名",
			"client_ip":               "IP地址",
			"client_mac":              "MAC地址",
			"client_groupname":        "分组",
			"ccid":                    "所属控制中心",
			"client_os":               "操作系统",
			"client_third_login_user": "实名账号",
			"type":                    "类型",   // 业务特有字段
			"format_content":          "详细信息", // 业务特有字段
			"content":                 "事件详情",
			"account":                 "告警账号",
		},

		// 日志详情--资产汇总
		LOG_ASSET: {
			"event_time":                         "时间",
			"client_name":                        "计算机名",
			"client_ip":                          "IP地址",
			"client_mac":                         "MAC地址",
			"client_groupname":                   "分组",
			"ccid":                               "所属控制中心",
			"client_os":                          "操作系统",
			"client_third_login_user":            "实名账号",
			"ext_main_ver":                       "主程序版本",
			"ext_virus_lib_date":                 "病毒库时间",
			"ext_leaklib_ver":                    "补丁库版本",
			"last_time":                          "最后在线时间",
			"nac_user_full_name":                 "实名姓名",
			"client_login_user":                  "登录用户",
			"client_os_domain_name":              "登录域",
			"client_type":                        "系统平台", // 特殊处理
			"client_os_small_version_edition_id": "Windows10版本号",
			"hardware_summary_device_type":       "计算机类型",
			"hardware_summary_description":       "计算机型号",
			"hardware_summary_cpu":               "CPU",
			"hardware_summary_memory":            "内存",
			"hardware_summary_harddisk":          "硬盘",
			"hardware_summary_displaycard":       "显卡",
			"hardware_summary_monitor":           "显示器",
			"hardware_harddisk_serial_number":    "硬盘序列号",
			"hardware_summary_serial_number":     "SN序列号",
			"os_lang":                            "系统语言",
			"os_osspa":                           "激活状态",
			"os_install_date":                    "系统安装时间",
			"hardware_summary_device_use":        "设备用途",
			"hardware_summary_username":          "使用人",
			"hardware_summary_user_number":       "工号",
			"hardware_summary_mobile":            "手机",
			"hardware_summary_email":             "邮箱",
			"hardware_summary_location":          "物理位置",
			"hardware_summary_telephone":         "座机",
			"hardware_summary_memo":              "备注",
			"client_hardware_cpu_core_count":     "CPU核心数",
			"client_hardware_cpu_frequency":      "主频",
			"client_hardware_harddisk_size":      "硬盘",
			"client_hardware_memory_size":        "内存大小",
			"client_hardware_monitor_size":       "显示器尺寸",
		},
	}
)
