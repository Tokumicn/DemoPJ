package exporter

import (
	"compress/flate"
	"git-biz.qianxin-inc.cn/eps/skylar/apps/libs/tianqing.git/logs"
	"github.com/mholt/archiver/v3"
	"path/filepath"
)

func CreateZip(folderName, fileName string) error {

	fileList, err := filepath.Glob(filepath.Join(folderName, "*"))
	if err != nil {
		return err
	}

	logs.Debugf("待Zip压缩文件列表: %+v, 文件存放到: %s", fileList, fileName)

	z := archiver.Zip{
		CompressionLevel:       flate.DefaultCompression,
		MkdirAll:               true,
		SelectiveCompression:   true,
		ContinueOnError:        true,
		OverwriteExisting:      true,
		ImplicitTopLevelFolder: false,
	}

	err = z.Archive(fileList, fileName)
	if err != nil {
		return err
	}

	return nil
}
