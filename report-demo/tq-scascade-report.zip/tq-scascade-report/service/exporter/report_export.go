package exporter

import (
	"fmt"
	"os"
	"tq-scascade-report/pkg/config"
	"tq-scascade-report/pkg/dao"
	"tq-scascade-report/pkg/def"
	"tq-scascade-report/pkg/model"
	"tq-scascade-report/pkg/tools"
)

func buildExportTplByBusiness(business string) (string, error) {

	tplMap := config.Cfg().ExportConf.TplMap

	tpl, ok := tplMap[business]
	if ok {
		return tpl, nil
	}

	return "", fmt.Errorf("tpl not exsit.")
}

func ExportAndNotification(reqData *model.ResultExportQueryRequest) error {

	// 获取查询先关参数
	condition, err := dao.GetReportDetailCondition(reqData.ResultId)
	if err != nil {
		return err
	}

	// 文件存放目录    report_startTime-endTime-random
	// 文件翻译后目录  报表管理_startTime-endTime
	// Excel文件名
	// PDF文件名
	exportFullPath, exportFileName, showFileName, timeStr := buildExportDir(REPORT, condition.Business, condition.StartTime, condition.EndTime)

	// 导出文件到指定位置
	err = exportForReportDetail(reqData, exportFullPath, timeStr, condition.Business, condition.ReportTypes)
	if err != nil {
		return err
	}

	// 将文件夹打包
	zipFilePath := fmt.Sprintf("%s.zip", exportFullPath)
	err = CreateZip(exportFullPath, zipFilePath)
	if err != nil {
		return err
	}

	// 删除多余文件
	err = os.RemoveAll(exportFullPath)
	if err != nil {
		return err
	}

	// 发送推送
	return NotificationToZipDownload(reqData.Uid, exportFileName, showFileName)
}

func exportForReportDetail(reqData *model.ResultExportQueryRequest, exportFolder, timeStr, business, reportTypes string) error {

	// 更新模板地址
	tpl, err := buildExportTplByBusiness(business)
	if err != nil {
		return err
	}
	reqData.Tpl = tpl

	needReportTypes := buildNeedExportReportTypes(reqData.ReportTypes, reportTypes)
	for _, tp := range needReportTypes {
		if tp == def.SUMMARIZE {
			sumReqData := &model.SummarizeResultQueryRequest{
				ResultId: reqData.ResultId,
				TopCCId:  reqData.TopCCId,
				Tpl:      reqData.Tpl,
			}

			err := exportSummarizeReport(sumReqData, exportFolder, timeStr, business)
			if err != nil {
				return err
			}
		}

		if tp == def.CCID ||
			tp == def.CLIENT ||
			tp == def.PATCHES ||
			tp == def.VIRUS {

			typeCode, err := buildOtherReportTypeCode(business, tp)
			if err != nil {
				return err
			}

			detailReq := &model.ResultQueryRequest{
				ResultId:       reqData.ResultId,
				TopCCId:        reqData.TopCCId,
				ReportType:     tp,
				WhereArgs:      reqData.WhereArgs,
				PageSize:       reqData.PageSize,
				Current:        reqData.Current,
				Order:          reqData.Order,
				OrderCondition: reqData.OrderCondition,
			}

			err = exportOtherReport(detailReq, exportFolder, timeStr, typeCode)
			if err != nil {
				return err
			}
		}
	}

	return nil
}

func buildNeedExportReportTypes(reqTypes, allowTypes string) []string {
	allowReportTypes := tools.SplitStrWithoutEmpty(allowTypes, ",")

	reqReportTypes := tools.SplitStrWithoutEmpty(reqTypes, ",")

	needReportTypes := make([]string, 0)

	for _, reqTP := range reqReportTypes {
		for _, allowTP := range allowReportTypes {
			if reqTP == allowTP {
				needReportTypes = append(needReportTypes, reqTP)
			}
		}
	}

	return needReportTypes
}

// 导出全部类型的报表
//func exportAllReport(reqData *model.ResultQueryRequest) (string, error) {
//
//	sumReqData := &model.SummarizeResultQueryRequest{
//		ResultId: reqData.ResultId,
//		TopCCId:  reqData.TopCCId,
//	}
//
//	condition, err := dao.GetReportDetailCondition(reqData.ResultId)
//	if err != nil {
//		return "", err
//	}
//
//	dirTag := convertBusiness2String(condition.Business)
//	exportFolder := buildExportDir(dirTag, "All", condition.StartTime, condition.EndTime)
//
//	reportTypes := tools.SplitStrWithoutEmpty(condition.ReportTypes, ",")
//
//	for _, rType := range reportTypes {
//
//		if rType == def.SUMMARIZE {
//			err = exportSummarizeReport(sumReqData, exportFolder)
//			if err != nil {
//				return "", err
//			}
//		} else {
//			reqData.ReportType = rType
//			typeCode, err := buildOtherReportTypeCode(condition.Business, rType)
//			if err != nil {
//				return "", err
//			}
//			err = exportOtherReport(reqData, exportFolder, typeCode)
//			if err != nil {
//				return "", err
//			}
//		}
//	}
//
//	return exportFolder, nil
//}
