package exporter

import "testing"

func TestSplit(t *testing.T) {

	spliter := ExcelSplitHelper{
		FullName:              "D://wokerDir//src//git-biz.qianxin-inc.cn//eps/skylar//apps//super-cascade//tq-scascade-report//download//demo",
		SplitFileIndex:        1,
		CurrentFileRowsLength: 0,
		SheetName:             "Demo1",
		Titles:                []string{"Col1", "Col2", "Col3"},
		Keys:                  []string{"key1", "key2", "key3"},
	}

	err := spliter.NewFile()
	if err != nil {
		t.Fatal(err)
	}

	res := []map[string]interface{}{
		{"key1": 111, "key2": 222, "key3": 333},
		{"key1": 111, "key2": 222, "key3": 333},
		{"key1": 111, "key2": 222, "key3": 333},
		{"key1": 111, "key2": 222, "key3": 333},
		{"key1": 111, "key2": 222, "key3": 333},
		{"key1": 111, "key2": 222, "key3": 333},
		{"key1": 111, "key2": 222, "key3": 333},
		{"key1": 111, "key2": 222, "key3": 333},
		{"key1": 111, "key2": 222, "key3": 333},
		{"key1": 111, "key2": 222, "key3": 333},
		{"key1": 111, "key2": 222, "key3": 333},
	}

	for i := 0; i <= 5; i++ {
		err := spliter.AppendData(res)
		if err != nil {
			t.Fatal(err)
		}
	}

	err = spliter.Save()
	if err != nil {
		t.Error(err)
	}
}
