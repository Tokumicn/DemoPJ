package exporter

import (
	"fmt"
	"git-biz.qianxin-inc.cn/eps/skylar/apps/libs/tianqing.git/logs"
	"github.com/360EntSecGroup-Skylar/excelize/v2"
	"time"
	"tq-scascade-report/pkg/def"
)

const (
	SplitRowsLimit = 10000 // 切分行数
)

// 支持往一个Sheet里写入并切分
type ExcelSplitHelper struct {
	file                  *excelize.File
	FullName              string
	LastFullName          string // 记录最新的文件名 用于拆分文件后记录文件名
	SplitFileIndex        int    // 当前文件切分序号
	CurrentFileRowsLength int    // 当前行数

	SheetName string
	// Sheet的标题
	Titles []string
	Keys   []string
}

func (helper *ExcelSplitHelper) NewFile() error {
	file := excelize.NewFile()
	file.SetDefaultFont("SimSun") // 默认字体宋体
	file.NewSheet(helper.SheetName)

	for colIndex, title := range helper.Titles {
		err := file.SetCellValue(helper.SheetName, getCellName(colIndex+1, 1), title)
		if err != nil {
			return err
		}
	}

	helper.file = file

	return nil
}

func (helper *ExcelSplitHelper) AppendData(resData []map[string]interface{}) error {

	rowCOUNT := helper.CurrentFileRowsLength + len(resData)

	// 需要切分
	if rowCOUNT > SplitRowsLimit {

		batchSize := SplitRowsLimit
		length := len(resData)
		start := 0
		end := 0
		for {
			if length < batchSize {
				end = length
			} else {
				end = start + batchSize
			}

			// 防止数据不足batchSize时,拷贝不越界
			if end > length {
				end = length
			}

			batchSlice := resData[start:end]
			helper.appendRows(batchSlice)
			err := helper.saveAndNew()
			if err != nil {
				logs.Error("文件过大分文件到导出出错. err: ", err.Error())
				return err
			}

			if end >= length {
				// 更新当前文件行数
				helper.CurrentFileRowsLength = len(batchSlice)
				break
			}

			start = end
		}

	} else {
		helper.appendRows(resData)
	}

	return nil
}

func (helper *ExcelSplitHelper) appendRows(resData []map[string]interface{}) {

	// 制作Excel
	for colIndex, key := range helper.Keys {

		rowIndex := 2
		// 按列写入
		for _, row := range resData {
			// 取值
			val, ok := row[key]
			if ok {
				cellName := getCellName(colIndex+1, rowIndex)

				if key == "event_time" {
					val = val.(time.Time).Format(def.YYYYMMDDHHSSmm)
				}

				err := helper.file.SetCellValue(helper.SheetName, cellName, val)
				if err != nil {
					logs.Errorf("appendRows--SetCellValue err: %s", err.Error())
					continue
				}
			}
			rowIndex++
		}
	}

}

func (helper *ExcelSplitHelper) saveAndNew() error {

	fileName := fmt.Sprintf("%s%d.xlsx", helper.FullName, helper.SplitFileIndex)
	helper.SplitFileIndex++

	// 删除未命名的Sheet1
	helper.file.DeleteSheet("Sheet1")
	helper.file.SetActiveSheet(0)
	if err := helper.file.SaveAs(fileName); err != nil {
		return err
	}

	err := helper.NewFile()
	if err != nil {
		return err
	}

	// 记录最新文件名
	helper.LastFullName = fmt.Sprintf("%s%d.xlsx", helper.FullName, helper.SplitFileIndex)

	return nil
}

func (helper *ExcelSplitHelper) Save() error {

	if len(helper.LastFullName) <= 0 {
		helper.file.DeleteSheet("Sheet1")
		helper.file.SetActiveSheet(0)
		excelFileName := fmt.Sprintf("%s.xlsx", helper.FullName)
		if err := helper.file.SaveAs(excelFileName); err != nil {
			return err
		}
	}

	return nil
}
