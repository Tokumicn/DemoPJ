package common

import "fmt"

func (conf *QueryCHConfig) FakeQuery() ([]map[string]interface{}, error) {
	fmt.Println("=======================高级搜索========================")
	fmt.Println("SQL: ", conf.SQL)
	fmt.Printf("Args: %#v\n", conf.Args)
	fmt.Println("=======================高级搜索End========================")
	return nil, nil
}

func (conf *QueryPGConfig) FakeQuery() ([]map[string]interface{}, error) {
	fmt.Println("=======================高级搜索========================")
	fmt.Println("SQL: ", conf.SQL)
	fmt.Printf("Args: %#v\n", conf.Args)
	fmt.Println("=======================高级搜索End========================")
	return nil, nil
}
