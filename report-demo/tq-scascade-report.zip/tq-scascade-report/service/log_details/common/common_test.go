package common

import (
	"git-biz.qianxin-inc.cn/eps/skylar/apps/libs/tianqing.git/logs"
	"git-biz.qianxin-inc.cn/eps/skylar/apps/libs/tianqing.git/utils"
	"testing"
	"time"
	"tq-scascade-report/pkg/def"
	"tq-scascade-report/pkg/model"
	"tq-scascade-report/pkg/postgres"
)

func init() {
	logs.Init(logs.Config{
		Writer: "console",
		Level:  "debug",
	})

	postgres.InitPostgresDB(&postgres.Config{
		Host:            "10.44.202.12",
		Port:            "5432",
		User:            "postgres",
		Password:        "postgres",
		DBName:          "dataportal",
		ApplicationName: "tq-scascade-report",
		MaxIdle:         2,
		MaxOpen:         4,
		MaxLife:         600,
		Mock:            true,
	})
}

func TestCommonGetLogDetailsData(t *testing.T) {

	reqData := &model.QueryLogDetailsRequest{
		BusinessCode:   def.SCORE,
		CCID:           "CCID_AAA,CCID_AAA",
		StartTime:      &utils.JSONTime{T: time.Now().AddDate(0, 3, 0)},
		EndTime:        &utils.JSONTime{T: time.Now()},
		PageSize:       20,
		Current:        2,
		Order:          -1,
		OrderCondition: "",
	}

	advance01 := &model.AdvanceSearch{
		RelationTemplate: "$1 OR $2",
		Conditions: []*model.Condition{
			&model.Condition{
				Op:    "gt",
				Key:   "score",
				Value: 88,
			},
			&model.Condition{
				Op:    "lte",
				Key:   "score",
				Value: 98,
			},
		},
	}
	reqData.AdvanceSearch = advance01

	_, _, err := CommonGetLogDetailsData(reqData, def.CLICKHOUSE_DBType)
	if err != nil {
		t.Fatal(err)
	}
}
