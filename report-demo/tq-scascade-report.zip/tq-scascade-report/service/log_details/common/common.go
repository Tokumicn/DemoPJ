package common

import (
	"fmt"
	"git-biz.qianxin-inc.cn/eps/skylar/apps/libs/tianqing.git/logs"
	"tq-scascade-report/pkg/advanced_search"
	"tq-scascade-report/pkg/def"
	"tq-scascade-report/pkg/model"
	"tq-scascade-report/service/log_details/custom_column"
	"tq-scascade-report/service/log_details/security"
	"tq-scascade-report/service/value_convert"
)

// 获取日志详情信息
func CommonGetLogDetailsData(reqData *model.QueryLogDetailsRequest, dbType string) ([]map[string]interface{}, int, error) {

	// 创建查询语句
	querySql, totalSql, args, err := execSQLBuild(reqData, dbType)
	if err != nil {
		return nil, -1, err
	}

	// 查询数据
	rawData, total, err := execQuery(querySql, totalSql, args, dbType)
	if err != nil {
		return nil, -1, err
	}

	// 通用功能，包括报表
	// 根据 BusinessCode 获取日志详情的
	logDetailsCode := makeLogDetailsCode(reqData.BusinessCode)
	res := make([]map[string]interface{}, 0)
	for _, row := range rawData {
		completeRow, err := value_convert.RowValueConvert(row, logDetailsCode, -1)
		if err != nil {
			logs.Errorf("RowValueConvert error: %s", err.Error())
			res = append(res, row) // 转换失败则保持原样
		}
		res = append(res, completeRow)
	}

	return res, total, nil
}

func execQuery(querySql, totalSql string, args map[string]interface{}, dbType string) ([]map[string]interface{}, int, error) {
	var (
		res   []map[string]interface{}
		total int
		err   error
	)
	if dbType == def.CLICKHOUSE_DBType {
		// 获取查询结果
		chQuery := &QueryCHConfig{
			SQL:  querySql,
			Args: args,
		}
		res, err = chQuery.Query()
		if err != nil {
			return nil, -1, err
		}

		// 获取total
		chTotal := &QueryCHConfig{
			SQL:  totalSql,
			Args: args,
		}
		totalRes, err := chTotal.Query()
		if err != nil {
			return nil, -1, err
		}

		total64 := totalRes[0]["total"].(uint64)
		total = int(total64)

	} else if dbType == def.POSTGRES_DBType {
		// 获取查询结果
		pgQuery := &QueryPGConfig{
			SQL:  querySql,
			Args: args,
		}
		res, err = pgQuery.Query()
		if err != nil {
			return nil, -1, err
		}

		// 获取total
		pgTotal := &QueryPGConfig{
			SQL:  totalSql,
			Args: args,
		}
		totalRes, err := pgTotal.Query()
		if err != nil {
			return nil, -1, err
		}

		total64 := totalRes[0]["total"].(int64)
		total = int(total64)
	}

	return res, total, nil
}

func execSQLBuild(reqData *model.QueryLogDetailsRequest, dbType string) (string, string, map[string]interface{}, error) {
	securityConfig, ok := security.BusinessSecurityColumnsConfigMap[reqData.BusinessCode]
	if !ok {
		return "", "", nil, fmt.Errorf("[security.BusinessSecurityColumnsConfigMap]获取查询配置失败. [BusinessCode: %s]", reqData.BusinessCode)
	}

	// 获取自定义列配置  获取不到则使用默认配置
	customCols, _, err := custom_column.GetCustomColumnFieldsArray(reqData.BusinessCode)
	if err != nil {
		return "", "", nil, err
	}

	// 拼接查询SQL
	var q *model.Query
	if reqData.AdvanceSearch != nil {
		q = &model.Query{
			RelationTemplate: reqData.AdvanceSearch.RelationTemplate,
			Conditions:       reqData.AdvanceSearch.Conditions,
		}
	}

	search := &model.AdvancedSearch{
		BusinessCode: reqData.BusinessCode,
		Select:       customCols,
		PagingArgs: &model.PagingArgs{
			Current:  reqData.Current,
			PageSize: reqData.PageSize,
			DBType:   dbType,
		},
		OrderArgs:      &model.OrderArgs{},
		SecurityConfig: securityConfig,
		BasicSearch: &model.BasicSearch{
			CCIDs:     reqData.CCIds,
			StartTime: reqData.StartTime,
			EndTime:   reqData.EndTime,
		},
		AdvancedQuery: q,
	}

	// 资产数据以id排序
	if dbType == def.POSTGRES_DBType {
		search.OrderArgs.Order = -1
		search.OrderArgs.OrderCondition = "id"
	}

	if len(reqData.OrderCondition) > 0 {
		search.OrderArgs.OrderCondition = reqData.OrderCondition
		search.OrderArgs.Order = reqData.Order
	}

	// 针对审计日志的特殊处理  增加额外参数AuditType
	if reqData.BusinessCode == def.AUDIT && reqData.Ext != nil {
		search.BasicSearch.AuditType = reqData.Ext.AuditType
	}

	querySql, totalSql, args, err := advanced_search.SqlBuilder(search)
	if err != nil {
		return "", "", nil, err
	}

	return querySql, totalSql, args, nil
}

// 为了将日志详情和定时报表的转换配置统一，需要一个标记该业务的唯一标识
func makeLogDetailsCode(businessCode string) string {
	logDetailCodePrefix := "LOG"
	logDetailCodeSuffix := "CODE"
	return fmt.Sprintf("%s_%s_%s", logDetailCodePrefix, businessCode, logDetailCodeSuffix)
}
