package common

import (
	"tq-scascade-report/pkg/clickhouse"
)

type QueryCHConfig struct {
	SQL  string
	Args map[string]interface{} // 查询参数
}

func (conf *QueryCHConfig) Query() ([]map[string]interface{}, error) {
	stmt, err := clickhouse.GetClickHouseDB().PrepareNamed(conf.SQL)
	if err != nil {
		return nil, err
	}

	rows, err := stmt.Queryx(conf.Args)
	if err != nil {
		return nil, err
	}

	defer rows.Close()

	var res []map[string]interface{}
	for rows.Next() {
		m := map[string]interface{}{}
		err := rows.MapScan(m)
		if err != nil {
			return nil, err
		}
		res = append(res, m)
	}

	return res, nil
}
