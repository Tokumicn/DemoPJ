package common

import (
	"github.com/jmoiron/sqlx"
	"tq-scascade-report/pkg/postgres"
)

const PGDBName = ""

type QueryPGConfig struct {
	SQL  string
	Args map[string]interface{} // 查询参数
}

func (conf *QueryPGConfig) Query() ([]map[string]interface{}, error) {
	db := postgres.GetDefaultPostgresDB()
	query, arg, err := sqlx.Named(conf.SQL, conf.Args)
	query, arg, err = sqlx.In(query, arg...)
	query = db.Rebind(query)
	rows, err := db.Queryx(query, arg...)
	if err != nil {
		return nil, err
	}

	defer rows.Close()

	var res []map[string]interface{}
	for rows.Next() {
		m := map[string]interface{}{}
		err := rows.MapScan(m)
		if err != nil {
			return nil, err
		}
		res = append(res, m)
	}

	return res, nil
}
