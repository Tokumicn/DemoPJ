package custom_column

import "testing"

func TestCustomColumnsConfigReadAndUnMarshal(t *testing.T) {
	path := "../../../config/custom_cols.json"
	customConfig, err := readCustomConfig(path)
	if err != nil {
		t.Fatal(err)
	}
	t.Logf("%#v", customConfig)
}
