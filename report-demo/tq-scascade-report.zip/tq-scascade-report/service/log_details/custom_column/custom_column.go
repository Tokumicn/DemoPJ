package custom_column

import (
	"encoding/json"
	"fmt"
	"git-biz.qianxin-inc.cn/eps/skylar/apps/libs/tianqing.git/logs"
	"git-biz.qianxin-inc.cn/eps/skylar/apps/libs/tianqing.git/utils"
	"strings"
	"time"
	"tq-scascade-report/pkg/dao"
	"tq-scascade-report/pkg/model"
	"tq-scascade-report/service/log_details/security"
)

// ---自定义列---
// [根据业务]获取 自定义列
func GetCustomColumns(businessCode string) (*model.CustomColumnViewModel, error) {

	var (
		customCols *dao.QueryCustomColumn
		err        error
	)
	dto := &dao.QueryCustomColumn{
		BusinessCode: businessCode,
	}

	queryCustomCols, err := dto.GetByBusinessCode()
	if err != nil {
		return nil, err
	}

	if queryCustomCols == nil || queryCustomCols.Id <= 0 {
		customCols, err = initCustomColumns(businessCode)
		if err != nil {
			return nil, err
		}
	} else {
		customCols = queryCustomCols
	}

	customColMap := strings.Split(customCols.CustomColumn, ",")
	optionalColMap := strings.Split(customCols.OptionalColumn, ",")

	allColumnMap := make(map[string]string)
	err = json.Unmarshal([]byte(customCols.AllColumnMap), &allColumnMap)
	if err != nil {
		return nil, err
	}

	result := &model.CustomColumnViewModel{
		Id:             customCols.Id,
		BusinessCode:   customCols.BusinessCode,
		AllColumns:     allColumnMap,
		CustomColumn:   customColMap,
		OptionalColumn: optionalColMap,
	}

	return result, nil
}

// [根据Id]更新 自定义列
func UpdateCustomColumns(reqData *model.UpdateCustomColumnRequest) error {
	dto := dao.QueryCustomColumn{
		BusinessCode: reqData.BusinessCode,
	}

	oldColumns, err := dto.GetByBusinessCode()
	if err != nil {
		return err
	}

	// 初始化[新建]
	if oldColumns == nil || oldColumns.Id <= 0 {
		_, err = initCustomColumns(reqData.BusinessCode)
		if err != nil {
			return err
		}
	}

	customColStr := strings.Join(reqData.CustomColumn, ",")
	optionalColStr := strings.Join(reqData.OptionalColumn, ",")

	// 更新
	dto.Id = oldColumns.Id
	dto.TableName = oldColumns.TableName
	dto.CustomColumn = customColStr
	dto.OptionalColumn = optionalColStr
	dto.AllColumnMap = oldColumns.AllColumnMap
	dto.CreateTime = oldColumns.CreateTime
	dto.UpdateTime = &utils.JSONTime{T: time.Now()}

	_, _, _, err = dto.Update(oldColumns.Id)
	if err != nil {
		return err
	}

	return nil
}

// 第一次创建默认自定义列
func initCustomColumns(businessCode string) (*dao.QueryCustomColumn, error) {
	defaultColuns, ok := DefaultCustomConfigMap[businessCode]
	if !ok {
		logs.Errorf("initCustomColumns 未获取到默认自定义列信息[business: %s]", businessCode)
		return nil, fmt.Errorf("未获取到默认自定义列信息.")
	}

	customColArr := make([]string, 0)
	optionalColArr := make([]string, 0)
	allColMap := make(map[string]string, 0)

	for k, v := range defaultColuns.CustomColumn {
		allColMap[k] = v
		customColArr = append(customColArr, k)
	}

	for k, v := range defaultColuns.OptionalColumn {
		allColMap[k] = v
		optionalColArr = append(optionalColArr, k)
	}

	allColBytes, err := json.Marshal(allColMap)
	if err != nil {
		return nil, err
	}

	dto := &dao.QueryCustomColumn{
		BusinessCode:   businessCode,
		TableName:      defaultColuns.TableName,
		AllColumnMap:   string(allColBytes),
		CustomColumn:   strings.Join(customColArr, ","),
		OptionalColumn: strings.Join(optionalColArr, ","),
		CreateTime:     &utils.JSONTime{T: time.Now()},
		UpdateTime:     &utils.JSONTime{T: time.Now()},
	}

	err = dto.Create()
	if err != nil {
		return nil, err
	}

	return dto, nil
}

// 获取自定义字段
func GetCustomColumnFieldsArray(businessCode string) (string, []string, error) {
	var cols string

	columns, err := GetCustomColumns(businessCode)
	if err != nil {
		logs.Errorf("DB获取自定义列失败. [businessCode: %s]", businessCode)

		// 获取不到使用默认配置
		if columnsConfig, ok := security.BusinessSecurityColumnsConfigMap[businessCode]; ok {
			cols = columnsConfig.DefaultColumns
		}
	} else {
		cols = strings.Join(columns.CustomColumn, ",")
	}

	if len(cols) <= 0 {
		return "", nil, fmt.Errorf("获取自定义列失败. [businessCode: %s]", businessCode)
	}

	if columns == nil || len(columns.CustomColumn) <= 0 {
		return "", nil, fmt.Errorf("获取自定义列失败. [businessCode: %s]", businessCode)
	}

	return cols, columns.CustomColumn, nil
}
