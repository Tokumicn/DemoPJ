package custom_column

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"tq-scascade-report/pkg/def"
)

type CustomColumnConfig struct {
	TableName      string            `json:"tableName"`
	CustomColumn   map[string]string `json:"customColumn"`   // 自定义显示列
	OptionalColumn map[string]string `json:"optionalColumn"` // 可选自定义列
}

var DefaultCustomConfigMap = map[string]*CustomColumnConfig{}

func InitDefaultCustomConfigMapFromJson() error {
	customConfig, err := readCustomConfig(def.CUSTOM_COLS_PATH)
	if err != nil {
		return err
	}
	if customConfig == nil {
		return fmt.Errorf("读取自定义配置信息失败.")
	}
	DefaultCustomConfigMap = customConfig
	return nil
}

func readCustomConfig(path string) (map[string]*CustomColumnConfig, error) {
	b, err := ioutil.ReadFile(path)
	if err != nil {
		return nil, err
	}

	marshalMap := make(map[string]*CustomColumnConfig, 0)
	err = json.Unmarshal(b, &marshalMap)
	if err != nil {
		return nil, err
	}

	return marshalMap, nil
}
