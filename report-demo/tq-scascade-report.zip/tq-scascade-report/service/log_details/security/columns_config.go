package security

import "tq-scascade-report/pkg/def"

type ColumnsConfig struct {
	// 表名
	TableName string
	// 默认的查询列 ==> 查询不到DB中配置信息时使用
	DefaultColumns string
	// 允许查询的列
	AllowQueryColumns map[string]int
	// 允许排序的列
	AllowOrderColumns map[string]int
}

var BusinessSecurityColumnsConfigMap = map[string]*ColumnsConfig{
	// 资产
	def.ASSET: {
		TableName:      def.ASSET_SCOURSE_DATA_TABLENAME,
		DefaultColumns: "client_mid, client_name, client_ip, client_gid, client_os, client_mac, client_login_user, client_group_path, client_group_name, ccid, client_hardware_cpu_core_count, client_hardware_cpu_frequency, client_hardware_harddisk_size, client_hardware_memory_size, client_hardware_monitor_size", // 计算机名、IP地址、MAC地址、分组、所属控制中心、主程序版本、病毒库时间、补丁库版本、操作系统、实名账号
		AllowQueryColumns: map[string]int{
			"id":                                 1,
			"client_mid":                         1,
			"client_name":                        1,
			"client_ip":                          1,
			"client_report_ip":                   1,
			"client_mac":                         1,
			"client_gid":                         1,
			"client_group_name":                  1,
			"client_group_path":                  1,
			"ccid":                               1,
			"last_time":                          1,
			"ext_main_ver":                       1,
			"ext_virus_lib_date":                 1,
			"ext_leaklib_ver":                    1,
			"client_os":                          1,
			"nac_user_user_name":                 1,
			"nac_user_full_name":                 1,
			"client_login_user":                  1,
			"client_os_domain_name":              1,
			"client_type":                        1,
			"client_os_small_version":            1,
			"client_os_edition_id":               1,
			"client_os_small_version_edition_id": 1,
			"hardware_summary_device_type":       1,
			"hardware_summary_description":       1,
			"hardware_summary_cpu":               1,
			"hardware_summary_memory":            1,
			"hardware_summary_harddisk":          1,
			"hardware_summary_displaycar":        1,
			"hardware_summary_monito":            1,
			"hardware_harddisk_serial_number":    1,
			"hardware_summary_serial_number":     1,
			"os_lang":                            1,
			"os_osspa":                           1,
			"os_install_date":                    1,
			"hardware_summary_device_use":        1,
			"hardware_summary_username":          1,
			"hardware_summary_user_number":       1,
			"hardware_summary_mobile":            1,
			"hardware_summary_email":             1,
			"hardware_summary_location":          1,
			"hardware_summary_telephone":         1,
			"hardware_summary_memo":              1,
			"client_hardware_cpu_core_count":     1, // -- int client_hardware_cpu.core_count  CPU核心数
			"client_hardware_cpu_frequency":      1, //  float64 client_hardware_cpu.frequency 主频
			"client_hardware_harddisk_size":      1, //  int64 client_hardware_harddisk.size 硬盘
			"client_hardware_memory_size":        1, //  int client_hardware_memory.size 内存大小
			"client_hardware_monitor_size":       1, //  float64 client_hardware_monitor.size 显示器尺寸
		},
		AllowOrderColumns: map[string]int{
			"id":   1,
			"ccid": 1,
		},
	},

	// 扫描分析
	def.SCORE: {
		TableName:      def.SCORE_SCOURSE_DATA_TABLENAME,
		DefaultColumns: "client_mid, client_name, client_ip, client_gid, client_os, client_mac,client_third_login_user, client_grouppath, client_groupname, ccid, exam_score, leak_num, virus_num, event_time", // 计算机名、IP地址、MAC地址、分组、所属控制中心、主程序版本、病毒库时间、补丁库版本、操作系统、实名账号
		AllowQueryColumns: map[string]int{
			"client_mid":              1,
			"client_name":             1,
			"client_nickname":         1,
			"client_displayname":      1,
			"client_reportip":         1,
			"client_ip":               1,
			"client_gid":              1,
			"client_os":               1,
			"client_mac":              1,
			"client_third_login_user": 1,
			"client_login_user":       1,
			"client_groupname":        1,
			"client_grouppath":        1,
			"ccid":                    1,
			"exam_score":              1,
			"leak_num":                1,
			"virus_num":               1,
			"event_time":              1,
		},
		AllowOrderColumns: map[string]int{
			"event_time": 1,
			"ccid":       1,
			"exam_score": 1,
		},
	},

	// 病毒分析
	def.VIRUS: {
		TableName:      def.VIRUS_SCOURSE_DATA_TABLENAME,
		DefaultColumns: `event_time, client_name, client_ip, client_mac, client_third_login_user, client_os, from, vname, md5, sha1, path, task_id, op`,
		AllowQueryColumns: map[string]int{
			"client_mid":              1,
			"client_name":             1,
			"client_nickname":         1,
			"client_displayname":      1,
			"client_reportip":         1,
			"client_ip":               1,
			"client_gid":              1,
			"client_os":               1,
			"client_mac":              1,
			"client_third_login_user": 1,
			"client_login_user":       1,
			"client_groupname":        1,
			"client_grouppath":        1,
			"ccid":                    1,
			"md5":                     1,
			"op":                      1, // 【处理结果】
			"path":                    1,
			"sha1":                    1,
			"task_id":                 1, // 【触发方式】  该字段查询时需要特殊转换
			"type":                    1,
			"vname":                   1,
			"virus_cat":               1,
			"from":                    1,
			"event_time":              1,
		},
		AllowOrderColumns: map[string]int{
			"ccid": 1,
		},
	},

	// 漏洞分析
	def.LEAK: {
		TableName: def.LEAK_SCOURSE_DATA_TABLENAME,
		// 计算机名、IP地址、MAC地址、分组、所属控制中心、主程序版本、病毒库时间、补丁库版本、操作系统、实名账号
		DefaultColumns: "client_mid, client_name, client_ip, client_gid, client_os, client_mac,client_third_login_user, client_grouppath, client_groupname, ccid, kbid, leak_type, event_action, event_time, leak_name",
		AllowQueryColumns: map[string]int{
			"client_mid":              1,
			"client_name":             1,
			"client_nickname":         1,
			"client_displayname":      1,
			"client_reportip":         1,
			"client_ip":               1,
			"client_gid":              1,
			"client_os":               1,
			"client_mac":              1,
			"client_third_login_user": 1,
			"client_login_user":       1,
			"client_groupname":        1,
			"client_grouppath":        1,
			"ccid":                    1,
			"prestatus":               1,
			"currstatus":              1,
			"reason":                  1,
			"event_action":            1,
			"leak_type":               1,
			"event_time":              1,
			"kbid":                    1,
			"leak_name":               1, // 补丁名称
		},
		AllowOrderColumns: map[string]int{
			"event_time": 1,
			"ccid":       1,
			"kbid":       1,
			"leak_type":  1,
		},
	},

	// 告警事件
	def.ALERT: {
		TableName:      def.ALERT_SCOURSE_DATA_TABLENAME,
		DefaultColumns: "event_time, client_name, client_ip, client_mac, client_third_login_user, account, client_gid, ccid, client_os, type, content, format_content",
		AllowQueryColumns: map[string]int{
			"client_mid":              1,
			"client_name":             1,
			"client_nickname":         1,
			"client_displayname":      1,
			"client_reportip":         1,
			"client_ip":               1,
			"client_gid":              1,
			"client_os":               1,
			"client_mac":              1,
			"client_third_login_user": 1,
			"client_login_user":       1,
			"client_groupname":        1,
			"client_grouppath":        1,
			"ccid":                    1,
			"type":                    1,
			"account":                 1,
			"content":                 1,
			"format_content":          1,
			"datetime":                1,
			"event_time":              1,
		},
		AllowOrderColumns: map[string]int{
			"event_time": 1,
			"ccid":       1,
			"type":       1,
		},
	},

	// 审计
	def.AUDIT: {
		TableName:      "skylar_scascade.audit",
		DefaultColumns: "event_time, client_name, client_mac, client_third_login_user, client_gid, ccid, account, client_os, type, format_content, content ",
		AllowQueryColumns: map[string]int{
			"client_mid":              1,
			"client_name":             1,
			"client_nickname":         1,
			"client_displayname":      1,
			"client_reportip":         1,
			"client_ip":               1,
			"client_gid":              1,
			"client_os":               1,
			"client_mac":              1,
			"client_third_login_user": 1,
			"client_login_user":       1,
			"client_groupname":        1,
			"client_grouppath":        1,
			"ccid":                    1,
			"type":                    1,
			"account":                 1,
			"content":                 1,
			"format_content":          1,
			"occur_time":              1,
			"event_time":              1,
		},
		AllowOrderColumns: map[string]int{
			"event_time": 1,
			"ccid":       1,
			"type":       1,
		},
	},
}
