// 日志详情: 数据从ClickHouse

package log_details

import (
	"encoding/json"
	"fmt"
	"git-biz.qianxin-inc.cn/eps/skylar/apps/libs/tianqing.git/logs"
	"git-biz.qianxin-inc.cn/eps/skylar/apps/libs/tianqing.git/utils"
	"time"
	"tq-scascade-report/pkg/dao"
	"tq-scascade-report/pkg/def"
	"tq-scascade-report/pkg/model"
	"tq-scascade-report/service/cascade_config"
	"tq-scascade-report/service/log_details/common"
)

// ---条件模板---
// [根据业务]获取 条件模板列表
func GetConditionTemplateList(businessCode string) ([]*model.ConditionTemplateViewModel, error) {

	cdTlp := dao.ConditionTemplate{
		BusinessCode: businessCode,
	}

	conditionTemplates, err := cdTlp.GetByBusinessCode()
	if err != nil {
		return nil, err
	}

	viewList := make([]*model.ConditionTemplateViewModel, 0)

	for _, tlp := range conditionTemplates {

		conditionList := make([]*model.Condition, 0)
		err := json.Unmarshal([]byte(tlp.Conditions), &conditionList)
		if err != nil {
			logs.Errorf("[GetConditionTemplateList--JsonUnmarshal] [conditions: %s] [err: %s]", tlp.Conditions, err.Error())
			continue
		}

		tempTlp := &model.ConditionTemplateViewModel{
			Id:               tlp.Id,
			Name:             tlp.Name,
			BusinessCode:     tlp.BusinessCode,
			Conditions:       conditionList,
			RelationTemplate: tlp.RelationTemplate,
		}

		viewList = append(viewList, tempTlp)
	}

	return viewList, nil
}

// [根据Id]更新 条件模板内容
func UpdateConditionTemplate(request *model.UpdateConditionTemplateRequest) error {

	condBytes, err := json.Marshal(request.Conditions)
	if err != nil {
		return err
	}
	conditionJson := string(condBytes)

	if request.Id > 0 { // 更新
		dto := dao.ConditionTemplate{
			Id: request.Id,
		}

		oldTlp, err := dto.Get()
		if err != nil {
			return err
		}

		if oldTlp.Conditions != conditionJson {
			oldTlp.Conditions = conditionJson
		}
		if oldTlp.RelationTemplate != request.RelationTemplate {
			oldTlp.RelationTemplate = request.RelationTemplate
		}
		oldTlp.UpdateTime = &utils.JSONTime{T: time.Now()}

		_, _, _, err = oldTlp.Update(request.Id)
		if err != nil {
			return err
		}

	} else { // 新建
		dto := dao.ConditionTemplate{
			Name:         request.Name,
			BusinessCode: request.BusinessCode,
		}

		templates, err := dto.GetByNameAndCode()
		if err != nil {
			return err
		}

		if len(templates) > 0 {
			return fmt.Errorf("模板名称重复,请修改后重试.")
		}

		dto.Conditions = conditionJson
		dto.RelationTemplate = request.RelationTemplate
		dto.CreateTime = &utils.JSONTime{T: time.Now()}
		dto.UpdateTime = &utils.JSONTime{T: time.Now()}

		err = dto.Create()
		if err != nil {
			return err
		}
	}

	return nil
}

// [根据Id]删除 条件模板
func DeleteConditionTemplate(id int64) error {
	condition := &dao.ConditionTemplate{
		Id: id,
	}

	return condition.Delete()
}

// ---筛选字段列表---
// [根据业务]获取 可选筛选字段列表
func GetQueryFields(businessCode string) (interface{}, error) {

	return def.GetOptionalFieldsFilterConfig(businessCode)

	// 暂不提供DB配置支持，后续迭代时再做
	//dto := dao.XXXQueryFieldsConfigXXX{
	//	BusinessCode: businessCode,
	//}
	//
	//conf, err := dto.GetByBusinessCode()
	//if err != nil {
	//	return nil, err
	//}
	//
	//result := &model.QueryFieldViewModel{
	//	Id:            conf.Id,
	//	BusinessCode:  conf.BusinessCode,
	//	FieldName:     conf.FieldName,
	//	DisplayName:   conf.DisplayName,
	//	Operation:     conf.Operation,
	//	OptionalValue: conf.OptionalValue,
	//}
	//return result, nil
}

// -----------------非业务需要，配置需要-----------------
// ---自定义列---
// [根据id]删除 可选筛选字段列表
func DeleteCustomColumns(id int64) error {
	dto := &dao.QueryCustomColumn{
		Id: id,
	}

	return dto.Delete()
}

// ---可选筛选字段---
// [根据id]修改 可选筛选字段列表

// [根据id]删除 可选筛选字段列表
func DeleteQueryFields(id int64) error {
	dto := &dao.XXXQueryFieldsConfigXXX{
		Id: id,
	}

	return dto.Delete()
}

// ---日志详情配置---
// 创建 日志详情业务
// 修改 日志详情业务
// 删除 日志详情业务
// 列表 日志详情业务列表

func QueryByFilter(reqData *model.QueryLogDetailsRequest) (*model.LogDetailViewModel, error) {

	topCCIdArr, err := cascade_config.GetLogDetailCCIdListByTop(reqData.TopCCId)
	if err != nil {
		return nil, err
	}
	reqData.CCIds = topCCIdArr

	// 获取日志详情数据
	rawData, total, err := getLogDetailRawData(reqData)
	if err != nil {
		return nil, err
	}

	var detail = &model.LogDetailViewModel{
		Total:  total,
		Detail: rawData,
	}

	return detail, nil
}

func getLogDetailRawData(reqData *model.QueryLogDetailsRequest) ([]map[string]interface{}, int, error) {
	switch reqData.BusinessCode {
	case def.ASSET: // IT资产日志
		return common.CommonGetLogDetailsData(reqData, def.POSTGRES_DBType)
	case def.SCORE, // 扫描分数日志
		def.VIRUS, // 病毒分析日志
		def.LEAK,  // 漏洞分析日志
		def.ALERT, // 告警事件日志
		def.AUDIT: // 审计日志
		return common.CommonGetLogDetailsData(reqData, def.CLICKHOUSE_DBType)
	default:
		return nil, -1, fmt.Errorf("business[%s] is invalid.", reqData.BusinessCode)
	}
}
