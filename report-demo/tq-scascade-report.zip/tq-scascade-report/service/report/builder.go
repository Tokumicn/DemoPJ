package report

import (
	"fmt"
	"tq-scascade-report/pkg/def"
)

// 除汇总统计外报表查询条件
type QueryCondition struct {
	CCIDs      []string            `json:"ccIds"`
	Business   string              `json:"business"`   // 所属业务 -- 确定表名
	ReportType string              `json:"reportType"` // 报表类型 -- 确定查询类型（Group By、SUM、TOP等）
	TimeScale  string              `json:"timeScale"`  // 时间刻度
	TimeRange  string              `json:"timeRange"`  // 时间范围
	StartTime  string              `json:"startTime"`
	EndTime    string              `json:"endTime"`
	TopCCId    string              `json:"topCCId"`
	TopCCIdMap map[string][]string `json:"topCCIdMap"` // 【仅汇总统计使用】 TopCCId : [{ccid1}, {ccid2}, ...]
}

func (q *QueryCondition) BuildReportExec() (*ReportExec, error) {

	var (
		repoExec *ReportExec
		err      error
	)
	switch q.Business {
	case def.SCORE: // 扫描分数
		repoExec, err = q.scoreTemplate()
	case def.VIRUS: // 病毒分析
		repoExec, err = q.virusTemplate()
	case def.LEAK: // 漏洞分析
		repoExec, err = q.leakTemplate()
	case def.ALERT: // 告警分析
		repoExec, err = q.alertTemplate()
	//case def.ASSET: // 资产
	//case def.AUDIT: // 审计
	default:
		return nil, fmt.Errorf("business[%s] reportType[%s] parameter error.", q.Business, q.ReportType)
	}

	if err != nil {
		return nil, err
	}

	// 填入传入查询传参数，方便记录日志
	repoExec.Condition = q
	return repoExec, nil
}

func (q *QueryCondition) scoreTemplate() (*ReportExec, error) {

	switch q.ReportType {
	case def.SUMMARIZE: // 汇总统计
		return q.NewScoreSUMMARIZEReport()
	case def.CCID: // 按控制中心统计
		return q.NewScoreCCIDReport()
	default:
		return nil, fmt.Errorf("reporttpl type error. [business: %s][reportType: %s]", q.Business, q.ReportType)
	}
}

func (q *QueryCondition) virusTemplate() (*ReportExec, error) {
	switch q.ReportType {
	case def.SUMMARIZE: // 按汇总统计
		return q.NewVirusSUMMARIZEReport()
	case def.CCID: // 按控制中心统计
		return q.NewVirusCCIDReport()
	case def.CLIENT: // 按客户端统计
		return q.NewVirusClientReport()
	case def.VIRUS: // 按病毒统计
		return q.NewVirusNameReport()
	default:
		return nil, fmt.Errorf("reporttpl type error. [business: %s][reportType: %s]", q.Business, q.ReportType)
	}
}

func (q *QueryCondition) leakTemplate() (*ReportExec, error) {
	switch q.ReportType {
	case def.SUMMARIZE: // 按汇总统计
		return q.NewLeakSUMMARIZEReport()
	case def.CCID: // 按控制中心统计
		return q.NewLeakCCIDReport()
	case def.CLIENT: // 按客户端统计
		return q.NewLeakClientReport()
	case def.PATCHES: // 按补丁统计
		return q.NewLeakPatchReport()
	default:
		return nil, fmt.Errorf("reporttpl type error. [business: %s][reportType: %s]", q.Business, q.ReportType)
	}
}

func (q *QueryCondition) alertTemplate() (*ReportExec, error) {
	switch q.ReportType {
	case def.SUMMARIZE:
		return q.NewAlertSUMMARIZEReport()
	default:
		return nil, fmt.Errorf("reporttpl type error. [business: %s][reportType: %s]", q.Business, q.ReportType)
	}
}
