package report

import (
	"fmt"
	"git-biz.qianxin-inc.cn/eps/skylar/apps/libs/tianqing.git/logs"
	"tq-scascade-report/pkg/postgres"
)

type SavePGConfig struct {
	TableName  string
	InsertArgs []string
}

// 单行插入  sqlx@1.2.0 ==> @release
func (s_pg *SavePGConfig) Save(data []map[string]interface{}) error {

	for _, val := range data {
		createSql := buildInsertSql(s_pg.InsertArgs, s_pg.TableName)
		stmt, err := postgres.GetDefaultPostgresDB().PrepareNamed(createSql)
		if err != nil {
			logs.Error(err)
			continue
		}

		result, err := stmt.Exec(val)
		if err != nil {
			logs.Error(err)
			continue
		}

		rowsAffected, err := result.RowsAffected()
		if err != nil {
			logs.Error(err)
		}

		logs.Debug("rowsAffected: ", rowsAffected)
	}

	return nil
}

// 批量插入  sqlx@1.2.1 ===> @master
func (s_pg *SavePGConfig) BatchInsert(data []map[string]interface{}) error {

	// 查询无结果 无需存储
	if len(data) <= 0 {
		return nil
	}

	if len(s_pg.InsertArgs) <= 0 {
		return fmt.Errorf("insert args config err. args[%v]", s_pg.InsertArgs)
	}

	insertSql := buildInsertSql(s_pg.InsertArgs, s_pg.TableName)

	batchSize := 1000
	length := len(data)
	start := 0
	end := 0
	for {
		if length < batchSize {
			end = length
		} else {
			end = start + batchSize
		}

		// 防止数据不足batchSize时,拷贝不越界
		if end > length {
			end = length
		}

		batchSlice := data[start:end]

		result, err := postgres.GetDefaultPostgresDB().NamedExec(insertSql, batchSlice)
		if err != nil {
			return err
		}

		rowsAffected, err := result.RowsAffected()
		if err != nil {
			logs.Error(err)
		}

		logs.Debug("rowsAffected: ", rowsAffected)

		if end >= length {
			break
		}

		start = end
	}

	return nil
}

func buildInsertSql(insertArgs []string, tableName string) string {
	var insertFields string
	var insertParams string
	for i := 0; i < len(insertArgs)-1; i++ {
		insertFields += fmt.Sprintf("%s, ", insertArgs[i])
		insertParams += fmt.Sprintf(":%s, ", insertArgs[i])
	}
	lastArg := insertArgs[len(insertArgs)-1]
	insertFields += fmt.Sprintf("%s", lastArg)
	insertParams += fmt.Sprintf(":%s", lastArg)

	return fmt.Sprintf("INSERT INTO %s (%s) VALUES (%s)", tableName, insertFields, insertParams)
}
