// 病毒分析报表

package report

import (
	"fmt"
	"tq-scascade-report/pkg/def"
)

// 结果存储表
const (
	virusSumResultTableName = "scascade_virus_summarize"

	virusCCIDResultTableName = "scascade_virus_ccid"

	virusClientResultTableName = "scascade_virus_client"

	virusNameResultTableName = "scascade_virus_name"
)

// 源数据表
const virusSumSourceTableName = def.VIRUS_SCOURSE_DATA_TABLENAME

// 汇总统计通用存储字段列表
var virusSumDataInputArgs = []string{"result_id", "top_ccid", "data_type", "ext", "create_time"}

// 按汇总统计
func (q *QueryCondition) NewVirusSUMMARIZEReport() (*ReportExec, error) {

	exec := &ReportExec{}

	// 汇总统计--趋势图--病毒名
	trendNameReport, err := q.buildVirusSUMMARIZE_TrendNameReport()
	if err != nil {
		return nil, err
	}
	exec.SubReport = append(exec.SubReport, trendNameReport...)

	// 汇总统计--趋势图--查杀次数
	trendKillCountReport, err := q.buildVirusSUMMARIZE_TrendKillCountReport()
	if err != nil {
		return nil, err
	}
	exec.SubReport = append(exec.SubReport, trendKillCountReport...)

	// 汇总统计--趋势图--查杀终端数
	trendClientCountReport, err := q.buildVirusSUMMARIZE_TrendClientCountReport()
	if err != nil {
		return nil, err
	}
	exec.SubReport = append(exec.SubReport, trendClientCountReport...)

	// 汇总统计--病毒种类占比
	catPerReport, err := q.buildVirusSUMMARIZE_CatPerReport()
	if err != nil {
		return nil, err
	}
	exec.SubReport = append(exec.SubReport, catPerReport...)

	// 汇总统计--病毒处理占比
	optionPerReport, err := q.buildVirusSUMMARIZE_OptionPerReport()
	if err != nil {
		return nil, err
	}
	exec.SubReport = append(exec.SubReport, optionPerReport...)

	// 汇总统计--触发方式占比
	taskPerReport, err := q.buildVirusSUMMARIZE_TaskPerReport()
	if err != nil {
		return nil, err
	}
	exec.SubReport = append(exec.SubReport, taskPerReport...)

	// 汇总统计--感染病毒最多终端Top10
	clientTop10Report, err := q.buildVirusSUMMARIZE_GroupClientTop10Report()
	if err != nil {
		return nil, err
	}
	exec.SubReport = append(exec.SubReport, clientTop10Report...)

	// 汇总统计--感染病毒最多控制中心Top10
	ccIdTop10Report, err := q.buildVirusSUMMARIZE_GroupCCIDTop10Report()
	if err != nil {
		return nil, err
	}
	exec.SubReport = append(exec.SubReport, ccIdTop10Report...)

	// 汇总统计--感染病毒Top10
	vNameTop10Report, err := q.buildVirusSUMMARIZE_GroupVNameTop10Report()
	if err != nil {
		return nil, err
	}
	exec.SubReport = append(exec.SubReport, vNameTop10Report...)

	return exec, nil
}

// 汇总统计--趋势图--病毒名
func (q *QueryCondition) buildVirusSUMMARIZE_TrendNameReport() ([]*Reporter, error) {

	repos, err := q.summarizeReportBuildHelper(def.VIRUS_SUMMARIZE_TREND_NAME, JSON,
		virusSumResultTableName, virusSumDataInputArgs)
	if err != nil {
		return nil, err
	}

	return repos, nil
}

// 汇总统计--趋势图--查杀次数
func (q *QueryCondition) buildVirusSUMMARIZE_TrendKillCountReport() ([]*Reporter, error) {

	repos, err := q.summarizeReportBuildHelper(def.VIRUS_SUMMARIZE_TREND_KILLCOUNT, JSON,
		virusSumResultTableName, virusSumDataInputArgs)
	if err != nil {
		return nil, err
	}

	return repos, nil
}

// 汇总统计--趋势图--查杀终端数
func (q *QueryCondition) buildVirusSUMMARIZE_TrendClientCountReport() ([]*Reporter, error) {

	repos, err := q.summarizeReportBuildHelper(def.VIRUS_SUMMARIZE_TREND_ClientCOUNT, JSON,
		virusSumResultTableName, virusSumDataInputArgs)
	if err != nil {
		return nil, err
	}
	return repos, nil
}

// 汇总统计--病毒种类占比 CatPer
func (q *QueryCondition) buildVirusSUMMARIZE_CatPerReport() ([]*Reporter, error) {

	repos, err := q.summarizeReportBuildHelper(def.VIRUS_SUMMARIZE_CAT_PER, JSON,
		virusSumResultTableName, virusSumDataInputArgs)
	if err != nil {
		return nil, err
	}

	return repos, nil
}

// 汇总统计--病毒处理占比 OptionPer
func (q *QueryCondition) buildVirusSUMMARIZE_OptionPerReport() ([]*Reporter, error) {

	repos, err := q.summarizeReportBuildHelper(def.VIRUS_SUMMARIZE_OPTION_PER, JSON,
		virusSumResultTableName, virusSumDataInputArgs)
	if err != nil {
		return nil, err
	}

	return repos, nil
}

// 汇总统计--触发方式占比 TaskPer
func (q *QueryCondition) buildVirusSUMMARIZE_TaskPerReport() ([]*Reporter, error) {

	repos, err := q.summarizeReportBuildHelper(def.VIRUS_SUMMARIZE_TASK_PER, JSON,
		virusSumResultTableName, virusSumDataInputArgs)
	if err != nil {
		return nil, err
	}

	return repos, nil
}

// 汇总统计--感染病毒最多终端Top10
func (q *QueryCondition) buildVirusSUMMARIZE_GroupClientTop10Report() ([]*Reporter, error) {

	repos, err := q.summarizeReportBuildHelper(def.VIRUS_SUMMARIZE_CLIENT_TOP10, JSON,
		virusSumResultTableName, virusSumDataInputArgs)
	if err != nil {
		return nil, err
	}

	return repos, nil
}

// 汇总统计--感染病毒最多控制中心Top10
func (q *QueryCondition) buildVirusSUMMARIZE_GroupCCIDTop10Report() ([]*Reporter, error) {

	repos, err := q.summarizeReportBuildHelper(def.VIRUS_SUMMARIZE_CCID_TOP10, JSON,
		virusSumResultTableName, virusSumDataInputArgs)
	if err != nil {
		return nil, err
	}

	return repos, nil
}

// 汇总统计--感染病毒Top10
func (q *QueryCondition) buildVirusSUMMARIZE_GroupVNameTop10Report() ([]*Reporter, error) {

	repos, err := q.summarizeReportBuildHelper(def.VIRUS_SUMMARIZE_VNAME_TOP10, JSON,
		virusSumResultTableName, virusSumDataInputArgs)
	if err != nil {
		return nil, err
	}

	return repos, nil
}

// 按控制中心统计
func (q *QueryCondition) NewVirusCCIDReport() (*ReportExec, error) {

	exec := &ReportExec{}

	repo, err := q.reportBuildHelper(def.VIRUS_CCID, RAW,
		virusCCIDResultTableName,
		[]string{
			"result_id",
			"data_type",
			"ccid",
			"ccid_name",
			"cli_count",
			"all_kills",
			"monitor_kills",
			"user_kills",
			"admin_kills",
		})
	if err != nil {
		return nil, err
	}

	exec.SubReport = append(exec.SubReport, repo)

	return exec, nil
}

// 按终端统计
func (q *QueryCondition) NewVirusClientReport() (*ReportExec, error) {

	exec := &ReportExec{}

	repo, err := q.reportBuildHelper(def.VIRUS_CLIENT, RAW,
		virusClientResultTableName,
		[]string{
			"result_id",
			"data_type",
			"client_mid",
			"client_name",
			"client_third_login_user",
			"client_ip",
			"client_mac",
			"ccid",
			"ccid_name",
			"all_kills",
			"monitor_kills",
			"user_kills",
			"admin_kills",
		})
	if err != nil {
		return nil, err
	}

	exec.SubReport = append(exec.SubReport, repo)

	return exec, nil
}

// 按病毒统计
func (q *QueryCondition) NewVirusNameReport() (*ReportExec, error) {

	exec := &ReportExec{}

	repo, err := q.reportBuildHelper(def.VIRUS_NAME, RAW,
		virusNameResultTableName,
		[]string{
			"result_id",
			"data_type",
			"vname",
			"virus_cat",
			"virus_cat_desc",
			"cli_count",
			"all_kills",
			"monitor_kills",
			"user_kills",
			"admin_kills",
			"ccid",
		})
	if err != nil {
		return nil, err
	}

	exec.SubReport = append(exec.SubReport, repo)

	return exec, nil
}

// 汇总统计--趋势图--病毒名个数
func trendCondition_VirusName(scale string) (*TrendTlpCondition, error) {
	var condition TrendTlpCondition
	switch scale {
	case def.DayScale:
		condition = TrendTlpCondition{
			S: "toDate(event_time) as etime, COUNT(vname) as vname_count",
			T: virusSumSourceTableName,
		}
	case def.WeekScale:
		condition = TrendTlpCondition{
			S: "toWeek(event_time) as etime, COUNT(vname) as vname_count",
			T: virusSumSourceTableName,
		}
	case def.MonthScale:
		condition = TrendTlpCondition{
			S: "toMonth(event_time) as etime, COUNT(vname) as vname_count",
			T: virusSumSourceTableName,
		}
	default:
		return nil, fmt.Errorf("scale[%s] 无效.", scale)
	}

	return &condition, nil
}

// 汇总统计--趋势图--查杀数
func trendCondition_VirusKillCount(scale string) (*TrendTlpCondition, error) {
	var condition TrendTlpCondition
	switch scale {
	case def.DayScale:
		condition = TrendTlpCondition{
			S: "toDate(event_time) as etime, COUNT(*) as kill_count",
			T: virusSumSourceTableName,
		}
	case def.WeekScale:
		condition = TrendTlpCondition{
			S: "toWeek(event_time) as etime, COUNT(*) as kill_count",
			T: virusSumSourceTableName,
		}
	case def.MonthScale:
		condition = TrendTlpCondition{
			S: "toMonth(event_time) as etime, COUNT(*) as kill_count",
			T: virusSumSourceTableName,
		}
	default:
		return nil, fmt.Errorf("scale[%s] 无效.", scale)
	}

	return &condition, nil
}

// 汇总统计--趋势图--查杀终端数
func trendCondition_VirusClientCount(scale string) (*TrendTlpCondition, error) {
	var condition TrendTlpCondition
	switch scale {
	case def.DayScale:
		condition = TrendTlpCondition{
			S: "toDate(event_time) as etime, COUNT(DISTINCT client_mid) as cli_count",
			T: virusSumSourceTableName,
		}
	case def.WeekScale:
		condition = TrendTlpCondition{
			S: "toWeek(event_time) as etime, COUNT(DISTINCT client_mid) as cli_count",
			T: virusSumSourceTableName,
		}
	case def.MonthScale:
		condition = TrendTlpCondition{
			S: "toMonth(event_time) as etime, COUNT(DISTINCT client_mid) as cli_count",
			T: virusSumSourceTableName,
		}
	default:
		return nil, fmt.Errorf("scale[%s] 无效.", scale)
	}

	return &condition, nil
}
