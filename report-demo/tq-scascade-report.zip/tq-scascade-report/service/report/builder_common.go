package report

import (
	"fmt"
	"strings"
	"text/template"
	"tq-scascade-report/pkg/def"
	"tq-scascade-report/service/report/sqltlp"
)

// 除趋势图之外的查询Sql映射
var reportCodeQuerySqlMap = map[string]string{
	// 扫描分数
	def.SCORE_CCID:                   sqltlp.ScoreGroupCCID,
	def.SCORE_SUMMARIZE_CLIENT_TOP10: sqltlp.ScoreGroupClientTop10,
	def.SCORE_SUMMARIZE_CCID_TOP10:   sqltlp.ScoreGroupCCIDTop10,

	// 病毒分析
	def.VIRUS_CCID:                   sqltlp.VirusGroupCCID,
	def.VIRUS_CLIENT:                 sqltlp.VirusGroupClient,
	def.VIRUS_NAME:                   sqltlp.VirusGroupName,
	def.VIRUS_SUMMARIZE_CAT_PER:      sqltlp.VirusSummarizeCatPer,
	def.VIRUS_SUMMARIZE_OPTION_PER:   sqltlp.VirusSummarizeOptionPer,
	def.VIRUS_SUMMARIZE_TASK_PER:     sqltlp.VirusSummarizeTaskPer,
	def.VIRUS_SUMMARIZE_CLIENT_TOP10: sqltlp.VirusSummarizeGroupClientTop10,
	def.VIRUS_SUMMARIZE_CCID_TOP10:   sqltlp.VirusSummarizeGroupCCIDTop10,
	def.VIRUS_SUMMARIZE_VNAME_TOP10:  sqltlp.VirusSummarizeGroupNameTop10,

	// 漏洞分析
	def.LEAK_CCID:                   sqltlp.LeakGroupCCID,
	def.LEAK_CLIENT:                 sqltlp.LeakGroupClient,
	def.LEAK_PATCH:                  sqltlp.LeakGroupPatch,
	def.LEAK_SUMMARIZE_FAILURE_PER:  sqltlp.LeakSummarizeRepairFailurePer,
	def.LEAK_SUMMARIZE_LEVEL_PER:    sqltlp.LeakSummarizeRepairLevelPer,
	def.LEAK_SUMMARIZE_CCID_TOP10:   sqltlp.LeakSummarizeGroupCCIDTop10,
	def.LEAK_SUMMARIZE_CLIENT_TOP10: sqltlp.LeakSummarizeGroupClientTop10,
	def.LEAK_SUMMARIZE_PATCH_TOP10:  sqltlp.LeakSummarizeGroupPatchTop10,

	// 告警事件
	def.ALERT_SUMMARIZE_Type_PER:   sqltlp.AlertSummarizeTypePer,
	def.ALERT_SUMMARIZE_COUNTS_PER: sqltlp.AlertSummarizeCountsPer,
}

type TrendTlpCondition struct {
	S string
	W []string
	T string
	G string
	//O string
}

func (q *QueryCondition) reportBuildHelper(
	reportCde string,
	dConvertType int,
	saveTableName string, saveInputArgs []string) (*Reporter, error) {

	sql, err := q.getQuerySqlByReportCode(reportCde)
	if err != nil {
		return nil, err
	}

	repo := &Reporter{
		QuerySourceConfig: &QueryCHConfig{
			SQL: sql,
			Args: map[string]interface{}{
				"ccIds": q.CCIDs,
			},
		},
		DataConvertConfig: &Convert{
			DataConvertType: dConvertType,
			ResultType:      reportCde,
			QueryResult:     make([]map[string]interface{}, 0),
			SaveResult:      make([]map[string]interface{}, 0),
			TopCCId:         q.TopCCId,
		},
		SaveDataConfig: &SavePGConfig{
			TableName:  saveTableName,
			InsertArgs: saveInputArgs,
		},
	}

	return repo, nil
}

func (q *QueryCondition) summarizeReportBuildHelper(
	reportCde string,
	dConvertType int,
	saveTableName string, saveInputArgs []string) ([]*Reporter, error) {

	sql, err := q.getQuerySqlByReportCode(reportCde)
	if err != nil {
		return nil, err
	}

	sumReports := make([]*Reporter, 0)

	for top, CCIds := range q.TopCCIdMap {
		repo := &Reporter{
			QuerySourceConfig: &QueryCHConfig{
				SQL: sql,
				Args: map[string]interface{}{
					"ccIds": CCIds,
				},
			},
			DataConvertConfig: &Convert{
				DataConvertType: dConvertType,
				ResultType:      reportCde,
				QueryResult:     make([]map[string]interface{}, 0),
				SaveResult:      make([]map[string]interface{}, 0),
				TopCCId:         top,
			},
			SaveDataConfig: &SavePGConfig{
				TableName:  saveTableName,
				InsertArgs: saveInputArgs,
			},
		}

		sumReports = append(sumReports, repo)
	}

	return sumReports, nil
}

func (q *QueryCondition) getQuerySqlByReportCode(code string) (string, error) {

	var (
		sql string
		err error
	)

	if tlp, ok := reportCodeQuerySqlMap[code]; ok {
		sql, err = q.commonTempletBuilder(tlp)
		if err != nil {
			return "", err
		}
	} else { // 针对趋势图(趋势图独特之处在于有时间刻度区分)
		sql, err = q.summarizeTrendTempletBuilder(code, q.TimeScale)
		if err != nil {
			return "", err
		}
	}

	return sql, nil
}

func (q *QueryCondition) commonTempletBuilder(sqlTlp string) (string, error) {

	tlpCond := &TrendTlpCondition{
		W: q.CCIDs,
	}
	return buildSql(sqlTlp, tlpCond)
}

func (q *QueryCondition) summarizeTrendTempletBuilder(reportCode, scale string) (string, error) {

	// 获取字符串模板
	tlpStr, err := getSummarizeTlpStrByScale(scale)
	if err != nil {
		return "", nil
	}

	// 获取模板构建条件
	tlpCond, err := getTrendTlpCondition(reportCode, scale)
	if err != nil {
		return "", nil
	}

	tlpCond.W = q.CCIDs

	return buildSql(tlpStr, tlpCond)
}

func buildSql(tlpStr string, tlpCond *TrendTlpCondition) (string, error) {
	funcMap := template.FuncMap{
		"whereCCID": buildCCIDWhere,
	}

	tmpl, err := template.New("buildSqlTlp").Funcs(funcMap).Parse(tlpStr)
	if err != nil {
		return "", nil
	}
	strBuf := &strings.Builder{}
	err = tmpl.Execute(strBuf, tlpCond)
	if err != nil {
		return "", nil
	}

	return strBuf.String(), nil
}

func getSummarizeTlpStrByScale(scale string) (string, error) {
	switch scale {
	case def.DayScale:
		return sqltlp.SummarizeInDay, nil
	case def.WeekScale:
		return sqltlp.SummarizeInWeek, nil
	case def.MonthScale:
		return sqltlp.SummarizeInMonth, nil
	case def.QuarterScale:
		return sqltlp.SummarizeInQuarter, nil
	default:
		return "", fmt.Errorf("scale[%s] 无效.", scale)
	}
}

func buildCCIDWhere(ccIds []string) string {
	whereStr := ""
	if len(ccIds) > 0 {
		whereStr = " ccid IN (:ccIds)"
	} else {
		whereStr = " ccid <> '' "
	}

	return whereStr
}

// 获取趋势图模板
func getTrendTlpCondition(reportCode, scale string) (*TrendTlpCondition, error) {

	switch reportCode {

	// 扫描分数
	case def.SCORE_SUMMARIZE_TREND:
		return trendCondition_Score(scale)

	// 病毒分析
	case def.VIRUS_SUMMARIZE_TREND_NAME:
		return trendCondition_VirusName(scale)
	case def.VIRUS_SUMMARIZE_TREND_KILLCOUNT:
		return trendCondition_VirusKillCount(scale)
	case def.VIRUS_SUMMARIZE_TREND_ClientCOUNT:
		return trendCondition_VirusClientCount(scale)

	// 漏洞分析
	case def.LEAK_SUMMARIZE_TREND:
		return trendCondition_Leak(scale)

	// 告警事件
	case def.ALERT_SUMMARIZE_TREND:
		return trendCondition_Alert(scale)

	default:
		return nil, fmt.Errorf("scale[%s] 无效.", scale)
	}

}
