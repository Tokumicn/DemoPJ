// 漏洞分析报表

package report

import (
	"fmt"
	"tq-scascade-report/pkg/def"
)

// 结果存储表
const (
	leakSumResultTableName = "scascade_leak_summarize"

	leakCCIDResultTableName = "scascade_leak_ccid"

	leakClientResultTableName = "scascade_leak_client"

	leakPatchResultTableName = "scascade_leak_patch"
)

// 源数据表
const leakSumSourceTableName = def.LEAK_SCOURSE_DATA_TABLENAME

var leakSumDataInputArgs = []string{"result_id", "top_ccid", "data_type", "ext", "create_time"}

// 按汇总统计
func (q *QueryCondition) NewLeakSUMMARIZEReport() (*ReportExec, error) {

	exec := &ReportExec{}

	// 汇总统计--趋势图--发现漏洞、修复漏洞、忽略漏洞
	trendReport, err := q.buildLeakSUMMARIZE_TrendReport()
	if err != nil {
		return nil, err
	}
	exec.SubReport = append(exec.SubReport, trendReport...)

	// 汇总统计--漏洞修复失败占比 RepairFailure
	failurePerReport, err := q.buildLeakSUMMARIZE_FixFailurePerReport()
	if err != nil {
		return nil, err
	}
	exec.SubReport = append(exec.SubReport, failurePerReport...)

	// 汇总统计--已修复漏洞级别占比 Leak Level
	levelPerReport, err := q.buildLeakSUMMARIZE_LevelPerReport()
	if err != nil {
		return nil, err
	}
	exec.SubReport = append(exec.SubReport, levelPerReport...)

	// 汇总统计--漏洞修复次数最多终端Top10
	clientTop10Report, err := q.buildLeakSUMMARIZE_GroupClientTop10Report()
	if err != nil {
		return nil, err
	}
	exec.SubReport = append(exec.SubReport, clientTop10Report...)

	// 汇总统计--漏洞修复次数最多控制中心Top10
	ccIdTop10Report, err := q.buildLeakSUMMARIZE_GroupCCIDTop10Report()
	if err != nil {
		return nil, err
	}
	exec.SubReport = append(exec.SubReport, ccIdTop10Report...)

	// 汇总统计--漏洞修复次数最多补丁Top10
	patchTop10Report, err := q.buildLeakSUMMARIZE_GroupPatchTop10Report()
	if err != nil {
		return nil, err
	}
	exec.SubReport = append(exec.SubReport, patchTop10Report...)

	return exec, nil
}

// 汇总统计--趋势图--发现漏洞、修复漏洞、忽略漏洞
func (q *QueryCondition) buildLeakSUMMARIZE_TrendReport() ([]*Reporter, error) {

	repos, err := q.summarizeReportBuildHelper(def.LEAK_SUMMARIZE_TREND, JSON,
		leakSumResultTableName, leakSumDataInputArgs)
	if err != nil {
		return nil, err
	}

	return repos, nil
}

// 汇总统计--漏洞修复失败占比 RepairFailure
func (q *QueryCondition) buildLeakSUMMARIZE_FixFailurePerReport() ([]*Reporter, error) {

	repos, err := q.summarizeReportBuildHelper(def.LEAK_SUMMARIZE_FAILURE_PER, JSON,
		leakSumResultTableName, leakSumDataInputArgs)
	if err != nil {
		return nil, err
	}

	return repos, nil
}

// 汇总统计--已修复漏洞级别占比 Leak Level
func (q *QueryCondition) buildLeakSUMMARIZE_LevelPerReport() ([]*Reporter, error) {

	repos, err := q.summarizeReportBuildHelper(def.LEAK_SUMMARIZE_LEVEL_PER, JSON,
		leakSumResultTableName, leakSumDataInputArgs)
	if err != nil {
		return nil, err
	}

	return repos, nil
}

// 汇总统计--漏洞修复次数最多终端Top10
func (q *QueryCondition) buildLeakSUMMARIZE_GroupClientTop10Report() ([]*Reporter, error) {

	repos, err := q.summarizeReportBuildHelper(def.LEAK_SUMMARIZE_CLIENT_TOP10, JSON,
		leakSumResultTableName, leakSumDataInputArgs)
	if err != nil {
		return nil, err
	}

	return repos, nil
}

// 汇总统计--漏洞修复次数最多控制中心Top10
func (q *QueryCondition) buildLeakSUMMARIZE_GroupCCIDTop10Report() ([]*Reporter, error) {

	repos, err := q.summarizeReportBuildHelper(def.LEAK_SUMMARIZE_CCID_TOP10, JSON,
		leakSumResultTableName, leakSumDataInputArgs)
	if err != nil {
		return nil, err
	}

	return repos, nil
}

// 汇总统计--漏洞修复次数最多补丁Top10
func (q *QueryCondition) buildLeakSUMMARIZE_GroupPatchTop10Report() ([]*Reporter, error) {

	repos, err := q.summarizeReportBuildHelper(def.LEAK_SUMMARIZE_PATCH_TOP10, JSON,
		leakSumResultTableName, leakSumDataInputArgs)
	if err != nil {
		return nil, err
	}

	return repos, nil
}

// 汇总统计--趋势图--发现漏洞补丁
// 汇总统计--趋势图--修复漏洞补丁
// 汇总统计--趋势图--忽略漏洞补丁
func trendCondition_Leak(scale string) (*TrendTlpCondition, error) {
	var condition TrendTlpCondition
	switch scale {
	case def.DayScale:
		condition = TrendTlpCondition{
			S: "toDate(event_time) as etime, event_action, COUNT(*) as total",
			T: leakSumSourceTableName,
			G: ", event_action",
		}
	case def.WeekScale:
		condition = TrendTlpCondition{
			S: "toWeek(event_time) as etime, event_action, COUNT(*) as total",
			T: leakSumSourceTableName,
			G: ", event_action",
		}
	case def.MonthScale:
		condition = TrendTlpCondition{
			S: "toMonth(event_time) as etime, event_action, COUNT(*) as total",
			T: leakSumSourceTableName,
			G: ", event_action",
		}
	default:
		return nil, fmt.Errorf("scale[%s] 无效.", scale)
	}

	return &condition, nil
}

// 按终端统计
func (q *QueryCondition) NewLeakClientReport() (*ReportExec, error) {
	exec := &ReportExec{}

	repo, err := q.reportBuildHelper(def.LEAK_CLIENT, RAW,
		leakClientResultTableName,
		[]string{
			"result_id",
			"data_type",
			"client_mid",
			"client_name",
			"client_third_login_user",
			"client_ip",
			"client_mac",
			"ccid",
			"ccid_name",
			"founds",
			"fixs",
			"ignores",
		})
	if err != nil {
		return nil, err
	}

	exec.SubReport = append(exec.SubReport, repo)

	return exec, nil
}

// 按控制中心统计
func (q *QueryCondition) NewLeakCCIDReport() (*ReportExec, error) {
	exec := &ReportExec{}

	repo, err := q.reportBuildHelper(def.LEAK_CCID, RAW,
		leakCCIDResultTableName,
		[]string{
			"result_id",
			"data_type",
			"ccid",
			"ccid_name",
			"cli_count",
			"founds",
			"fixs",
			"ignores",
		})
	if err != nil {
		return nil, err
	}

	exec.SubReport = append(exec.SubReport, repo)

	return exec, nil
}

// 按漏洞补丁统计
func (q *QueryCondition) NewLeakPatchReport() (*ReportExec, error) {
	exec := &ReportExec{}

	repo, err := q.reportBuildHelper(def.LEAK_PATCH, RAW,
		leakPatchResultTableName,
		[]string{
			"result_id",
			"data_type",
			"kbid",
			"leak_type",
			"leak_type_desc",
			"leak_name",
			"founds",
			"fixs",
			"ignores",
			"ccid",
			"ccid_name",
		})
	if err != nil {
		return nil, err
	}

	exec.SubReport = append(exec.SubReport, repo)

	return exec, nil
}
