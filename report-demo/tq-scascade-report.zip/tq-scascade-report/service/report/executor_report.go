package report

type ReportExecutor interface {
	Query() error
	Convert() error
	Save() error
}

type Reporter struct {
	TaskResultId int64
	// 查询配置
	QuerySourceConfig *QueryCHConfig
	// 存储结果
	SaveExecResultConfig *SavePGConfig
	// 存储配置
	SaveDataConfig *SavePGConfig
	// 数据结构转换
	DataConvertConfig *Convert
}

type ReportExec struct {
	// 传入通用条件，方便记录日志
	Condition *QueryCondition
	SubReport []*Reporter
}

func (rep *Reporter) Query() error {

	res, err := rep.QuerySourceConfig.Query()
	if err != nil {
		return err
	}

	rep.DataConvertConfig.QueryResult = res
	return nil
}

func (rep *Reporter) Convert() error {

	return rep.DataConvertConfig.DataConvert()
}

func (rep *Reporter) Save() error {

	//return rep.SaveDataConfig.Save(rep.DataConvertConfig.SaveResult) // 单挑插入 sqlx个版本都支持
	return rep.SaveDataConfig.BatchInsert(rep.DataConvertConfig.SaveResult) // 批量插入 仅sqlx @master支持
}
