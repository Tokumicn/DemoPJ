package security

// 报表业务
// 允许的Order 配置
var ReportDetailTableAllowOrderMap = map[string]map[string]int{
	// 扫描分数
	// 按CCID统计
	"scascade_score_ccid": {
		"cli_count": 1, // 终端数量
		"avg_score": 1, // 平均分
	},

	// 病毒分析
	// 按CCID统计
	"scascade_virus_ccid": {
		"cli_count":     1, // 终端数量
		"all_kills":     1, // 总查杀数
		"monitor_kills": 1, // 监控查杀数
		"user_kills":    1, // 用户查杀数
		"admin_kills":   1, // 管理员查杀数
	},
	// 按Client统计
	"scascade_virus_client": {
		"all_kills":     1, // 总查杀数
		"monitor_kills": 1, // 监控查杀数
		"user_kills":    1, // 用户查杀数
		"admin_kills":   1, // 管理员查杀数
	},
	// 按病毒统计
	"scascade_virus_name": {
		"cli_count":     1, // 感染终端数
		"all_kills":     1, // 总查杀数
		"monitor_kills": 1, // 监控查杀数
		"user_kills":    1, // 用户查杀数
		"admin_kills":   1, // 管理员查杀数
	},

	// 漏洞分析
	// 按CCID统计
	"scascade_leak_ccid": {
		"cli_count": 1, // 终端数
		"founds":    1, // 已发现漏洞补丁数
		"fixs":      1, // 已安装漏洞补丁数
		"ignores":   1, // 已忽略漏洞补丁数
	},
	// 按Client统计
	"scascade_leak_client": {
		"founds":  1, // 已发现漏洞补丁数
		"fixs":    1, // 已安装漏洞补丁数
		"ignores": 1, // 已忽略漏洞补丁数
	},
	// 按漏洞补丁统计
	"scascade_leak_patch": {
		"leak_type": 1, // 漏洞补丁级别
		"founds":    1, // 已发现漏洞补丁数
		"fixs":      1, // 已安装漏洞补丁数
		//"ignores":   1, // 已忽略漏洞补丁数
	},
}

// 允许的查询字段配置
var ReportDetailTableQueryMap = map[string]map[string]int{
	// 扫描分数
	// 按CCID统计
	"scascade_score_ccid": {
		"ccid_name": 1,
	},

	// 病毒分析
	// 按CCID统计
	"scascade_virus_ccid": {
		"ccid_name": 1,
	},
	// 按Client统计
	"scascade_virus_client": {
		"client_name":             1, // 计算机名
		"client_third_login_user": 1, // 实名账号
	},
	// 按病毒统计
	"scascade_virus_name": {
		"vname": 1, // 病毒名
	},

	// 漏洞分析
	// 按CCID统计
	"scascade_leak_ccid": {
		"ccid_name": 1,
	},
	// 按Client统计
	"scascade_leak_client": {
		"client_name":             1, // 计算机名
		"client_third_login_user": 1, // 实名账号
	},
	// 按漏洞补丁统计
	"scascade_leak_patch": {
		"leak_name": 1, // 补丁名
		"kbid":      1, // 补丁号
	},
}

// 每种业务允许的报表类型  暂不使用
//var ReportTypeAllowMap = map[string]map[string]int{
//	// 扫描分数
//	def.SCORE: {
//		def.SUMMARIZE: 1,
//		def.CCID:      1,
//	},
//
//	// 病毒分析
//	def.VIRUS: {
//		def.SUMMARIZE: 1,
//		def.CCID:      1,
//		def.CLIENT:    1,
//		def.VIRUS:     1,
//	},
//
//	// 漏洞分析
//	def.LEAK: {
//		def.SUMMARIZE: 1,
//		def.CCID:      1,
//		def.CLIENT:    1,
//		def.PATCHES:   1,
//	},
//
//	// 告警事件
//	def.ALERT: {
//		def.SUMMARIZE: 1,
//	},
//}
