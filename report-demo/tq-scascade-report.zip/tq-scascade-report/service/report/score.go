// 扫描分数报表

package report

import (
	"fmt"
	"tq-scascade-report/pkg/def"
)

const scoreSumDataTableName = "scascade_score_summarize"

var scoreSumDataInputArgs = []string{"result_id", "top_ccid", "data_type", "ext", "create_time"}

func (q *QueryCondition) NewScoreCCIDReport() (*ReportExec, error) {

	exec := &ReportExec{}

	repo, err := q.reportBuildHelper(def.SCORE_CCID, RAW,
		"scascade_score_ccid",
		[]string{"result_id", "data_type", "ccid", "ccid_name", "cli_count", "avg_score"})
	if err != nil {
		return nil, err
	}

	exec.SubReport = append(exec.SubReport, repo)

	return exec, nil
}

func trendCondition_Score(scale string) (*TrendTlpCondition, error) {

	var condition TrendTlpCondition
	switch scale {
	case def.DayScale:
		condition = TrendTlpCondition{
			S: "toDate(event_time) as etime, AVG(exam_score) as avg_score",
			T: def.SCORE_SCOURSE_DATA_TABLENAME,
		}
	case def.WeekScale:
		condition = TrendTlpCondition{
			S: "toWeek(event_time) as etime, AVG(exam_score) as avg_score",
			T: def.SCORE_SCOURSE_DATA_TABLENAME,
		}
	case def.MonthScale:
		condition = TrendTlpCondition{
			S: "toMonth(event_time) as etime, AVG(exam_score) as avg_score",
			T: def.SCORE_SCOURSE_DATA_TABLENAME,
		}
	case def.QuarterScale:
		condition = TrendTlpCondition{
			S: "toQuarter(event_time) as etime, AVG(exam_score) as avg_score",
			T: def.SCORE_SCOURSE_DATA_TABLENAME,
		}
	default:
		return nil, fmt.Errorf("scale[%s] 无效.", scale)
	}

	return &condition, nil
}

func (q *QueryCondition) NewScoreSUMMARIZEReport() (*ReportExec, error) {

	exec := &ReportExec{}
	repoTrend, err := q.buildScoreSUMMARIZE_TrendReport()
	if err != nil {
		return nil, err
	}
	exec.SubReport = append(exec.SubReport, repoTrend...)

	clientTop10Report, err := q.buildScoreSUMMARIZE_GroupClientTop10Report()
	if err != nil {
		return nil, err
	}
	exec.SubReport = append(exec.SubReport, clientTop10Report...)

	ccIdTop10Report, err := q.buildScoreSUMMARIZE_GroupCCIDTop10Report()
	if err != nil {
		return nil, err
	}
	exec.SubReport = append(exec.SubReport, ccIdTop10Report...)

	return exec, nil
}

// 趋势图报表
func (q *QueryCondition) buildScoreSUMMARIZE_TrendReport() ([]*Reporter, error) {

	repos, err := q.summarizeReportBuildHelper(def.SCORE_SUMMARIZE_TREND, JSON, scoreSumDataTableName, scoreSumDataInputArgs)
	if err != nil {
		return nil, err
	}
	return repos, nil
}

// 最低分TOP10终端
func (q *QueryCondition) buildScoreSUMMARIZE_GroupClientTop10Report() ([]*Reporter, error) {

	repos, err := q.summarizeReportBuildHelper(def.SCORE_SUMMARIZE_CLIENT_TOP10, JSON, scoreSumDataTableName, scoreSumDataInputArgs)
	if err != nil {
		return nil, err
	}
	return repos, nil
}

// 最低分TOP10控制中心
func (q *QueryCondition) buildScoreSUMMARIZE_GroupCCIDTop10Report() ([]*Reporter, error) {

	repos, err := q.summarizeReportBuildHelper(def.SCORE_SUMMARIZE_CCID_TOP10, JSON, scoreSumDataTableName, scoreSumDataInputArgs)
	if err != nil {
		return nil, err
	}
	return repos, nil
}
