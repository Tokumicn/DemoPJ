package sqltlp

const (
	// 汇总统计--病毒种类占比
	VirusSummarizeCatPer = `SELECT virus_cat, COUNT(*) AS total FROM skylar_scascade.sd
									WHERE {{whereCCID .W}} AND event_time >= :startTime AND event_time <= :endTime
									GROUP BY virus_cat
									ORDER BY total DESC`

	// 汇总统计--病毒处理占比
	/*
		op 1,256,512=》未处理
		   2,64,128=》修复成功
		   4=》修复失败
		   8=》系统文件不做删除处理
	*/
	// 查询结果: 1:未处理  2:修复成功 3:修复失败 4:系统文件不做删除处理 5:无效处理类型
	VirusSummarizeOptionPer = `SELECT 
								(CASE WHEN op in (1,256,512) THEN 1
								 	  WHEN op in (2,64,128) THEN 2
									  WHEN op in (4) THEN 3
									  WHEN op in (8) THEN 4 
                                      WHEN op >=0 THEN 5 end) AS virus_option,
								count(*) AS total
							FROM skylar_scascade.sd 
							WHERE {{whereCCID .W}} AND event_time >= :startTime AND event_time <= :endTime
                            GROUP BY virus_option;`

	// 汇总统计--触发方式占比
	// -1:用户查杀   0:实时监控查杀   1:管理员查杀
	VirusSummarizeTaskPer = `SELECT 
								(CASE WHEN task_id > 1   THEN 1
									  WHEN task_id = 0   THEN 0
									  WHEN task_id = -1  THEN -1 END) AS virus_task,
								count(*) AS total
							FROM skylar_scascade.sd 
							WHERE {{whereCCID .W}} AND event_time >= :startTime AND event_time <= :endTime
                            GROUP BY virus_task;`

	// 汇总统计--感染病毒最多[终端] TOP 10
	VirusSummarizeGroupClientTop10 = `SELECT client_mid, client_name, client_ip, client_mac, client_third_login_user, ccid, COUNT(*) as all_kills
        FROM skylar_scascade.sd 
		WHERE {{whereCCID .W}} AND event_time >= :startTime AND event_time <= :endTime
		GROUP BY client_mid, client_name, client_ip, ccid, client_mac, client_third_login_user
		ORDER BY all_kills DESC 
		LIMIT 10;`

	// 汇总统计--感染最多[控制中心] TOP 10
	VirusSummarizeGroupCCIDTop10 = `SELECT ccid, COUNT(client_mid) as cli_count, COUNT(*) as all_kills
        FROM skylar_scascade.sd 
		WHERE {{whereCCID .W}} AND event_time >= :startTime AND event_time <= :endTime
		GROUP BY ccid, client_mid
		ORDER BY all_kills DESC 
        LIMIT 10;`

	// 汇总统计--感染[病毒] TOP 10
	VirusSummarizeGroupNameTop10 = `SELECT vname, virus_cat, COUNT(client_mid) as cli_count, COUNT(*) as all_kills
        FROM skylar_scascade.sd 
		WHERE {{whereCCID .W}} AND event_time >= :startTime AND event_time <= :endTime
		GROUP BY vname, virus_cat, client_mid
		ORDER BY cli_count DESC 
		LIMIT 10;`

	// 按控制中心统计(控制中心、终端数量、查杀总次数、实时监控查杀次数、用户查杀次数、管理员查杀次数)
	VirusGroupCCID = `SELECT ccid,
							 COUNT(client_mid) as cli_count, 
							 COUNT(*) as all_kills,
							 SUM(CASE WHEN task_id =0 THEN 1 ELSE 0 END) AS monitor_kills,
							 SUM(CASE WHEN task_id =-1 THEN 1 ELSE 0 END) AS user_kills,
							 SUM(CASE WHEN task_id >0 THEN 1 ELSE 0 END) AS admin_kills
        FROM skylar_scascade.sd
		WHERE {{whereCCID .W}} AND event_time >= :startTime AND event_time <= :endTime
		GROUP BY ccid, client_mid
		ORDER BY all_kills DESC;`

	// 按终端统计(计算机名、实名账户、IP地址、MAC、所属控制中心、总查杀次数、实时监控查杀次数、用户查杀次数、管理员查杀次数)
	VirusGroupClient = `SELECT  client_mid, 
                                client_name, 
                                client_third_login_user, 
                                client_ip, 
                                client_mac, 
                                ccid,
								COUNT(*) as all_kills,
								SUM(CASE WHEN task_id =0 THEN 1 ELSE 0 END) AS monitor_kills,
								SUM(CASE WHEN task_id =-1 THEN 1 ELSE 0 END) AS user_kills,
								SUM(CASE WHEN task_id >0 THEN 1 ELSE 0 END) AS admin_kills
        FROM skylar_scascade.sd 
		WHERE {{whereCCID .W}} AND event_time >= :startTime AND event_time <= :endTime
		GROUP BY client_mid, client_name, client_third_login_user, client_ip, client_mac, ccid
		ORDER BY all_kills DESC;`

	// 按病毒统计(病毒名、病毒类型、感染终端数、总查杀次数、实时监控查杀次数、用户查杀次数、管理员查杀次数)
	VirusGroupName = `SELECT  vname, 
                              virus_cat,
                              COUNT(client_mid) as cli_count ,
							  COUNT(*) as all_kills,
							  SUM(CASE WHEN task_id =0 THEN 1 ELSE 0 END) AS monitor_kills,
							  SUM(CASE WHEN task_id =-1 THEN 1 ELSE 0 END) AS user_kills,
							  SUM(CASE WHEN task_id >0 THEN 1 ELSE 0 END) AS admin_kills,
							  ccid
        FROM skylar_scascade.sd 
		WHERE {{whereCCID .W}} AND event_time >= :startTime AND event_time <= :endTime
		GROUP BY vname, virus_cat, client_mid,ccid
		ORDER BY cli_count DESC;`
)
