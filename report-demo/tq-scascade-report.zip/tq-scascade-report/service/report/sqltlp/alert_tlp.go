package sqltlp

const (

	// 汇总统计--[告警类型]占比
	AlertSummarizeTypePer = `SELECT type, COUNT(*) AS total FROM skylar_scascade.secevent
									WHERE {{whereCCID .W}} AND event_time >= :startTime 
                                                           AND event_time <= :endTime
									GROUP BY type
									ORDER BY total DESC`

	// 汇总统计--[告警次数]占比
	AlertSummarizeCountsPer = `SELECT ccid, COUNT(*) AS total FROM skylar_scascade.secevent
									WHERE {{whereCCID .W}} AND event_time >= :startTime 
                                                           AND event_time <= :endTime
									GROUP BY ccid
									ORDER BY total DESC`
)
