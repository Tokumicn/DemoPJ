// 汇总统计--趋势图SQL构建器
package sqltlp

// 趋势图
const (
	// 按天统计
	SummarizeInDay = `SELECT toYear(event_time) as eyear, {{.S}} FROM {{.T}}
		WHERE {{whereCCID .W}} AND event_time >= :startTime AND event_time <= :endTime
		GROUP BY eyear, etime {{.G}}
		ORDER BY eyear, etime ASC;`

	// 按周统计
	SummarizeInWeek = `SELECT toYear(event_time) as eyear, {{.S}} FROM {{.T}}
		WHERE {{whereCCID .W}} AND event_time >= :startTime AND event_time <= :endTime
		GROUP BY eyear, etime {{.G}}
		ORDER BY eyear, etime ASC;`

	// 按月统计
	SummarizeInMonth = `SELECT toYear(event_time) as eyear, {{.S}} FROM {{.T}}
		WHERE {{whereCCID .W}} AND event_time >= :startTime AND event_time <= :endTime
		GROUP BY eyear, etime {{.G}}
		ORDER BY eyear, etime ASC;`

	// 按季统计
	SummarizeInQuarter = `SELECT toYear(event_time) as eyear, {{.S}} FROM {{.T}}
		WHERE {{whereCCID .W}} AND event_time >= :startTime AND event_time <= :endTime
		GROUP BY eyear, etime {{.G}}
		ORDER BY eyear, etime ASC;`
)
