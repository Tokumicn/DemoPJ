package sqltlp

const (
	// 汇总统计--平均扫描分数最低[终端]TOP N
	ScoreGroupClientTop10 = `SELECT client_name, client_ip, client_mac, client_third_login_user, ccid, client_mid, AVG(exam_score) as avg_score 
        FROM skylar_scascade.exam
		WHERE {{whereCCID .W}} AND event_time >= :startTime AND event_time <= :endTime
		GROUP BY client_name, client_ip, client_mac, client_third_login_user, ccid,client_mid
		ORDER BY avg_score ASC
		LIMIT 10;`

	// 按控制中心统计（所属控制中心、终端数量、平均分）Top10
	ScoreGroupCCIDTop10 = `SELECT ccid, COUNT(client_mid) as cli_count, AVG(exam_score) as avg_score 
        FROM skylar_scascade.exam
		WHERE {{whereCCID .W}} AND event_time >= :startTime AND event_time <= :endTime
		GROUP BY ccid
		ORDER BY avg_score ASC
		LIMIT 10;`

	//  汇总统计--平均扫描分数最低[分组]TOP N
	//ScoreGroupGidTopN = `SELECT e.client_gid as gid ,AVG(e.exam_score) as avgscore FROM skylar_scascade.exam e
	//	WHERE {WherePlace} AND e.event_time > ? AND e.event_time < ?
	//	GROUP BY e.client_gid
	//	ORDER BY avgscore ASC ;`

	// 按控制中心统计（所属控制中心、终端数量、平均分）
	ScoreGroupCCID = `SELECT ccid, COUNT(client_mid) as cli_count, AVG(exam_score) as avg_score 
        FROM skylar_scascade.exam
		WHERE {{whereCCID .W}} AND event_time >= :startTime AND event_time <= :endTime
		GROUP BY ccid
		ORDER BY avg_score ASC;`
)
