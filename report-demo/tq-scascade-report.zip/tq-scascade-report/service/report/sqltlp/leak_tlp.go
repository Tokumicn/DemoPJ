package sqltlp

const (
	/*
		  event_action
		    - 1: 发现
			- 2: 修复成功
		    - 3: 修复失败
			- 4: 忽略漏洞
		    - 5: 用户取消忽略
		    - 6: 用户卸载漏洞
	*/

	// 汇总统计--漏洞修复失败占比
	/*
	   reason 600     => '其他',
	          601     => '下载失败',
	          602     => '签名验证失败',
	          603     => '签名无效',
	          604     => '安装失败',
	          605     => '用户取消',
	          606     => '修复超时'
	*/
	LeakSummarizeRepairFailurePer = `SELECT reason, COUNT(*) AS total FROM skylar_scascade.leak_repair
									WHERE {{whereCCID .W}} AND event_time >= :startTime 
                                                           AND event_time <= :endTime
                                                           AND event_action = 3 
                                                           AND reason in (600,601,602,603,604,605,606)
									GROUP BY reason
									ORDER BY total DESC`

	// 汇总统计--已修复漏洞级别分布占比
	/*
		   leak_type:  1=> 高危
			           2=> 软件安全更新
		               3=> 高危可选
			           4=> 其他
	*/
	LeakSummarizeRepairLevelPer = `SELECT leak_type, COUNT(*) AS total FROM skylar_scascade.leak_repair
									WHERE {{whereCCID .W}} AND event_time >= :startTime 
                                                           AND event_time <= :endTime
                                                           AND event_action = 2 
                                                           AND leak_type in (1,2,3,4)
									GROUP BY leak_type
									ORDER BY total DESC`

	// 汇总统计--安装漏洞补丁最多[终端]TOP N
	// event_action = 2 修复成功
	LeakSummarizeGroupClientTop10 = `SELECT client_mid, client_name, client_ip, client_mac, client_third_login_user, ccid, COUNT(*) as install_count
        FROM skylar_scascade.leak_repair 
		WHERE {{whereCCID .W}} AND event_time >= :startTime 
                               AND event_time <= :endTime
                               AND event_action = 2
		GROUP BY client_mid, client_name, client_ip, ccid, client_mac, client_third_login_user
		ORDER BY install_count DESC 
		LIMIT 10;`

	// 汇总统计--安装补丁次数最多[控制中心] TOP N
	// event_action = 2 修复成功
	LeakSummarizeGroupCCIDTop10 = `SELECT ccid, COUNT(*) as install_count
        FROM skylar_scascade.leak_repair
		WHERE {{whereCCID .W}} AND event_time >= :startTime 
                               AND event_time <= :endTime
                               AND event_action = 2
		GROUP BY ccid
		ORDER BY install_count DESC 
        LIMIT 10;`

	// 汇总统计--安装次数最多[漏洞补丁] TOP N
	// event_action = 2 修复成功
	LeakSummarizeGroupPatchTop10 = `SELECT leak_name, kbid, COUNT(*) as install_count
        FROM skylar_scascade.leak_repair
		WHERE {{whereCCID .W}} AND event_time >= :startTime 
                               AND event_time <= :endTime
                               AND event_action = 2
		GROUP BY kbid, leak_name
		ORDER BY install_count DESC 
		LIMIT 10;`

	// 按控制中心统计(控制中心、终端数量、发现漏洞补丁数、已安装漏洞补丁数、忽略漏洞补丁数)
	LeakGroupCCID = `SELECT ccid,
							 COUNT(client_mid) as cli_count,
							 SUM(CASE WHEN event_action = 1 THEN 1 ELSE 0 END) AS founds,
							 SUM(CASE WHEN event_action = 2 THEN 1 ELSE 0 END) AS fixs,
							 SUM(CASE WHEN event_action = 4 THEN 1 ELSE 0 END) AS ignores
        FROM skylar_scascade.leak_repair
		WHERE {{whereCCID .W}} AND event_time >= :startTime AND event_time <= :endTime
		GROUP BY ccid, client_mid
		ORDER BY cli_count DESC;`

	// 按终端统计(计算机名、实名账户、IP地址、MAC、所属控制中心、发现漏洞补丁数、已安装漏洞补丁数、忽略漏洞补丁数)
	LeakGroupClient = `SELECT   client_mid, 
                                client_name, 
                                client_third_login_user, 
                                client_ip, 
                                client_mac, 
                                ccid,
								SUM(CASE WHEN event_action = 1 THEN 1 ELSE 0 END) AS founds,
                                SUM(CASE WHEN event_action = 2 THEN 1 ELSE 0 END) AS fixs,
							    SUM(CASE WHEN event_action = 4 THEN 1 ELSE 0 END) AS ignores
        FROM skylar_scascade.leak_repair 
		WHERE {{whereCCID .W}} AND event_time >= :startTime AND event_time <= :endTime
		GROUP BY client_mid, client_name, client_third_login_user, client_ip, client_mac, ccid
		ORDER BY founds DESC;`

	// 按病漏洞补丁统计(补丁名、补丁号、漏洞级别、已安装补丁数、发现漏洞补丁数)
	LeakGroupPatch = `SELECT  kbid, 
                              leak_name,
                              leak_type,
							  SUM(CASE WHEN event_action = 1 THEN 1 ELSE 0 END) AS founds,
                              SUM(CASE WHEN event_action = 2 THEN 1 ELSE 0 END) AS fixs,
							  SUM(CASE WHEN event_action = 4 THEN 1 ELSE 0 END) AS ignores,
							  ccid
        FROM skylar_scascade.leak_repair 
		WHERE {{whereCCID .W}} AND event_time >= :startTime AND event_time <= :endTime
		GROUP BY kbid, leak_type, leak_name, ccid
		ORDER BY founds DESC;`
)
