package report

import (
	"git-biz.qianxin-inc.cn/eps/skylar/apps/libs/tianqing.git/logs"
	"math/rand"
	"testing"
	"time"
	"tq-scascade-report/pkg/clickhouse"
	"tq-scascade-report/pkg/def"
	"tq-scascade-report/pkg/postgres"
)

func init() {
	logs.Init(logs.Config{
		Writer: "console",
		Level:  "debug",
	})

	config := &clickhouse.Config{
		Host:         "10.44.203.4:9997",
		Debug:        false,
		User:         "",
		Password:     "",
		DBName:       "skylar_scascade",
		MaxIdle:      1,
		MaxOpen:      2,
		MaxLife:      60,
		ReadTimeout:  120,
		WriteTimeout: 120,
		AltHosts:     "",
	}

	clickhouse.ClickHouseInit(config)

	postgres.InitPostgresDB(&postgres.Config{
		Host:            "10.44.202.12",
		Port:            "5432",
		User:            "postgres",
		Password:        "postgres",
		DBName:          "dataportal",
		ApplicationName: "tq-scascade-report",
		MaxIdle:         2,
		MaxOpen:         4,
		MaxLife:         600,
		Mock:            true,
	})
}

// Score
func TestScoreCCID(t *testing.T) {

	//sTime, _ := time.Parse("2006-01-02 ", "2020-07-15")
	//eTime, _ := time.Parse("2006-01-02", "2020-09-25")

	sTime := "2020-07-15"
	eTime := "2020-09-25"

	queryCond := QueryCondition{
		CCIDs:      []string{"4F9998B2-24FE-7E3D-55C2-02098BA9E74D", "4F9998B2-24FE-7E3D-55C2-02098BA9E74A"},
		Business:   def.SCORE,
		ReportType: def.CCID,
		StartTime:  sTime,
		EndTime:    eTime,
	}

	reports, err := queryCond.BuildReportExec()
	if err != nil {
		t.Fatal(err)
	}

	rand.Seed(time.Now().Unix())

	for _, exec := range reports.SubReport {
		t.Log(exec.QuerySourceConfig.SQL)

		err := exec.Query()
		if err != nil {
			t.Fatal(err)
		}

		exec.DataConvertConfig.ResultId = rand.Int63n(9999)

		// 整理数据
		err = exec.Convert()
		if err != nil {
			logs.Error(err)
			continue
		}

		// 存储查询结果
		err = exec.Save()
		if err != nil {
			logs.Error(err)
			continue
		}
	}
}

func TestReportBuildHelper(t *testing.T) {

	// 非趋势图
	//q := &QueryCondition{
	//	CCIDs:      []string{},
	//	Business:   def.SCORE,
	//	ReportType: def.CCID,
	//	StartTime:  &utils.JSONTime{T: time.Now()},
	//	EndTime:    &utils.JSONTime{T: time.Now()},
	//}
	//
	//sql, err := q.getQuerySqlByReportCode(def.SCORE_CCID)
	//if err != nil {
	//	t.Error(err)
	//}
	//
	//t.Log(sql)

	// 汇总趋势图
	q2 := &QueryCondition{
		CCIDs:      []string{"1111", "2222"},
		Business:   def.SCORE,
		ReportType: def.SUMMARIZE,
		TimeScale:  def.DayScale,
		StartTime:  "",
		EndTime:    "",
	}

	sql2, err := q2.getQuerySqlByReportCode(def.SCORE_SUMMARIZE_CCID_TOP10)
	if err != nil {
		t.Error(err)
	}

	t.Log(sql2)

	sql3, err := q2.getQuerySqlByReportCode(def.SCORE_SUMMARIZE_TREND)
	if err != nil {
		t.Error(err)
	}

	t.Log(sql3)

	// 病毒分析 -- 趋势图
	q3 := &QueryCondition{
		CCIDs:      []string{"AAA", "BBB"},
		Business:   def.VIRUS,
		ReportType: def.SUMMARIZE,
		TimeScale:  def.MonthScale,
		StartTime:  "",
		EndTime:    "",
	}

	sql4, err := q3.getQuerySqlByReportCode(def.VIRUS_SUMMARIZE_TREND_KILLCOUNT)
	if err != nil {
		t.Error(err)
	}

	t.Log(sql4)
}

func TestGORMSqlBuilder(t *testing.T) {

}
