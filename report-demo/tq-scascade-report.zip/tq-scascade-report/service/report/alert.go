package report

import (
	"fmt"
	"tq-scascade-report/pkg/def"
)

const alertSumResultTableName = "scascade_alert_summarize"

var alertSumDataInputArgs = []string{"result_id", "top_ccid", "data_type", "ext", "create_time"}

// 源数据表
const alertSumSourceTableName = def.ALERT_SCOURSE_DATA_TABLENAME

// 告警事件--按汇总统计
func (q *QueryCondition) NewAlertSUMMARIZEReport() (*ReportExec, error) {

	exec := &ReportExec{}

	// 汇总统计--趋势图--告警次数
	trendReport, err := q.buildAlertSUMMARIZE_TrendReport()
	if err != nil {
		return nil, err
	}
	exec.SubReport = append(exec.SubReport, trendReport...)

	// 汇总统计--告警类型占比
	levelPerReport, err := q.buildAlertSUMMARIZE_TypePerReport()
	if err != nil {
		return nil, err
	}
	exec.SubReport = append(exec.SubReport, levelPerReport...)

	// 汇总统计--告警次数占比
	alertCountPerReport, err := q.buildAlertSUMMARIZE_CountsPerReport()
	if err != nil {
		return nil, err
	}
	exec.SubReport = append(exec.SubReport, alertCountPerReport...)

	return exec, nil
}

// 汇总统计--趋势图--告警次数
func trendCondition_Alert(scale string) (*TrendTlpCondition, error) {
	var condition TrendTlpCondition
	switch scale {
	case def.DayScale:
		condition = TrendTlpCondition{
			S: "toDate(event_time) as etime, COUNT(*) as alert_count",
			T: alertSumSourceTableName,
		}
	case def.WeekScale:
		condition = TrendTlpCondition{
			S: "toWeek(event_time) as etime, COUNT(*) as alert_count",
			T: virusSumSourceTableName,
		}
	case def.MonthScale:
		condition = TrendTlpCondition{
			S: "toMonth(event_time) as etime, COUNT(*) as alert_count",
			T: virusSumSourceTableName,
		}
	default:
		return nil, fmt.Errorf("scale[%s] 无效.", scale)
	}

	return &condition, nil
}

// 汇总统计--趋势图--告警次数
func (q *QueryCondition) buildAlertSUMMARIZE_TrendReport() ([]*Reporter, error) {

	repos, err := q.summarizeReportBuildHelper(def.ALERT_SUMMARIZE_TREND, JSON,
		alertSumResultTableName, alertSumDataInputArgs)
	if err != nil {
		return nil, err
	}

	return repos, nil
}

// 汇总统计--告警类型占比
func (q *QueryCondition) buildAlertSUMMARIZE_TypePerReport() ([]*Reporter, error) {

	repos, err := q.summarizeReportBuildHelper(def.ALERT_SUMMARIZE_Type_PER, JSON,
		alertSumResultTableName, alertSumDataInputArgs)
	if err != nil {
		return nil, err
	}

	return repos, nil
}

// 汇总统计--告警次数占比
func (q *QueryCondition) buildAlertSUMMARIZE_CountsPerReport() ([]*Reporter, error) {

	repos, err := q.summarizeReportBuildHelper(def.ALERT_SUMMARIZE_COUNTS_PER, JSON,
		alertSumResultTableName, alertSumDataInputArgs)
	if err != nil {
		return nil, err
	}

	return repos, nil
}
