package report

import (
	"encoding/json"
	"git-biz.qianxin-inc.cn/eps/skylar/apps/libs/tianqing.git/logs"
	"time"
	"tq-scascade-report/pkg/def"
	"tq-scascade-report/service/value_convert"
)

const (
	JSON = iota + 1
	RAW
)

type Convert struct {
	// 结果Id
	ResultId        int64
	ResultType      string
	DataConvertType int
	QueryResult     []map[string]interface{} // 查询结果集
	SaveResult      []map[string]interface{}
	TopCCId         string // 结果需要记录查询时使用的TopCCId以满足汇总统计对控制中心筛选的查询
}

func (con *Convert) DataConvert() error {

	convData := make([]map[string]interface{}, 0)
	for _, row := range con.QueryResult {

		// 根据ResultType配置的待转换字段将数据转换完毕后再做存储
		completeRow, err := value_convert.RowValueConvert(row, con.ResultType, con.ResultId)
		if err != nil {
			logs.Errorf("RowValueConvert error: %s", err.Error())
		}

		if con.DataConvertType == JSON {
			valBytes, err := json.Marshal(completeRow)
			if err != nil {
				logs.Error(err)
				continue
			}

			tmp := map[string]interface{}{
				"result_id":   con.ResultId,
				"data_type":   def.ReportResultTypeDic[con.ResultType],
				"top_ccid":    con.TopCCId,
				"ext":         string(valBytes),
				"create_time": time.Now().Format(def.YYYYMMDDHHSSmm),
			}

			convData = append(convData, tmp)
		} else if con.DataConvertType == RAW {
			row["result_id"] = con.ResultId
			row["data_type"] = def.ReportResultTypeDic[con.ResultType]
			row["top_ccid"] = con.TopCCId
			convData = append(convData, row)
		}
	}

	con.SaveResult = convData
	return nil
}
