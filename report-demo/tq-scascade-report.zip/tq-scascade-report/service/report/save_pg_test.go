package report

import (
	"testing"
)

func TestBatchInsert(t *testing.T) {

}

func TestPlaceholder(t *testing.T) {

	var insertArgs = []string{"1", "2", "3", "4", "5", "6"}

	placeholder := "("
	for i := 0; i < len(insertArgs)-1; i++ {
		placeholder += "?, "
	}
	placeholder += "?)"

	t.Log(placeholder)
}

func TestJoinInsertSql(t *testing.T) {
	var insertArgs = []string{"result_id", "data_type", "ccid", "ccid_name", "cli_count", "avg_score"}
	tableName := "scascade_score_ccid"

	sql := buildInsertSql(insertArgs, tableName)
	compareSql := `INSERT INTO scascade_score_ccid (result_id, data_type, ccid, ccid_name, cli_count, avg_score) VALUES (:result_id, :data_type, :ccid, :ccid_name, :cli_count, :avg_score)`

	t.Log(sql)

	if sql != compareSql {
		t.Log("sql:", sql)
		t.Log("compareSql:", sql)
		t.Fatal()
	}
}
