package local_cron_job

import (
	"git-biz.qianxin-inc.cn/eps/skylar/apps/libs/tianqing.git/logs"
	"github.com/robfig/cron/v3"
	"tq-scascade-report/pkg/config"
	"tq-scascade-report/service"
)

// 定时删除历史数据任务
func LocalCronJobRun() {

	cronExpr := config.Cfg().ServerConf.ClearHistoryCron
	if len(cronExpr) <= 0 {
		cronExpr = "0 0 23 * * ?"
	}

	crontab := cron.New()
	crontab.AddFunc(cronExpr, func() {
		service.ClearUselessData()
	})

	crontab.Start()
	logs.Debugf("启动定时清理历史数据任务: [expr: %s]", cronExpr)
	select {}
}
