package service

import (
	"git-biz.qianxin-inc.cn/eps/skylar/apps/libs/tianqing.git/logs"
	"time"
	"tq-scascade-report/pkg/dao"
	"tq-scascade-report/pkg/def"
	"tq-scascade-report/service/cascade_config"
	"tq-scascade-report/service/report_show"
)

func ClearUselessData() {
	config, err := cascade_config.GetCascadeConfig()
	if err != nil {
		return
	}

	if config.LogAutoClear <= 0 {
		logs.Warnf("[ClearUselessDataByClickHouse] 过期数据清理配置[未开启].")
		return // 不删除过期数据
	}

	// 注意天数
	dropTimeStr := time.Now().AddDate(0, 0, (config.LogExpiredDays-1)*-1).Format(def.YYYYMMDD)
	// 仅保留日期
	dropTime, err := time.Parse(def.YYYYMMDD, dropTimeStr)
	if err != nil {
		return
	}

	go clearUselessSourceDataByClickHouse(dropTime)
	go clearUselessDataByReport(dropTime)
}

// 删除源数据--ClickHouse
func clearUselessSourceDataByClickHouse(dropTime time.Time) {

	for _, dropTable := range def.DropUselessSourceDataTableArr {
		err := dao.DropPartition(dropTable, dropTime)
		if err != nil {
			logs.Errorf("[ClearUselessDataByClickHouse] 清理过期无效数据时出错.[dropTable: %s] [dropTime: %s] [err: %s]",
				dropTable, dropTime, err.Error())
			continue
		}
	}

	return
}

// 删除 过期报表数据
func clearUselessDataByReport(dropTime time.Time) {

	dtoRes := dao.TaskResult{}
	uselessIds, err := dtoRes.ListOfUselessIds(dropTime)
	if err != nil {
		logs.Error("[clearUselessDataByReport]获取过期报表历史数据出错. err: ", err.Error())
		return
	}

	for _, id := range uselessIds {

		err := report_show.DeleteTaskResultWithDetail(id)
		if err != nil {
			logs.Error("[DeleteTaskResultWithDetail]获取过期报表历史数据出错.[resultId: %s] [err: %s]", id, err.Error())
			continue
		}
	}
}
