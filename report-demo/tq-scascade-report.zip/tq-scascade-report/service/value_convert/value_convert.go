package value_convert

import (
	"fmt"
	"git-biz.qianxin-inc.cn/eps/skylar/apps/libs/tianqing.git/logs"
	"tq-scascade-report/pkg/def"
	"tq-scascade-report/pkg/model"
	"tq-scascade-report/pkg/tools"
	"tq-scascade-report/service/cascade_config"
)

// 需要转换的字段
const (
	CCIDName       = "ccid_name"         // 控制中心名
	VirusCat       = "virus_cat"         // 病毒类型
	VirusTask      = "virus_task"        // 病毒触发方式
	VirusOption    = "virus_option"      // 病毒处理方式
	AlertType      = "alert_type"        // 事件类型
	LeakAction     = "leak_event_action" // 漏洞修复类型
	LeakFailReason = "leak_reason"       // 漏洞修复失败原因
	LeakType       = "leak_type"         // 漏洞级别
	AuditType      = "audit_type"        // 审计类型
)

// 查询对应的需要转换的Key映射
var reportCodeValueConvertMap = map[string][]string{

	// 定时报表--扫描分数
	def.SCORE_CCID: {
		CCIDName,
	},
	def.SCORE_SUMMARIZE_CLIENT_TOP10: {
		CCIDName,
	},
	def.SCORE_SUMMARIZE_CCID_TOP10: {
		CCIDName,
	},
	// 定时报表--病毒分析
	def.VIRUS_CCID: {
		CCIDName,
	},
	def.VIRUS_CLIENT: {
		CCIDName,
	},
	def.VIRUS_NAME: {
		VirusCat,
	},
	def.VIRUS_SUMMARIZE_CLIENT_TOP10: {
		CCIDName,
	},
	def.VIRUS_SUMMARIZE_CCID_TOP10: {
		CCIDName,
	},
	def.VIRUS_SUMMARIZE_VNAME_TOP10: {
		VirusCat,
	},
	def.VIRUS_SUMMARIZE_CAT_PER: {
		VirusCat,
	},
	def.VIRUS_SUMMARIZE_OPTION_PER: {
		VirusOption,
	},
	def.VIRUS_SUMMARIZE_TASK_PER: {
		VirusTask,
	},

	// 定时报表--漏洞分析
	def.LEAK_CCID: {
		CCIDName,
	},
	def.LEAK_CLIENT: {
		CCIDName,
	},
	def.LEAK_PATCH: {
		CCIDName,
		LeakType,
	},
	def.LEAK_SUMMARIZE_TREND: {
		LeakAction,
	},
	def.LEAK_SUMMARIZE_FAILURE_PER: {
		LeakFailReason,
	},
	def.LEAK_SUMMARIZE_LEVEL_PER: {
		LeakType,
	},
	def.LEAK_SUMMARIZE_CLIENT_TOP10: {
		CCIDName,
	},
	def.LEAK_SUMMARIZE_CCID_TOP10: {
		CCIDName,
	},
	//def.LEAK_SUMMARIZE_PATCH_TOP10:  {},

	// 定时报表--告警事件
	def.ALERT_SUMMARIZE_Type_PER: {
		AlertType,
	},
	def.ALERT_SUMMARIZE_COUNTS_PER: {
		CCIDName,
	},

	// 日志详情--扫描分数
	def.LOG_SCORE_CODE: {
		CCIDName,
	},
	// 日志详情--病毒分析
	def.LOG_VIRUS_CODE: {
		CCIDName,
	},
	// 日志详情--漏洞分析
	def.LOG_LEAK_CODE: {},
	// 日志详情--资产详情
	def.LOG_ASSET_CODE: {},
	// 日志详情--告警事件
	def.LOG_ALERT_CODE: {
		CCIDName,
		AlertType, // 事件类型
	},
	// 日志详情--审计日志
	def.LOG_AUDIT_CODE: {},
}

// resultId ==> 只针对定时报表类型，其CCID树的获取方式是使用本身记录的历史CCID树
// 而针对日志详情，获取最新的即可
func RowValueConvert(rowData map[string]interface{}, code string, resultId int64) (map[string]interface{}, error) {

	needConvertKeys, exist := reportCodeValueConvertMap[code]
	if !exist {
		// 无需转换，原数据返回
		return rowData, nil
	}

	// 提前准备数据
	prepareStatus, ccidNodes, err := tryPrepareCCIDTree(needConvertKeys, resultId)
	if prepareStatus && err != nil {
		// 需要转换但获取数据失败
		logs.Errorf("准备CCID数据时出错,无法正常完成ccidName的转换.[rowData: %#v] [resultId: %d]", rowData, resultId)
		return rowData, nil
	}

	for _, key := range needConvertKeys {
		switch key {
		case CCIDName: // 所在控制中心
			rowData = convertCCID2Name(rowData, ccidNodes)
		case VirusCat: // 病毒种类
			rowData = convertVirusCat2String(rowData)
		case VirusOption: // 病毒处理方式
			rowData = convertVirusOption2String(rowData)
		case VirusTask: // 病毒触发方式
			rowData = convertVirusTask2String(rowData)
		case AlertType: // 告警类型
			rowData = convertAlertType2String(rowData)
		case LeakAction: // 漏洞修复类型
			rowData = convertLeakAction2String(rowData)
		case LeakFailReason: // 漏洞修复失败原因
			rowData = convertLeakFailReason2String(rowData)
		case LeakType: // 漏洞级别
			rowData = convertLeakType2String(rowData)
		case AuditType: // 审计类型
			rowData = convertAuditType2String(rowData)
		default:
			return nil, fmt.Errorf("待转换字段[key: %s]有误. [rawData: %v]", key, rowData)
		}
	}

	return rowData, nil
}

func tryPrepareCCIDTree(needConvertKeys []string, resultId int64) (bool, []*model.CCIDNode, error) {

	need := false
	for _, key := range needConvertKeys {
		if key == CCIDName {
			need = true
		}
	}

	if need {
		var (
			ccidNodes []*model.CCIDNode
			err       error
		)
		// 获取树节点信息
		if resultId <= 0 {
			// 对于日志详情每次都获取最新的ccid节点树即可
			ccidNodes, _, err = cascade_config.GetCascadeCCIDTree()
			if err != nil {
				return need, nil, err // 转换出错则返回原数据不做转换
			}
			return need, ccidNodes, nil
		} else {
			// 对于定时报表而言，需要使用报表生成时记录的ccid节点树
			ccidNodes, _, err = cascade_config.GetCronReportCCIDTreeByResultId(resultId)
			if err != nil {
				return need, nil, err // 转换出错则返回原数据不做转换
			}
			return true, ccidNodes, nil
		}
	}

	return need, nil, nil
}

// 根据ccid 获取ccidName
func convertCCID2Name(rowData map[string]interface{}, ccidNodes []*model.CCIDNode) map[string]interface{} {

	ccid, ok := rowData["ccid"]
	if !ok {
		return rowData
	}

	for _, node := range ccidNodes {
		if node.CCID == ccid {
			rowData["ccid_name"] = node.Name
			break
		}
	}

	return rowData
}

// 将VirusCat转换为中文描述
func convertVirusCat2String(rowData map[string]interface{}) map[string]interface{} {
	var VirusCatMap = map[int]string{
		0:    "未知",
		1:    "木马",
		2:    "感染文件",
		3:    "高危程序",
		4:    "文件篡改",
		5:    "危险程序",
		6:    "广告程序",
		7:    "禁止启动",
		8:    "驱动禁止启动",
		9:    "被木马利用的程序",
		10:   "文件缺失",
		11:   "文件不存在的启动项",
		12:   "启动项被劫持",
		13:   "被劫持的系统文件",
		14:   "路由器WAN口DNS被篡改",
		15:   "数据库弱密码",
		100:  "MBR病毒",
		101:  "已经清除过的ROOTKIT",
		102:  "未知或损坏的压缩包",
		1000: "自动启动的非可执行文件",
		2000: "关键目录里未知的可执行文件",
		4000: "恶评插件",
		5000: "被篡改的IE设置",
		6000: "被篡改的系统设置",
		9999: "深度扫描最大的风险类型值",
	}

	rawCat, ok := rowData["virus_cat"]
	if !ok {
		return rowData
	}

	virusCat, err := tools.TryParseInt(rawCat)
	if err != nil {
		return rowData
	}
	catDesc, ok := VirusCatMap[virusCat]
	if ok {
		rowData["virus_cat_desc"] = catDesc
	}

	return rowData
}

// 将VirusOption转为中文描述
func convertVirusOption2String(rowData map[string]interface{}) map[string]interface{} {
	var VirusOptionMap = map[int]string{
		1: "未处理",
		2: "修复成功",
		3: "修复失败",
		4: "系统文件不做删除处理",
		5: "无效处理类型",
	}

	rawOption, ok := rowData["virus_option"]
	if !ok {
		return rowData
	}

	virusOption, err := tools.TryParseInt(rawOption)
	if err != nil {
		return rowData
	}
	catDesc, ok := VirusOptionMap[virusOption]
	if ok {
		rowData["virus_option_desc"] = catDesc
	}

	return rowData
}

// 将VirusTask转为中文描述
func convertVirusTask2String(rowData map[string]interface{}) map[string]interface{} {

	var VirusTaskMap = map[int]string{
		-1: "用户查杀",
		0:  "实时监控查杀",
		1:  "管理员查杀",
	}

	rawTask, ok := rowData["virus_task"]
	if !ok {
		return rowData
	}

	virusTask, err := tools.TryParseInt(rawTask)
	if err != nil {
		return rowData
	}
	catDesc, ok := VirusTaskMap[virusTask]
	if ok {
		rowData["virus_task_desc"] = catDesc
	}

	return rowData
}

// 将AlertType(type)转为中文描述
func convertAlertType2String(rowData map[string]interface{}) map[string]interface{} {
	var AlertTypeMap = map[string]string{
		"netout":                  "违规外联",
		"deviceout":               "接入外联设",
		"usbstorage":              "U盘使用告警",
		"peripherals":             "外设插入告警",
		"network":                 "网络防护",
		"process":                 "进程违规运行",
		"process_red":             "红名单进程检查",
		"desktop_configuration":   "系统配置变更",
		"account_change":          "系统账号变更",
		"remotedesktop":           "远程受控",
		"process_regedit":         "使用注册表编辑器违规",
		"weak_password":           "弱口令告警",
		"cancle_pcoff":            "取消定时关机",
		"network_flow":            "流量告警",
		"client_uninst":           "客户端卸载",
		"msconfig_change":         "启动项变更",
		"pc_onoff":                "开关机",
		"update_ipormac":          "ip mac变更",
		"illegal_ssid_connection": "非法ssid连接",
		"update_systemtime":       "修改系统时间",
		"password_attempt":        "密码错误",
		"Multisystem":             "多操作系统",
		"service_alarm":           "服务管理告警",
		"error_protect_pwd":       "卸载密码错误",
		"error_exit_pwd":          "退出密码错误",
		"dualnet_connection":      "有线无线共用",
		"internet_ip":             "互联网出口上报",
		"ip_collision":            "终端ip冲突事件上报格式",
		"new_accesss":             "新设备发现数据上报格式",
		"ip_offline":              "设备下线数据上报格式",
		"service_change":          "服务变更上报",
	}

	rawType, ok := rowData["type"]
	if !ok {
		return rowData
	}

	alertType, ok := rawType.(string)
	if !ok {
		return rowData
	}
	typeDesc, ok := AlertTypeMap[alertType]
	if ok {
		rowData["type_desc"] = typeDesc
	}

	return rowData
}

// 将LeakAction转为中文描述
func convertLeakAction2String(rowData map[string]interface{}) map[string]interface{} {
	var LeakActionMap = map[int]string{
		1: "发现",
		2: "修复成功",
		3: "修复失败",
		4: "忽略漏洞",
		5: "用户取消忽略",
		6: "用户卸载漏洞",
	}

	rawAction, ok := rowData["event_action"]
	if !ok {
		return rowData
	}

	LeakAction, err := tools.TryParseInt(rawAction)
	if err != nil {
		return rowData
	}
	actionDesc, ok := LeakActionMap[LeakAction]
	if ok {
		rowData["event_action_desc"] = actionDesc
	}

	return rowData
}

// 将LeakFailReason转为中文描述
func convertLeakFailReason2String(rowData map[string]interface{}) map[string]interface{} {
	var LeakReasonMap = map[int]string{
		600: "其他",
		601: "下载失败",
		602: "签名验证失败",
		603: "签名无效",
		604: "安装失败",
		605: "用户取消",
		606: "修复超时",
	}

	rawReason, ok := rowData["reason"]
	if !ok {
		return rowData
	}

	LeakReason, err := tools.TryParseInt(rawReason)
	if err != nil {
		return rowData
	}
	reasonDesc, ok := LeakReasonMap[LeakReason]
	if ok {
		rowData["reason_desc"] = reasonDesc
	}

	return rowData
}

// 将LeakType转为中文描述
func convertLeakType2String(rowData map[string]interface{}) map[string]interface{} {
	var LeakTypeMap = map[int]string{
		1: "高危",
		2: "软件安全更新",
		3: "高危可选",
		4: "其他",
	}

	rawType, ok := rowData["leak_type"]
	if !ok {
		return rowData
	}

	leakType, err := tools.TryParseInt(rawType)
	if err != nil {
		return rowData
	}
	leakTypeDesc, ok := LeakTypeMap[leakType]
	if ok {
		rowData["leak_type_desc"] = leakTypeDesc
	} else {
		rowData["leak_type_desc"] = "其他"
	}

	return rowData
}

// 将AuditType转为中文描述
func convertAuditType2String(rowData map[string]interface{}) map[string]interface{} {
	var AuditTypeMap = map[string]string{
		"audit_software":   "软件使用日志",
		"audit_device":     "外设使用日志",
		"audit_power":      "开关机日志",
		"audit_account":    "系统账号日志",
		"audit_network":    "网络访问日志",
		"audit_safe_udisk": "安全U盘日志",
		"file_rp":          "文件操作日志",
		"file_usb":         "文件操作日志",
		"file_browser":     "文件操作日志",
		"print_n":          "文件打印日志",
		"mail_n":           "邮件记录日志",
		"im_audit":         "IM审计日志",
	}

	rawType, ok := rowData["type"]
	if !ok {
		return rowData
	}

	auditType, ok := rawType.(string)
	if !ok {
		return rowData
	}
	auditTypeDesc, ok := AuditTypeMap[auditType]
	if ok {
		rowData["audit_type_desc"] = auditTypeDesc
	}

	return rowData
}
