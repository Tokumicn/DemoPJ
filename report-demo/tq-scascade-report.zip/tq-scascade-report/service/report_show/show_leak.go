package report_show

import (
	"fmt"
	"git-biz.qianxin-inc.cn/eps/skylar/apps/libs/tianqing.git/logs"
	"tq-scascade-report/pkg/def"
	"tq-scascade-report/pkg/model"
)

// 按控制中心统计
func buildLeakCCIDDetail(rawData []map[string]interface{}) (*model.ReportDetailViewModel, error) {

	var fieldsLeakCCID = []string{
		"ccid",
		"ccid_name",
		"cli_count",
		"founds",
		"fixs",
		"ignores",
	}

	result := commonBuildReportDetailHelper(rawData, fieldsLeakCCID, def.LEAK_CCID)
	return result, nil
}

// 按终端统计
func buildLeakClientDetail(rawData []map[string]interface{}) (*model.ReportDetailViewModel, error) {

	var fieldsLeakClient = []string{
		"client_mid",
		"client_name",
		"client_third_login_user",
		"client_ip",
		"client_mac",
		"ccid",
		"ccid_name",
		"founds",
		"fixs",
		"ignores",
	}

	result := commonBuildReportDetailHelper(rawData, fieldsLeakClient, def.LEAK_CLIENT)
	return result, nil
}

// 按漏洞统计
func buildLeakPatchDetail(rawData []map[string]interface{}) (*model.ReportDetailViewModel, error) {

	var fieldsVirusName = []string{
		"kbid",
		"leak_name",
		"leak_type",
		"leak_type_desc",
		"founds",
		"fixs",
		"ignores",
	}

	result := commonBuildReportDetailHelper(rawData, fieldsVirusName, def.VIRUS_NAME)
	return result, nil
}

var leakSumFieldsMap = map[string][]string{
	// 趋势图
	def.LEAK_SUMMARIZE_TREND: {
		"result_id",
		"event_action",
		"event_action_desc",
		"total",
		"etime",
		"eyear",
	},

	// 比例图
	def.LEAK_SUMMARIZE_FAILURE_PER: {
		"result_id",
		"reason",
		"reason_desc",
		"total",
	},
	def.LEAK_SUMMARIZE_LEVEL_PER: {
		"result_id",
		"leak_type",
		"leak_type_desc",
		"total",
	},

	// Top10图表
	def.LEAK_SUMMARIZE_CCID_TOP10: {
		"result_id",
		"ccid",
		"ccid_name",
		"install_count",
	},
	def.LEAK_SUMMARIZE_CLIENT_TOP10: {
		"result_id",
		"client_mid",
		"client_name",
		"client_ip",
		"client_mac",
		"client_third_login_user",
		"ccid",
		"ccid_name",
		"install_count",
	},
	def.LEAK_SUMMARIZE_PATCH_TOP10: {
		"result_id",
		"kbid",      // 补丁号
		"leak_name", // 漏洞补丁名
		"install_count",
	},
}

const (
	trendKey        = "event_action"
	trendCodeFound  = "LeakSumTrendFound"
	trendCodeFix    = "LeakSumTrendFix"
	trendCodeIgnore = "LeakSumTrendIgnore"
)

// 汇总统计
func buildLeakSummarizeDetail(rawData []map[string]interface{}) (*model.ReportDetailViewModel, error) {

	// 趋势图
	resTrendFound := make([]map[string]interface{}, 0)
	resTrendFix := make([]map[string]interface{}, 0)
	resTrendIgnore := make([]map[string]interface{}, 0)

	// 比例图表
	resFailurePer := make([]map[string]interface{}, 0)
	resLevelPer := make([]map[string]interface{}, 0)

	// Top10图表
	resClientTop10 := make([]map[string]interface{}, 0)
	resCCIDTop10 := make([]map[string]interface{}, 0)
	resPatchTop10 := make([]map[string]interface{}, 0)

	for i, raw := range rawData {
		var tempType int
		_, exist := rawData[i]["data_type"]
		if !exist {
			logs.Error("[buildLeakSummarizeDetail] get dataType failed.")
			continue
		} else {
			tempType = int(rawData[i]["data_type"].(int64))
		}
		reportType := def.GlobalDic[tempType]

		switch reportType {
		// 趋势图
		case def.LEAK_SUMMARIZE_TREND:
			temp := setMapFields(raw, leakSumFieldsMap[def.LEAK_SUMMARIZE_TREND])
			for key, val := range temp {
				if key == trendKey {
					tempAction := val.(float64)

					if tempAction == 1 { // 已发现漏洞
						resTrendFound = append(resTrendFound, temp)
					} else if tempAction == 2 { // 已修复漏洞
						resTrendFix = append(resTrendFix, temp)
					} else if tempAction == 4 { // 已忽略漏洞
						resTrendIgnore = append(resTrendIgnore, temp)
					}
				}
			}

			// 比例图表
		case def.LEAK_SUMMARIZE_FAILURE_PER:
			temp := setMapFields(raw, leakSumFieldsMap[def.LEAK_SUMMARIZE_FAILURE_PER])
			resFailurePer = append(resFailurePer, temp)
		case def.LEAK_SUMMARIZE_LEVEL_PER:
			temp := setMapFields(raw, leakSumFieldsMap[def.LEAK_SUMMARIZE_LEVEL_PER])
			resLevelPer = append(resLevelPer, temp)

			// Top10图表
		case def.LEAK_SUMMARIZE_CLIENT_TOP10:
			temp := setMapFields(raw, leakSumFieldsMap[def.LEAK_SUMMARIZE_CLIENT_TOP10])
			resClientTop10 = append(resClientTop10, temp)
		case def.LEAK_SUMMARIZE_CCID_TOP10:
			temp := setMapFields(raw, leakSumFieldsMap[def.LEAK_SUMMARIZE_CCID_TOP10])
			resCCIDTop10 = append(resCCIDTop10, temp)
		case def.LEAK_SUMMARIZE_PATCH_TOP10:
			temp := setMapFields(raw, leakSumFieldsMap[def.LEAK_SUMMARIZE_PATCH_TOP10])
			resPatchTop10 = append(resPatchTop10, temp)
		default:
			return nil, fmt.Errorf("[buildLeakSummarizeDetail] reportType[%s] is invalid.", reportType)
		}
	}

	details := make([]*model.ReportDetail, 0)

	// 趋势图
	detTrendFound := &model.ReportDetail{
		Code: trendCodeFound,
		Data: resTrendFound,
	}
	details = append(details, detTrendFound)

	detTrendFix := &model.ReportDetail{
		Code: trendCodeFix,
		Data: resTrendFix,
	}
	details = append(details, detTrendFix)

	detTrendIgnore := &model.ReportDetail{
		Code: trendCodeIgnore,
		Data: resTrendIgnore,
	}
	details = append(details, detTrendIgnore)

	// 比例图表
	detFailurePer := &model.ReportDetail{
		Code: def.LEAK_SUMMARIZE_FAILURE_PER,
		Data: resFailurePer,
	}
	details = append(details, detFailurePer)

	detLevelPer := &model.ReportDetail{
		Code: def.LEAK_SUMMARIZE_LEVEL_PER,
		Data: resLevelPer,
	}
	details = append(details, detLevelPer)

	// Top10图表
	detClientTop10 := &model.ReportDetail{
		Code: def.LEAK_SUMMARIZE_CLIENT_TOP10,
		Data: resClientTop10,
	}
	details = append(details, detClientTop10)

	detCCIDTop10 := &model.ReportDetail{
		Code: def.LEAK_SUMMARIZE_CCID_TOP10,
		Data: resCCIDTop10,
	}
	details = append(details, detCCIDTop10)

	detPatchTop10 := &model.ReportDetail{
		Code: def.LEAK_SUMMARIZE_PATCH_TOP10,
		Data: resPatchTop10,
	}
	details = append(details, detPatchTop10)

	return &model.ReportDetailViewModel{
		Detail: details,
	}, nil
}
