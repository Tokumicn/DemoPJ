package report_show

import (
	"fmt"
	"tq-scascade-report/pkg/advanced_search"
	"tq-scascade-report/pkg/dao"
	"tq-scascade-report/pkg/def"
	"tq-scascade-report/pkg/model"
	"tq-scascade-report/pkg/tools"
	"tq-scascade-report/service/cascade_config"

	"git-biz.qianxin-inc.cn/eps/skylar/apps/libs/tianqing.git/logs"
)

func GetReportDetailCCIdTree(viewM *model.ResultIdRequest) ([]*model.CCIDNode, error) {

	ccidTree, _, err := cascade_config.GetCronReportCCIDTreeByResultId(viewM.ResultId)
	if err != nil {
		return nil, err
	}

	return ccidTree, nil
}

func GetReportDetailById(query *model.ResultQueryRequest) (*model.ReportDetailViewModel, error) {

	// 特殊处理汇总统计
	if query.ReportType == def.SUMMARIZE {
		return GetSummarizeReportDetailById(&model.SummarizeResultQueryRequest{
			ResultId: query.ResultId,
			TopCCId:  query.TopCCId,
		})
	}

	condition, err := dao.GetReportDetailCondition(query.ResultId)
	if err != nil {
		return nil, err
	}

	reportTypeArr := tools.SplitStrWithoutEmpty(condition.ReportTypes, ",")
	if !def.ReportTypesContain(reportTypeArr, query.ReportType) {
		return nil, fmt.Errorf("报表创建时未选择该类型.")
	}

	tableName, err := def.GetTableNameByType(condition.Business, query.ReportType)
	if err != nil {
		logs.Error("[GetReportDetailById--GetTableNameByType] error: ", err.Error())
		return nil, err
	}

	// 根据传入的TopCCId获取过滤用的CCId
	ccidArr, err := cascade_config.GetResultCCIdListByTop(query.ResultId, query.TopCCId)
	if err != nil {
		return nil, err
	}
	query.CCIds = ccidArr

	rawData, total, err := getReportShowData(query, tableName, query.ReportType)
	if err != nil {
		return nil, err
	}

	// 根据数据DataType构建输出结果
	detailViewModel, err := buildDetailData(rawData)
	if err != nil {
		return nil, err
	}

	detailViewModel.Total = total
	return detailViewModel, err
}

func GetSummarizeReportDetailById(query *model.SummarizeResultQueryRequest) (*model.ReportDetailViewModel, error) {
	condition, err := dao.GetReportDetailCondition(query.ResultId)
	if err != nil {
		return nil, err
	}

	tableName, err := def.GetTableNameByType(condition.Business, def.SUMMARIZE)
	if err != nil {
		logs.Error("[GetSummarizeReportDetailById--GetTableNameByType] error: ", err.Error())
		return nil, err
	}

	sumRawData, total, err := dao.GetSummarizeReportDetailData(query.ResultId, tableName, query.TopCCId)
	if err != nil {
		logs.Errorf("[GetSummarizeReportDetailById--GetSummarizeReportDetailData] [resultId: %s] [topCCId: %s] [error: %s]", query.ResultId, query.TopCCId, err.Error())
		return nil, err
	}

	// 根据数据DataType构建输出结果
	detailViewModel, err := buildDetailData(sumRawData)
	if err != nil {
		return nil, err
	}

	detailViewModel.Total = total
	return detailViewModel, err
}

func getReportShowData(query *model.ResultQueryRequest, tableName, reportType string) ([]map[string]interface{}, int, error) {
	return getReportDetailDataWithQuery(query, tableName)
}

// 构建输出数据
func buildDetailData(rawData []map[string]interface{}) (*model.ReportDetailViewModel, error) {

	if rawData == nil || len(rawData) <= 0 {
		return nil, fmt.Errorf("raw data is empty.")
	}

	var dataTypeInt int
	_, exist := rawData[0]["data_type"]
	if !exist {
		logs.Error("get dataType failed.")
	} else {
		dataTypeInt = int(rawData[0]["data_type"].(int64))
	}

	dataType := def.GlobalDic[dataTypeInt]

	switch dataType {

	// 扫描分数
	case def.SCORE_CCID:
		return buildScoreCCIDDetail(rawData)
	case def.SCORE_SUMMARIZE_TREND, def.SCORE_SUMMARIZE_CCID_TOP10, def.SCORE_SUMMARIZE_CLIENT_TOP10:
		return buildScoreSummarizeDetail(rawData)

	// 病毒分析
	case def.VIRUS_CCID:
		return buildVirusCCIDDetail(rawData)
	case def.VIRUS_CLIENT:
		return buildVirusClientDetail(rawData)
	case def.VIRUS_NAME:
		return buildVirusNameDetail(rawData)
	case def.VIRUS_SUMMARIZE_TREND_NAME,
		def.VIRUS_SUMMARIZE_TREND_KILLCOUNT,
		def.VIRUS_SUMMARIZE_TREND_ClientCOUNT,
		def.VIRUS_SUMMARIZE_CAT_PER,
		def.VIRUS_SUMMARIZE_OPTION_PER,
		def.VIRUS_SUMMARIZE_TASK_PER,
		def.VIRUS_SUMMARIZE_CLIENT_TOP10,
		def.VIRUS_SUMMARIZE_CCID_TOP10,
		def.VIRUS_SUMMARIZE_VNAME_TOP10:
		return buildVirusSummarizeDetail(rawData)

	// 漏洞分析
	case def.LEAK_CCID:
		return buildLeakCCIDDetail(rawData)
	case def.LEAK_CLIENT:
		return buildLeakClientDetail(rawData)
	case def.LEAK_PATCH:
		return buildLeakPatchDetail(rawData)
	case def.LEAK_SUMMARIZE_TREND,
		def.LEAK_SUMMARIZE_FAILURE_PER,
		def.LEAK_SUMMARIZE_LEVEL_PER,
		def.LEAK_SUMMARIZE_CLIENT_TOP10,
		def.LEAK_SUMMARIZE_CCID_TOP10,
		def.LEAK_SUMMARIZE_PATCH_TOP10:
		return buildLeakSummarizeDetail(rawData)

	// 告警事件
	case def.ALERT_SUMMARIZE_TREND,
		def.ALERT_SUMMARIZE_Type_PER,
		def.ALERT_SUMMARIZE_COUNTS_PER:
		return buildAlertSummarizeDetail(rawData)

	default:
		return nil, fmt.Errorf("current data type[%s] is invalid.", dataType)
	}
}

// 获取日志详情--分页、排序、查询
func getReportDetailDataWithQuery(query *model.ResultQueryRequest, tableName string) ([]map[string]interface{}, int, error) {

	allow, err := checkOrderArgs(query, tableName)
	if err != nil {
		return nil, -1, err
	}

	// 当前排序字段不被允许 则直接丢弃 改为使用默认值
	if !allow {
		query.Order = 1
		query.OrderCondition = "id"
	}

	// 构建where语句
	whereStr, args, err := reportDetailWhereBuilder(query, tableName)
	if err != nil {
		return nil, -1, err
	}

	// 构建total sql
	sTotal := &advanced_search.Search{
		T: tableName,
		W: whereStr,
	}
	totalSql, err := sTotal.BuildTotalSQL()
	if err != nil {
		return nil, -1, err
	}

	// 构建分页查询 sql
	if len(query.OrderCondition) <= 0 {
		query.Order = 1
		query.OrderCondition = "id"
	}
	search := &advanced_search.Search{
		S: "*", // 为通用处理使用*
		T: tableName,
		W: whereStr,
		G: "", // 无需分组查询
		OrderArgs: &model.OrderArgs{
			Order:          query.Order,
			OrderCondition: query.OrderCondition,
		},
		PageArgs: &model.PagingArgs{
			DBType:   def.POSTGRES_DBType,
			Current:  query.Current,
			PageSize: query.PageSize,
		},
	}
	querySql, err := search.BuildSQL()
	if err != nil {
		return nil, -1, err
	}

	// 获取分页数据
	return dao.GetReportDetailDataWithQuery(querySql, totalSql, args)
}

func DeleteTaskResultWithDetail(resultId int64) error {

	err := dao.DeleteReportDetailData(resultId)
	if err != nil {
		return err
	}

	resDto := &dao.TaskResult{
		Id: resultId,
	}

	// 删除结果记录
	err = resDto.Delete()
	if err != nil {
		return err
	}

	return nil
}
