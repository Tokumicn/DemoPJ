package report_show

import (
	"testing"
	"tq-scascade-report/pkg/model"
)

func init() {

}

func TestReportDetailWhereBuilder(t *testing.T) {

	//whereBuilder, args, err := reportDetailWhereBuilder(&model.ResultQueryRequest{
	//	ResultId:       111,
	//	WhereArgs:      "nameXXX",
	//	PageSize:       20,
	//	Current:        1,
	//	Order:          -1,
	//	OrderCondition: "avg_score",
	//}, "scascade_score_ccid")

	whereBuilder, args, err := reportDetailWhereBuilder(&model.ResultQueryRequest{
		ResultId:       111,
		WhereArgs:      "XXX",
		PageSize:       20,
		Current:        1,
		Order:          -1,
		OrderCondition: "all_kills",
	}, "scascade_virus_client")

	if err != nil {
		t.Fatal(err)
	}

	t.Log("\nwhere: ", whereBuilder)
	t.Logf("\nargs:%#v", args)
}
