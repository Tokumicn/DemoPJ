package report_show

import (
	"errors"
	"fmt"
	"tq-scascade-report/pkg/model"
	"tq-scascade-report/service/report/security"
)

var (
	ERR_REPORTDETAIL_QueryFieldNotExist = errors.New("该数据集查询字段未找到")
	ERR_REPORTDETAIL_OrderFieldNotExist = errors.New("该数据集排序字段未找到")
)

// Build Where string & args
func reportDetailWhereBuilder(query *model.ResultQueryRequest, tableName string) (string, map[string]interface{}, error) {

	var (
		subWhereStr   = ""
		basicWhereStr = "result_id = :result_id AND ccid IN (:ccIds)"
	)

	args := map[string]interface{}{
		"result_id": query.ResultId,
		"ccIds":     query.CCIds,
	}

	if len(query.WhereArgs) <= 0 {
		return basicWhereStr, args, nil
	}

	// 获取该业务允许的查询字段
	queryKeys, ok := security.ReportDetailTableQueryMap[tableName]
	if !ok {
		return "", nil, ERR_REPORTDETAIL_QueryFieldNotExist
	}

	for key, _ := range queryKeys {
		args[key] = "%" + query.WhereArgs + "%" // 查询参数匹配为  前后都模糊
		if len(subWhereStr) > 0 {
			subWhereStr += " OR "
		}
		subWhereStr += fmt.Sprintf("%s like :%s", key, key)
	}

	whereStr := ""
	if len(subWhereStr) > 0 {
		whereStr = fmt.Sprintf("%s AND (%s)", basicWhereStr, subWhereStr)
	}

	return whereStr, args, nil
}

// 检查排序参数是否允许
func checkOrderArgs(query *model.ResultQueryRequest, tableName string) (bool, error) {

	if len(query.OrderCondition) <= 0 {
		query.Order = 0 // 默认值
		return true, nil
	}

	// 获取该业务允许的排序字段
	orderKeys, ok := security.ReportDetailTableAllowOrderMap[tableName]
	if !ok {
		return false, ERR_REPORTDETAIL_OrderFieldNotExist
	}

	// 判断查询字段是否允许
	if _, allow := orderKeys[query.OrderCondition]; allow {
		return true, nil
	}

	return false, nil
}
