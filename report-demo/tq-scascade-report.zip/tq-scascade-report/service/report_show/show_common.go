package report_show

import (
	"encoding/json"
	"git-biz.qianxin-inc.cn/eps/skylar/apps/libs/tianqing.git/logs"
	"tq-scascade-report/pkg/model"
)

func commonBuildReportDetailHelper(rawData []map[string]interface{}, showFields []string, reportCode string) *model.ReportDetailViewModel {
	result := make([]map[string]interface{}, 0)
	for _, raw := range rawData {

		data := setMapFields(raw, showFields)
		result = append(result, data)
	}

	details := make([]*model.ReportDetail, 0)
	det := &model.ReportDetail{
		Code: reportCode,
		Data: result,
	}
	details = append(details, det)

	return &model.ReportDetailViewModel{
		Detail: details,
	}
}

func setMapFields(rawMap map[string]interface{}, fieldNameArr []string) map[string]interface{} {
	temp := map[string]interface{}{}
	extMap := map[string]interface{}{}
	ext, ok := rawMap["ext"]
	if ok {
		extStr := ext.(string)

		// ext为空排除
		if len(extStr) > 0 {
			err := json.Unmarshal([]byte(extStr), &extMap)
			if err != nil {
				logs.Errorf("[setMapFields] raw[%#v] ext[%#v] json unmarshal err:%s", rawMap, ext, err.Error())
			}
		}
	}

	for _, field := range fieldNameArr {
		// 元数据中获取
		if val, ok := rawMap[field]; ok {
			temp[field] = val
		}

		// ext数据中获取
		if val, ok := extMap[field]; ok {
			temp[field] = val
		}
	}
	return temp
}
