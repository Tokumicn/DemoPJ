package report_show

import (
	"fmt"
	"git-biz.qianxin-inc.cn/eps/skylar/apps/libs/tianqing.git/logs"
	"tq-scascade-report/pkg/def"
	"tq-scascade-report/pkg/model"
)

// 按控制中心统计
func buildVirusCCIDDetail(rawData []map[string]interface{}) (*model.ReportDetailViewModel, error) {

	var fieldsVirusCCID = []string{
		"result_id",
		"ccid",
		"ccid_name",
		"cli_count",
		"all_kills",
		"monitor_kills",
		"user_kills",
		"admin_kills",
	}

	result := commonBuildReportDetailHelper(rawData, fieldsVirusCCID, def.VIRUS_CCID)
	return result, nil
}

// 按终端统计
func buildVirusClientDetail(rawData []map[string]interface{}) (*model.ReportDetailViewModel, error) {

	var fieldsVirusClient = []string{
		"result_id",
		"client_mid",
		"client_name",
		"client_third_login_user",
		"client_ip",
		"client_mac",
		"ccid",
		"ccid_name",
		"all_kills",
		"monitor_kills",
		"user_kills",
		"admin_kills",
	}

	result := commonBuildReportDetailHelper(rawData, fieldsVirusClient, def.VIRUS_CLIENT)
	return result, nil
}

// 按病毒统计
func buildVirusNameDetail(rawData []map[string]interface{}) (*model.ReportDetailViewModel, error) {

	var fieldsVirusName = []string{
		"result_id",
		"vname",
		"virus_cat",
		"virus_cat_desc",
		"cli_count",
		"all_kills",
		"monitor_kills",
		"user_kills",
		"admin_kills",
		"ccid",
	}

	result := commonBuildReportDetailHelper(rawData, fieldsVirusName, def.VIRUS_NAME)
	return result, nil
}

var virusSumFieldsMap = map[string][]string{
	// 趋势图
	def.VIRUS_SUMMARIZE_TREND_NAME: {
		"result_id",
		"vname_count",
		"etime",
		"eyear",
	},
	def.VIRUS_SUMMARIZE_TREND_KILLCOUNT: {
		"result_id",
		"kill_count",
		"etime",
		"eyear",
	},
	def.VIRUS_SUMMARIZE_TREND_ClientCOUNT: {
		"result_id",
		"cli_count",
		"etime",
		"eyear",
	},

	// 比例图
	def.VIRUS_SUMMARIZE_CAT_PER: {
		"result_id",
		"virus_cat",
		"virus_cat_desc",
		"total",
	},
	def.VIRUS_SUMMARIZE_OPTION_PER: {
		"result_id",
		"virus_option",
		"virus_option_desc",
		"total",
	},
	def.VIRUS_SUMMARIZE_TASK_PER: {
		"result_id",
		"virus_task",
		"virus_task_desc",
		"total",
	},

	// Top10图表
	def.VIRUS_SUMMARIZE_CCID_TOP10: {
		"result_id",
		"ccid",
		"ccid_name",
		"cli_count",
		"all_kills",
	},
	def.VIRUS_SUMMARIZE_CLIENT_TOP10: {
		"result_id",
		"client_mid",
		"client_name",
		"client_ip",
		"client_mac",
		"client_third_login_user",
		"ccid",
		"ccid_name",
		"all_kills",
	},
	def.VIRUS_SUMMARIZE_VNAME_TOP10: {
		"result_id",
		"vname",
		"virus_cat",
		"virus_cat_desc",
		"cli_count",
		"all_kills",
	},
}

// 汇总统计
func buildVirusSummarizeDetail(rawData []map[string]interface{}) (*model.ReportDetailViewModel, error) {

	// 趋势图
	resTrendName := make([]map[string]interface{}, 0)
	resTrendKillCount := make([]map[string]interface{}, 0)
	resTrendClientCount := make([]map[string]interface{}, 0)

	// 比例图表
	resCatPer := make([]map[string]interface{}, 0)
	resOptionPer := make([]map[string]interface{}, 0)
	resTaskPer := make([]map[string]interface{}, 0)

	// Top10图表
	resClientTop10 := make([]map[string]interface{}, 0)
	resCCIDTop10 := make([]map[string]interface{}, 0)
	resVNameTop10 := make([]map[string]interface{}, 0)

	for i, raw := range rawData {
		var tempType int
		_, exist := rawData[i]["data_type"]
		if !exist {
			logs.Error("[buildVirusSummarizeDetail] get dataType failed.")
			continue
		} else {
			tempType = int(rawData[i]["data_type"].(int64))
		}
		reportType := def.GlobalDic[tempType]

		switch reportType {
		// 趋势图
		case def.VIRUS_SUMMARIZE_TREND_NAME:
			temp := setMapFields(raw, virusSumFieldsMap[def.VIRUS_SUMMARIZE_TREND_NAME])
			resTrendName = append(resTrendName, temp)
		case def.VIRUS_SUMMARIZE_TREND_KILLCOUNT:
			temp := setMapFields(raw, virusSumFieldsMap[def.VIRUS_SUMMARIZE_TREND_KILLCOUNT])
			resTrendKillCount = append(resTrendKillCount, temp)
		case def.VIRUS_SUMMARIZE_TREND_ClientCOUNT:
			temp := setMapFields(raw, virusSumFieldsMap[def.VIRUS_SUMMARIZE_TREND_ClientCOUNT])
			resTrendClientCount = append(resTrendClientCount, temp)

			// 比例图表
		case def.VIRUS_SUMMARIZE_CAT_PER:
			temp := setMapFields(raw, virusSumFieldsMap[def.VIRUS_SUMMARIZE_CAT_PER])
			resCatPer = append(resCatPer, temp)
		case def.VIRUS_SUMMARIZE_OPTION_PER:
			temp := setMapFields(raw, virusSumFieldsMap[def.VIRUS_SUMMARIZE_OPTION_PER])
			resOptionPer = append(resOptionPer, temp)
		case def.VIRUS_SUMMARIZE_TASK_PER:
			temp := setMapFields(raw, virusSumFieldsMap[def.VIRUS_SUMMARIZE_TASK_PER])
			resTaskPer = append(resTaskPer, temp)

			// Top10图表
		case def.VIRUS_SUMMARIZE_CLIENT_TOP10:
			temp := setMapFields(raw, virusSumFieldsMap[def.VIRUS_SUMMARIZE_CLIENT_TOP10])
			resClientTop10 = append(resClientTop10, temp)
		case def.VIRUS_SUMMARIZE_CCID_TOP10:
			temp := setMapFields(raw, virusSumFieldsMap[def.VIRUS_SUMMARIZE_CCID_TOP10])
			resCCIDTop10 = append(resCCIDTop10, temp)
		case def.VIRUS_SUMMARIZE_VNAME_TOP10:
			temp := setMapFields(raw, virusSumFieldsMap[def.VIRUS_SUMMARIZE_VNAME_TOP10])
			resVNameTop10 = append(resVNameTop10, temp)
		default:
			return nil, fmt.Errorf("[buildVirusSummarizeDetail] reportType[%s] is invalid.", reportType)
		}
	}

	details := make([]*model.ReportDetail, 0)

	// 趋势图
	detTrendName := &model.ReportDetail{
		Code: def.VIRUS_SUMMARIZE_TREND_NAME,
		Data: resTrendName,
	}
	details = append(details, detTrendName)

	detTrendKillCount := &model.ReportDetail{
		Code: def.VIRUS_SUMMARIZE_TREND_KILLCOUNT,
		Data: resTrendKillCount,
	}
	details = append(details, detTrendKillCount)

	detTrendClientCount := &model.ReportDetail{
		Code: def.VIRUS_SUMMARIZE_TREND_ClientCOUNT,
		Data: resTrendClientCount,
	}
	details = append(details, detTrendClientCount)

	// 比例图表
	detCatPer := &model.ReportDetail{
		Code: def.VIRUS_SUMMARIZE_CAT_PER,
		Data: resCatPer,
	}
	details = append(details, detCatPer)

	detOptionPer := &model.ReportDetail{
		Code: def.VIRUS_SUMMARIZE_OPTION_PER,
		Data: resOptionPer,
	}
	details = append(details, detOptionPer)

	detTaskPer := &model.ReportDetail{
		Code: def.VIRUS_SUMMARIZE_TASK_PER,
		Data: resTaskPer,
	}
	details = append(details, detTaskPer)

	// Top10图表
	detClientTop10 := &model.ReportDetail{
		Code: def.VIRUS_SUMMARIZE_CLIENT_TOP10,
		Data: resClientTop10,
	}
	details = append(details, detClientTop10)

	detCCIDTop10 := &model.ReportDetail{
		Code: def.VIRUS_SUMMARIZE_CCID_TOP10,
		Data: resCCIDTop10,
	}
	details = append(details, detCCIDTop10)

	detVNameTop10 := &model.ReportDetail{
		Code: def.VIRUS_SUMMARIZE_VNAME_TOP10,
		Data: resVNameTop10,
	}
	details = append(details, detVNameTop10)

	return &model.ReportDetailViewModel{
		Detail: details,
	}, nil
}
