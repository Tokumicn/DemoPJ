package report_show

import (
	"fmt"

	"tq-scascade-report/pkg/def"
	"tq-scascade-report/pkg/model"

	"git-biz.qianxin-inc.cn/eps/skylar/apps/libs/tianqing.git/logs"
)

var scoreFieldsMap = map[string][]string{
	def.SCORE_SUMMARIZE_TREND: {
		"result_id",
		"avg_score",
		"etime",
		"eyear",
	},
	def.SCORE_SUMMARIZE_CLIENT_TOP10: {
		"result_id",
		"avg_score",
		"client_mid",
		"client_name",
		"client_ip",
		"client_mac",
		"client_third_login_user",
		"ccid",
		"ccid_name",
	},
	def.SCORE_SUMMARIZE_CCID_TOP10: {
		"result_id",
		"ccid",
		"ccid_name",
		"avg_score",
	},
}

func buildScoreCCIDDetail(rawData []map[string]interface{}) (*model.ReportDetailViewModel, error) {

	var fieldsScoreCCID = []string{
		"result_id",
		"ccid",
		"ccid_name",
		"cli_count",
		"avg_score",
	}

	result := commonBuildReportDetailHelper(rawData, fieldsScoreCCID, def.SCORE_CCID)
	return result, nil
}

func buildScoreSummarizeDetail(rawData []map[string]interface{}) (*model.ReportDetailViewModel, error) {

	resTrend := make([]map[string]interface{}, 0)
	resClientTop := make([]map[string]interface{}, 0)
	resCCIDTop := make([]map[string]interface{}, 0)

	for i, raw := range rawData {

		var tempType int
		_, exist := rawData[i]["data_type"]
		if !exist {
			logs.Error("[buildScoreSummarizeDetail] get dataType failed.")
			continue
		} else {
			tempType = int(rawData[i]["data_type"].(int64))
		}

		reportType := def.GlobalDic[tempType]

		switch reportType {
		case def.SCORE_SUMMARIZE_TREND:
			temp := setMapFields(raw, scoreFieldsMap[def.SCORE_SUMMARIZE_TREND])
			resTrend = append(resTrend, temp)
		case def.SCORE_SUMMARIZE_CLIENT_TOP10:
			temp := setMapFields(raw, scoreFieldsMap[def.SCORE_SUMMARIZE_CLIENT_TOP10])
			resClientTop = append(resClientTop, temp)
		case def.SCORE_SUMMARIZE_CCID_TOP10:
			temp := setMapFields(raw, scoreFieldsMap[def.SCORE_SUMMARIZE_CCID_TOP10])
			resCCIDTop = append(resCCIDTop, temp)
		default:
			return nil, fmt.Errorf("[buildScoreSummarizeDetail] reportType[%s] is invalid.", reportType)
		}
	}

	details := make([]*model.ReportDetail, 0)

	// 趋势图
	detTrend := &model.ReportDetail{
		Code: def.SCORE_SUMMARIZE_TREND,
		Data: resTrend,
	}
	details = append(details, detTrend)

	// ClientTop10
	detCliTop := &model.ReportDetail{
		Code: def.SCORE_SUMMARIZE_CLIENT_TOP10,
		Data: resClientTop,
	}
	details = append(details, detCliTop)

	// CCIDTop10
	detCCIDTop := &model.ReportDetail{
		Code: def.SCORE_SUMMARIZE_CCID_TOP10,
		Data: resCCIDTop,
	}
	details = append(details, detCCIDTop)

	return &model.ReportDetailViewModel{
		Detail: details,
	}, nil
}
