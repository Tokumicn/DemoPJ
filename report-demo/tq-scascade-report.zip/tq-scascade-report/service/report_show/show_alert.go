package report_show

import (
	"fmt"
	"git-biz.qianxin-inc.cn/eps/skylar/apps/libs/tianqing.git/logs"
	"tq-scascade-report/pkg/def"
	"tq-scascade-report/pkg/model"
)

var alertFieldsMap = map[string][]string{
	def.ALERT_SUMMARIZE_TREND: {
		"result_id",
		"alert_count",
		"etime",
		"eyear",
	},
	def.ALERT_SUMMARIZE_Type_PER: {
		"result_id",
		"total",
		"type",
		"type_desc",
	},
	def.ALERT_SUMMARIZE_COUNTS_PER: {
		"result_id",
		"ccid",
		"ccid_name",
		"total",
	},
}

func buildAlertSummarizeDetail(rawData []map[string]interface{}) (*model.ReportDetailViewModel, error) {

	resTrend := make([]map[string]interface{}, 0)
	resTypePer := make([]map[string]interface{}, 0)
	resCountPer := make([]map[string]interface{}, 0)

	for i, raw := range rawData {

		var tempType int
		_, exist := rawData[i]["data_type"]
		if !exist {
			logs.Error("[buildAlertSummarizeDetail] get dataType failed.")
			continue
		} else {
			tempType = int(rawData[i]["data_type"].(int64))
		}

		reportType := def.GlobalDic[tempType]

		switch reportType {
		case def.ALERT_SUMMARIZE_TREND:
			temp := setMapFields(raw, alertFieldsMap[def.ALERT_SUMMARIZE_TREND])
			resTrend = append(resTrend, temp)
		case def.ALERT_SUMMARIZE_Type_PER:
			temp := setMapFields(raw, alertFieldsMap[def.ALERT_SUMMARIZE_Type_PER])
			resTypePer = append(resTypePer, temp)
		case def.ALERT_SUMMARIZE_COUNTS_PER:
			temp := setMapFields(raw, alertFieldsMap[def.ALERT_SUMMARIZE_COUNTS_PER])
			resCountPer = append(resCountPer, temp)
		default:
			return nil, fmt.Errorf("[buildAlertSummarizeDetail] reportType[%s] is invalid.", reportType)
		}
	}

	details := make([]*model.ReportDetail, 0)

	// 趋势图
	detTrend := &model.ReportDetail{
		Code: def.ALERT_SUMMARIZE_TREND,
		Data: resTrend,
	}
	details = append(details, detTrend)

	// Type Per  告警类型占比
	detTypePer := &model.ReportDetail{
		Code: def.ALERT_SUMMARIZE_Type_PER,
		Data: resTypePer,
	}
	details = append(details, detTypePer)

	// Count Per 告警次数占比
	detCountPer := &model.ReportDetail{
		Code: def.ALERT_SUMMARIZE_COUNTS_PER,
		Data: resCountPer,
	}
	details = append(details, detCountPer)

	return &model.ReportDetailViewModel{
		Detail: details,
	}, nil
}
