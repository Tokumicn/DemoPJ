package service

import (
	"encoding/json"
	"errors"
	"fmt"
	"git-biz.qianxin-inc.cn/eps/skylar/apps/libs/tianqing.git/logs"
	"git-biz.qianxin-inc.cn/eps/skylar/apps/libs/tianqing.git/utils"
	"time"
	"tq-scascade-report/pkg/dao"
	"tq-scascade-report/pkg/def"
	"tq-scascade-report/pkg/job"
	"tq-scascade-report/pkg/job_common"
	"tq-scascade-report/pkg/model"
	"tq-scascade-report/pkg/tools"
	"tq-scascade-report/service/cascade_config"
	"tq-scascade-report/service/report"
)

// 名字重复判断
func TaskNameIsExist(jobName string) (bool, error) {

	dto := dao.CronQueryTask{
		Name: jobName,
	}

	return dto.NameExist()
}

// 立即生成
func RunTaskNow(taskId int64) error {

	dto := dao.CronQueryTask{
		Id: taskId,
	}

	jobDTO, err := dto.Get()
	if err != nil {
		logs.Errorf("[RunTaskNow] get task by taskId: %d, err: %s.", taskId, err.Error())
		return fmt.Errorf("get task[id: %d] by id err.", taskId)
	}
	if jobDTO == nil {
		return errors.New("job is no exist.")
	}

	job.G_scheduler.PushJobEvent(&job_common.JobEvent{
		TaskName:  jobDTO.Name,
		JobName:   jobDTO.JobName,
		EventType: job.JOB_EVENT_START_RIGHT_NOW,
	})

	return nil
}

func checkCronType(cronType string) bool {
	_, ok := def.CronTypeDic[cronType]
	return ok
}

func checkTimeScale(scale string) bool {
	_, ok := def.TimeScaleDic[scale]
	return ok
}

// 新建
func CreateTask(req *model.ReportTaskRequest) error {

	exist, err := TaskNameIsExist(req.Name)
	if err != nil {
		return err
	}

	if exist {
		return fmt.Errorf("task name[%s] is exist.", req.Name)
	}

	if !checkCronType(req.CronType) {
		return fmt.Errorf("cronType 参数无效.")
	}

	// 汇总统计时 timescale不允许为空
	reportTypeArr := tools.SplitStrWithoutEmpty(req.ReportTypes, ",")
	if def.ReportTypesContain(reportTypeArr, def.SUMMARIZE) {
		if !checkTimeScale(req.TimeScale) {
			return fmt.Errorf("timeScale 参数无效.")
		}
	}

	jsonNodes, rawNode, err := cascade_config.GetClipCascadeCCIDTreeByTopCCId(req.TopCCId)
	if err != nil {
		return err
	}

	tArgs := &CCIdTreeArgs{
		TopCCId: req.TopCCId,
		Nodes:   jsonNodes,
		Raw:     rawNode,
	}

	execArr, err := buildReportExec(tArgs, req.Business, reportTypeArr, req.TimeScale, req.TimeRange, req.StartTime, req.EndTime)
	if err != nil {
		logs.Errorf("[CreateTask]-buildReportExec err: %v", err)
		return err
	}

	currentJobName := job_common.JobNameGenerator()

	jsonBytes, err := json.Marshal(jsonNodes)
	if err != nil {
		return err
	}

	rawBytes, err := json.Marshal(rawNode)
	if err != nil {
		return err
	}

	dto := dao.CronQueryTask{
		Name:        req.Name,
		JobName:     currentJobName,
		Business:    req.Business,
		TopCCId:     req.TopCCId,
		CCIDsTree:   string(jsonBytes),
		RawTree:     string(rawBytes),
		ReportTypes: req.ReportTypes,
		DataCover:   req.DataCover,
		CronType:    req.CronType,
		Day:         req.Day,
		Hours:       req.Hours,
		Minutes:     req.Minutes,
		TimeRange:   req.TimeRange,
		CreateTime:  &utils.JSONTime{T: time.Now()},
		UpdateTime:  &utils.JSONTime{T: time.Now()},
		TimeScale:   req.TimeScale,
	}

	if req.TimeRange == def.CustomRange {
		dto.StartTime = req.StartTime.T.Format(def.YYYYMMDDHHSSmm)
		dto.EndTime = req.EndTime.T.Format(def.YYYYMMDDHHSSmm)
	}

	err = dto.Create()
	if err != nil {
		logs.Errorf("[CreateTask] create task by taskName: %s, err: %s.", req.Name, err.Error())
		return errors.New("create task err.")
	}

	jobEvent := &job_common.JobEvent{
		Id:          dto.Id,
		TaskName:    dto.Name,
		JobName:     currentJobName,
		EventType:   job.JOB_EVENT_CREATE,
		CronType:    req.CronType,
		Day:         req.Day,
		Hours:       req.Hours,
		Minutes:     req.Minutes,
		ReportExecs: execArr,
		DataCover:   req.DataCover,
		TimeRange:   req.TimeRange,
	}
	if req.TimeRange == def.CustomRange {
		jobEvent.StartTime = req.StartTime.T.Format(def.YYYYMMDDHHSSmm)
		jobEvent.EndTime = req.EndTime.T.Format(def.YYYYMMDDHHSSmm)
	}

	job.G_scheduler.PushJobEvent(jobEvent)

	// 对于非定时任务再次调用执行
	if dto.Id > 0 && req.CronType == def.NOW {
		job.G_scheduler.PushJobEvent(&job_common.JobEvent{
			TaskName:  dto.Name,
			JobName:   currentJobName,
			EventType: job.JOB_EVENT_START_RIGHT_NOW,
		})
	}

	return nil
}

// 计算查询需要的时间范围
func calcQueryTimeRange(req *model.ReportTaskRequest) (*utils.JSONTime, *utils.JSONTime, error) {

	// 计算最近一次执行的时间,查询时间范围以此为锚点
	_, _, planStartTime, err := job_common.CalcCronPlanByType(&job_common.CronConfig{
		CronType: req.CronType,
		Day:      req.Day,
		Hours:    req.Hours,
		Minutes:  req.Minutes,
	})
	if err != nil {
		return nil, nil, err
	}

	var (
		startTime time.Time
		endTime   time.Time
	)

	switch req.TimeRange {
	case def.PastTenDayRange: // 最近十天
		startTime, endTime = tools.GetPastTenDayDateRange(planStartTime)
	case def.LastWeekRange: // 上周
		startTime, endTime = tools.GetLastWeekDateRange(planStartTime)
	case def.MonthRange: // 本月
		startTime, endTime = tools.GetThisMonthDateRange(planStartTime)
	case def.QuarterRange: // 本季度
		startTime, endTime = tools.GetThisQuarterDateRange(planStartTime)
	case def.YearRange: // 本年
		startTime, endTime = tools.GetThisYearDateRange(planStartTime)
	case def.CustomRange:
		if req.StartTime == nil || req.EndTime == nil || req.EndTime.T.Unix() < req.StartTime.T.Unix() {
			return nil, nil, fmt.Errorf("计算查询时间范围时出错.[req: %v]", req)
		}
		return req.StartTime, req.EndTime, nil
	}

	return &utils.JSONTime{T: startTime}, &utils.JSONTime{T: endTime}, nil
}

// 删除
func DeleteTask(taskId int64) error {

	jobDTO := dao.CronQueryTask{
		Id: taskId,
	}

	dto, err := jobDTO.Get()
	if err != nil {
		logs.Errorf("[DeleteTask] get task by taskId: %d, err: %s.", taskId, err.Error())
		return fmt.Errorf("delete task[id: %d] by id err.", taskId)
	}

	if dto == nil {
		return errors.New("task not exsit.")
	}

	// 删内存
	job.G_scheduler.PushJobEvent(&job_common.JobEvent{
		JobName:   dto.JobName,
		TaskName:  dto.Name,
		EventType: job.JOB_EVENT_DELETE,
	})

	// 删DB
	err = dto.Delete()
	if err != nil {
		return err
	}
	return nil
}

// 编辑
func EditTask(taskId int64, modifyTask *model.ReportTaskRequest) error {

	dto := dao.CronQueryTask{
		Id: taskId,
	}

	oldTask, err := dto.Get()
	if err != nil {
		logs.Errorf("[EditTask] get task by taskId: %d, err: %s.", taskId, err.Error())
		return fmt.Errorf("update task[id: %d] by id err.", taskId)
	}

	if oldTask == nil {
		return fmt.Errorf("task[%d] is no exist.", taskId)
	}

	reportTypes := tools.SplitStrWithoutEmpty(modifyTask.ReportTypes, ",")

	treeArgs, err := makeCCIdTreeArgsByTask(oldTask)
	if err != nil {
		return err
	}

	// 判断是有更新了TopCCId
	if modifyTask.TopCCId != oldTask.TopCCId {
		jsonNode, rawNode, err := cascade_config.GetClipCascadeCCIDTreeByTopCCId(modifyTask.TopCCId)
		if err != nil {
			return err
		}

		treeArgs.TopCCId = modifyTask.TopCCId
		treeArgs.Nodes = jsonNode
		treeArgs.Raw = rawNode
	}

	execArr, err := buildReportExec(
		treeArgs,
		modifyTask.Business,
		reportTypes,
		modifyTask.TimeScale,
		modifyTask.TimeRange,
		nil,
		nil)
	if err != nil {
		logs.Errorf("[LoadTaskForScheduler]--buildReportExec err: %v", err)
		return err
	}

	jsonTree, err := json.Marshal(treeArgs.Nodes)
	if err != nil {
		return err
	}

	rawTree, err := json.Marshal(treeArgs.Raw)
	if err != nil {
		return err
	}

	// 更新
	mTask := &dao.CronQueryTask{
		Id:          oldTask.Id,
		Name:        oldTask.Name,
		JobName:     oldTask.JobName,
		Business:    modifyTask.Business,
		ReportTypes: modifyTask.ReportTypes,
		TopCCId:     modifyTask.TopCCId,
		CCIDsTree:   string(jsonTree),
		RawTree:     string(rawTree),
		DataCover:   modifyTask.DataCover,
		CronType:    modifyTask.CronType,
		Day:         modifyTask.Day,
		Hours:       modifyTask.Hours,
		Minutes:     modifyTask.Minutes,
		CreateTime:  oldTask.CreateTime,
		UpdateTime:  &utils.JSONTime{T: time.Now()},
		TimeScale:   modifyTask.TimeScale,
		TimeRange:   modifyTask.TimeRange,
	}

	newTask, _, _, err := mTask.Update(taskId)
	if err != nil {
		return err
	}

	jobEvent := &job_common.JobEvent{
		Id:          newTask.Id,
		TaskName:    newTask.Name,
		JobName:     newTask.JobName,
		EventType:   job.JOB_EVENT_SAVE,
		CronType:    newTask.CronType,
		Day:         newTask.Day,
		Hours:       newTask.Hours,
		Minutes:     newTask.Minutes,
		ReportExecs: execArr,
		DataCover:   newTask.DataCover,
		TimeRange:   newTask.TimeRange,
	}

	// 仅自定义时间范围时需要传入参数
	if modifyTask.TimeRange == def.CustomRange {
		jobEvent.StartTime = modifyTask.StartTime.T.Format(def.YYYYMMDDHHSSmm)
		jobEvent.EndTime = modifyTask.EndTime.T.Format(def.YYYYMMDDHHSSmm)
	}

	job.G_scheduler.PushJobEvent(jobEvent)

	return nil
}

func GetTaskList(pageSize, current int64, taskName string, order int64, ordcond string) ([]*model.ReportTaskViewModel, int64, error) {
	dto := dao.CronQueryTask{}

	var filter map[string]interface{}
	if len(taskName) > 0 {
		filter = map[string]interface{}{
			"name": taskName,
		}
	}

	dtoList, total, err := dto.List(pageSize, current, filter, "", order, ordcond)
	if err != nil {
		return nil, 0, err
	}

	result := make([]*model.ReportTaskViewModel, 0)
	for _, d := range dtoList {
		result = append(result, dto2ViewTaskModel(d))
	}

	return result, total, nil
}

func GetTaskInfoById(taskId int64) (*model.ReportTaskRequest, error) {
	dto := dao.CronQueryTask{
		Id: taskId,
	}

	task, err := dto.Get()
	if err != nil {
		return nil, err
	}

	res := &model.ReportTaskRequest{
		Id:          task.Id,
		Name:        task.Name,
		TopCCId:     task.TopCCId,
		Business:    task.Business,
		DataCover:   task.DataCover,
		TimeScale:   task.TimeScale,
		TimeRange:   task.TimeRange,
		CronType:    task.CronType,
		Day:         task.Day,
		Hours:       task.Hours,
		Minutes:     task.Minutes,
		ReportTypes: task.ReportTypes,
	}

	if len(task.StartTime) > 0 {
		sTime, err := time.ParseInLocation(def.YYYYMMDDHHSSmm, task.StartTime, time.Local)
		if err == nil {
			res.StartTime = &utils.JSONTime{T: sTime}
		}
	}

	if len(task.EndTime) > 0 {
		eTime, err := time.ParseInLocation(def.YYYYMMDDHHSSmm, task.EndTime, time.Local)
		if err == nil {
			res.EndTime = &utils.JSONTime{T: eTime}
		}
	}

	return res, nil
}

// 将已存储的定时任务加载到内存
func LoadTaskForScheduler() error {
	dto := dao.CronQueryTask{}
	var tempPageSize int64 = 100
	var tempCurrent int64 = 1
	for {
		list, _, err := dto.List(tempPageSize, tempCurrent, nil, "", 1, "")
		if err != nil {
			return err
		}
		// load task for scheduler
		for _, task := range list {

			types := tools.SplitStrWithoutEmpty(task.ReportTypes, ",")

			treeArgs, err := makeCCIdTreeArgsByTask(task)
			if err != nil {
				logs.Errorf("LoadTaskForScheduler--makeCCIdTreeArgsByTask [task: %v] [err: %s]", task, err.Error())
				continue
			}

			var startTime, endTime *utils.JSONTime
			// 仅自定义时间范围时需要转换
			if task.TimeRange == def.CustomRange {
				if len(task.StartTime) >= 0 {
					sTime, _ := time.Parse(def.YYYYMMDDHHSSmm, task.StartTime)
					startTime = &utils.JSONTime{T: sTime}
				}
				if len(task.EndTime) >= 0 {
					eTime, _ := time.Parse(def.YYYYMMDDHHSSmm, task.EndTime)
					endTime = &utils.JSONTime{T: eTime}
				}
			}

			execArr, err := buildReportExec(
				treeArgs,
				task.Business,
				types,
				task.TimeScale,
				task.TimeRange,
				startTime,
				endTime)
			if err != nil {
				logs.Errorf("[LoadTaskForScheduler]--buildReportExec err: %v", err)
				continue
			}

			jobEvent := &job_common.JobEvent{
				Id:          task.Id,
				JobName:     task.JobName,
				TaskName:    task.Name,
				EventType:   job.JOB_EVENT_CREATE,
				CronType:    task.CronType,
				Day:         task.Day,
				Hours:       task.Hours,
				Minutes:     task.Minutes,
				ReportExecs: execArr,
				DataCover:   task.DataCover,
				TimeRange:   task.TimeRange,
				StartTime:   task.StartTime,
				EndTime:     task.EndTime,
			}

			job.G_scheduler.PushJobEvent(jobEvent)
		}
		if len(list) >= 100 {
			tempCurrent++
		} else {
			break
		}
	}

	return nil
}

type CCIdTreeArgs struct {
	TopCCId string
	Nodes   []*model.CCIDNode
	Raw     *cascade_config.RawCCIdNode
}

func makeCCIdTreeArgsByTask(task *dao.CronQueryTask) (*CCIdTreeArgs, error) {
	var nodes []*model.CCIDNode
	err := json.Unmarshal([]byte(task.CCIDsTree), &nodes)
	if err != nil {
		logs.Errorf("makeCCIdTreeArgsByTask--JsonTree--Unmarshal [task: %v] [err: %s]", task, err.Error())
		return nil, err
	}

	var rawNode *cascade_config.RawCCIdNode
	err = json.Unmarshal([]byte(task.RawTree), &rawNode)
	if err != nil {
		logs.Errorf("makeCCIdTreeArgsByTask--RawTree--Unmarshal [task: %v] [err: %s]", task, err.Error())
		return nil, err
	}

	return &CCIdTreeArgs{
		TopCCId: task.TopCCId,
		Nodes:   nodes,
		Raw:     rawNode,
	}, nil
}

func buildReportExec(treeArgs *CCIdTreeArgs, business string, reportTypeArr []string, timeScale, timeRange string, startTime, endTime *utils.JSONTime) ([]*report.ReportExec, error) {

	CCIds := cascade_config.ClapAllNodesArr(treeArgs.Nodes)
	rExecs := make([]*report.ReportExec, 0)
	for _, rType := range reportTypeArr {

		tmpTopCCIdMap := make(map[string][]string)
		if rType == def.SUMMARIZE {
			tmpTopCCIdMap = cascade_config.FindAllSubTreeMap(treeArgs.Raw)
		}

		qCond := report.QueryCondition{
			CCIDs:      CCIds,
			Business:   business,
			ReportType: rType,
			TimeScale:  timeScale,
			TimeRange:  timeRange,

			TopCCId:    treeArgs.TopCCId,
			TopCCIdMap: tmpTopCCIdMap,
		}

		if startTime != nil && endTime != nil {
			qCond.StartTime = startTime.T.Format(def.YYYYMMDDHHSSmm)
			qCond.EndTime = endTime.T.Format(def.YYYYMMDDHHSSmm)
		}

		subExec, err := qCond.BuildReportExec()
		if err != nil {
			return nil, err
		}

		rExecs = append(rExecs, subExec)
	}

	return rExecs, nil
}

func dto2ViewTaskModel(dto *dao.CronQueryTask) *model.ReportTaskViewModel {

	viewM := &model.ReportTaskViewModel{
		Id:             dto.Id,
		Name:           dto.Name,
		JobName:        dto.JobName,
		Business:       dto.Business,
		ReportTypes:    dto.ReportTypes,
		DataCover:      dto.DataCover,
		IsCyclicity:    buildIsCyclicity(dto.CronType),
		BuildCycleDesc: buildCycleDesc(dto),
		GeneratedTime:  buildGeneratedTime(dto),
		ExecStatus:     buildStatus(dto.JobName),
	}
	return viewM
}

func buildIsCyclicity(cronType string) bool {
	if cronType == def.NOW {
		return false
	}

	return true
}

// 构建生成周期字段
func buildCycleDesc(task *dao.CronQueryTask) string {

	cycleDesc := ""
	cronType := task.CronType
	switch cronType {
	case def.DAILY:
		cycleDesc = fmt.Sprintf("每天 %d时 %d分", task.Hours, task.Minutes)
	case def.WEEKLY:
		cycleDesc = fmt.Sprintf("每%s %d时 %d分", weekly_ItoA(task.Day), task.Hours, task.Minutes)
	case def.MONTHLY:
		cycleDesc = fmt.Sprintf("每月 %d号 %d时 %d分", task.Day, task.Hours, task.Minutes)
	case def.NOW:
		cycleDesc = "立即生成"
	default:
		cycleDesc = "计算中..."
	}
	return cycleDesc
}

func weekly_ItoA(num int) string {
	weekStr := ""
	switch num {
	case 1:
		weekStr = "周一"
	case 2:
		weekStr = "周二"
	case 3:
		weekStr = "周三"
	case 4:
		weekStr = "周四"
	case 5:
		weekStr = "周五"
	case 6:
		weekStr = "周六"
	case 0, 7:
		weekStr = "周日"
	default:
		weekStr = ""
	}
	return weekStr
}

func buildGeneratedTime(task *dao.CronQueryTask) string {

	// 立即执行的任务 无法从调度器获取任务信息
	if task.CronType == def.NOW {
		return "" //task.CreateTime.T.Format(def.YYYYMMDDHHSSmm)
	}

	planNextTime, err := job.G_scheduler.GetJobPlanNextTime(task.JobName)
	if err != nil {
		logs.Errorf("[buildGeneratedTime] task[%#v] is error[%s]. ", task, err.Error())
		return ""
	}

	return planNextTime
}

// 构建操作状态字段
func buildStatus(taskName string) bool {
	return job.G_scheduler.GetJobExecutingStatus(taskName)
}
