package service

import (
	"encoding/json"
	"errors"
	"git-biz.qianxin-inc.cn/eps/skylar/apps/libs/tianqing.git/logs"
	"tq-scascade-report/pkg/dao"
	"tq-scascade-report/pkg/def"
	"tq-scascade-report/pkg/model"
	"tq-scascade-report/service/report"
)

func GetReportResultList(pageSize, current int64, taskName string, order int64, ordcond string) ([]*model.ReportResultViewModel, int64, error) {

	var filter map[string]interface{}
	if len(taskName) > 0 {
		filter = map[string]interface{}{
			"name": taskName,
		}
	}

	resDto := dao.TaskResult{}
	queryResults, total, err := resDto.List(pageSize, current, filter, "", order, ordcond)
	if err != nil {
		return nil, 0, err
	}

	viewResults := make([]*model.ReportResultViewModel, 0)
	for _, res := range queryResults {
		resultViewModel, err := dto2ViewResultModel(res)
		if err != nil {
			logs.Errorf("dto2ViewResultModel err: %s", err.Error())
			continue
		}
		viewResults = append(viewResults, resultViewModel)
	}

	return viewResults, total, nil
}

func dto2ViewResultModel(dto *dao.TaskResult) (*model.ReportResultViewModel, error) {

	if dto == nil {
		return nil, errors.New("task result is nil.")
	}

	q := &report.QueryCondition{}
	err := json.Unmarshal([]byte(dto.Condition), q)
	if err != nil {
		logs.Errorf("[dto2ViewResultModel] json unmarshal error: ", err.Error())
		return nil, err
	}

	viewM := &model.ReportResultViewModel{
		Id:          dto.Id,
		TaskName:    dto.TaskName,
		Business:    q.Business,
		IsCyclicity: !(dto.CronExpr == "* * * * * * 2099"), // 非周期性任务触发时间为2099年
		FinishTime:  dto.FinishTime.T.Format(def.YYYYMMDDHHSSmm),
	}

	return viewM, nil
}
