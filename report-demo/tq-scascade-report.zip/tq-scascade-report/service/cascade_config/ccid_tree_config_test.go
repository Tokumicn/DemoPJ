package cascade_config

import (
	"git-biz.qianxin-inc.cn/eps/skylar/apps/libs/tianqing.git/logs"
	"testing"
	"tq-scascade-report/pkg/redis"
)

func init() {
	logs.Init(logs.Config{
		Writer: "console",
		Level:  "debug",
	})

	redis.InitFakeRedis()
}

var JSONTree = `{
    "ccid": "117367D7-2173-1F14-04BB-5C72D7657311",
    "name": "111",
    "children": [
        {
            "ccid": "22EAF3D5-A74F-A594-9FFA-BD9C8D963122",
            "name": "222",
            "children": [
                {
                    "ccid": "3347F3F2-00AA-983B-A70D-642B5BBCBF33",
                    "name": "333",
                    "children": []
                },
                 {
                    "ccid": "4447F3F2-00AA-983B-A70D-642B5BBCBF44",
                    "name": "444",
                    "children": []
                }
            ]
        },
        {
            "ccid": "55EAF3D5-A74F-A594-9FFA-BD9C8D963155",
            "name": "555",
            "children": []
        }
    ]
}`

func TestBuildTree(t *testing.T) {

	defer redis.FakeRedis.Close()

	redis.FakeRedis.HSet(CascadeCCIDTreeKey, CascadeCCIDTreeField, JSONTree)

	/*
			1--|
		       |-5-|
		       |
		       |-2-|
		           |-3
		           |-4
	*/

	list01, rawTree01, err := GetCascadeCCIDTree()
	if err != nil {
		t.Error(err)
	}
	printNodeList()
	if len(list01) != 5 {
		t.Fatal()
	}
	t.Log(rawTree01)

	list02, rawTree02, err := GetClipCascadeCCIDTreeByTopCCId("22EAF3D5-A74F-A594-9FFA-BD9C8D963122")
	if err != nil {
		t.Error(err)
	}
	printNodeList()
	if len(list02) != 3 {
		t.Fatal()
	}
	t.Log(rawTree02)

	list03, _, err := GetClipCascadeCCIDTreeByTopCCId("55EAF3D5-A74F-A594-9FFA-BD9C8D963155")
	if err != nil {
		t.Error(err)
	}
	printNodeList()
	if len(list03) != 1 {
		t.Fatal()
	}

	list04, rawTree04, err := GetClipCascadeCCIDTreeByTopCCId("4447F3F2-00AA-983B-A70D-642B5BBCBF44")
	if err != nil {
		t.Error(err)
	}
	printNodeList()
	if len(list04) != 1 {
		t.Fatal()
	}
	t.Log(rawTree04)

	list05, rawTree05, err := GetClipCascadeCCIDTreeByTopCCId("ERRRRRRRRRRRRRRRRRRRRROR")
	if err != nil {
		t.Error(err)
	}
	if list05 != nil {
		t.Fatal()
	}
	t.Log(rawTree05)

	list07, rawTree07, err := GetClipCascadeCCIDTreeByTopCCId("117367D7-2173-1F14-04BB-5C72D7657311")
	if err != nil {
		t.Error(err)
	}
	printNodeList()
	if len(list07) != 5 {
		t.Fatal()
	}
	t.Log(rawTree07)

	list09, rawTree09, err := GetClipCascadeCCIDTreeByTopCCId("")
	if err != nil {
		t.Error(err)
	}
	printNodeList()
	if len(list09) != len(list01) {
		t.Fatal()
	}
	t.Log(rawTree09)

}

func TestFindAllSubTreeMap(t *testing.T) {
	defer redis.FakeRedis.Close()

	redis.FakeRedis.HSet(CascadeCCIDTreeKey, CascadeCCIDTreeField, JSONTree)
	_, rawTree, err := GetClipCascadeCCIDTreeByTopCCId("22EAF3D5-A74F-A594-9FFA-BD9C8D963122")
	if err != nil {
		t.Error(err)
	}
	subTreeMap := FindAllSubTreeMap(rawTree)
	if len(subTreeMap) != 3 {
		t.Fatal()
	}

	_, rawTree02, err := GetClipCascadeCCIDTreeByTopCCId("117367D7-2173-1F14-04BB-5C72D7657311")
	if err != nil {
		t.Error(err)
	}
	subTreeMap02 := FindAllSubTreeMap(rawTree02)
	if len(subTreeMap02) != 5 {
		t.Fatal()
	}

	_, rawTree03, err := GetClipCascadeCCIDTreeByTopCCId("")
	if err != nil {
		t.Error(err)
	}
	subTreeMap03 := FindAllSubTreeMap(rawTree03)
	if len(subTreeMap03) != 5 {
		t.Fatal()
	}

	_, rawTree04, err := GetClipCascadeCCIDTreeByTopCCId("4447F3F2-00AA-983B-A70D-642B5BBCBF44")
	if err != nil {
		t.Error(err)
	}
	subTreeMap04 := FindAllSubTreeMap(rawTree04)
	if len(subTreeMap04) != 1 {
		t.Fatal()
	}

	_, rawTree05, err := GetClipCascadeCCIDTreeByTopCCId("55EAF3D5-A74F-A594-9FFA-BD9C8D963155")
	if err != nil {
		t.Error(err)
	}
	subTreeMap05 := FindAllSubTreeMap(rawTree05)
	if len(subTreeMap05) != 1 {
		t.Fatal()
	}

}
