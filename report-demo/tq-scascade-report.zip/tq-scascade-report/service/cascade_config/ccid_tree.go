package cascade_config

import (
	"encoding/json"
	"fmt"
	"tq-scascade-report/pkg/model"
	"tq-scascade-report/pkg/redis"
)

var (
	list      []*model.CCIDNode // View Data
	id        int64
	pid       int64
	clipCCIDs []string

	// 以头部节点CCId为Key   该节点为头的子树所有CCId列表为Value
	subTreeMap map[string][]string
)

// 获取CCID树原始数据
func getCascadeCCIDTreeRawData() (*RawCCIdNode, error) {

	data, err := redis.RedisDB.HGet(CascadeCCIDTreeKey, CascadeCCIDTreeField).Bytes()
	if err != nil {
		return nil, err
	}

	// 从天擎PG获取多级级联配置信息
	rawNodes := &RawCCIdNode{}
	err = json.Unmarshal(data, &rawNodes)
	if err != nil {
		return nil, err
	}

	return rawNodes, nil
}

// 将数据构建为数组
func buildArray(node *RawCCIdNode, filter bool) {
	tempNode := &model.CCIDNode{
		Id:   node.Id,
		PId:  node.PId,
		Name: node.Name,
		CCID: node.CCID,
	}

	if filter {
		if node.Show {
			list = append(list, tempNode)
		}
	} else {
		list = append(list, tempNode)
	}

	if len(node.Children) <= 0 {
		return
	}

	for _, n := range node.Children {
		buildArray(n, filter)
	}
}

// 填充id与pid
func fillInNodes(pid int64, node *RawCCIdNode) {
	node.PId = pid
	node.Id = id
	pid = id
	id++

	if len(node.Children) <= 0 {
		return
	}

	for _, n := range node.Children {
		fillInNodes(pid, n)
	}
}

// 根据CCID标记节点是否展示
func fillInWithMarkOld(pid int64, node *RawCCIdNode, show bool) bool {
	// 填充Id与Pid
	node.PId = pid
	node.Id = id
	pid = id
	id++

	// 节点裁剪
	sonShow := false
	fatherShow := false
	if isContain(node.CCID) || show {
		node.Show = true
		sonShow = true
		fatherShow = true
	}

	if len(node.Children) <= 0 {
		return fatherShow
	}

	// 子节点裁剪与Id、PId填充
	for _, n := range node.Children {
		currentShow := fillInWithMarkOld(pid, n, sonShow)
		if currentShow {
			node.Show = true
			fatherShow = true
		}
	}

	return fatherShow
}

var findNode *RawCCIdNode

func findSubTreeByTopCCId(topCCId string, node *RawCCIdNode) {

	if node.CCID == topCCId {
		findNode = node
		return
	}

	for _, child := range node.Children {
		findSubTreeByTopCCId(topCCId, child)
	}
}

// 当前ccid是否包含在查询范围内
func isContain(ccid string) bool {
	for _, val := range clipCCIDs {
		if val == ccid {
			return true
		}
	}

	return false
}

func printNodeList() {
	fmt.Println("=======================")
	for _, node := range list {
		fmt.Printf("id:%d, ccid:%s, pid:%d \n", node.Id, node.CCID, node.PId)
	}
	fmt.Println("============end===========")
	fmt.Println()
}

// 遍历整棵树,每到一个节点记录一次
func eachAndRecordTree(node *RawCCIdNode) {
	if node == nil {
		return
	}

	recordTreeTopCCIdArr(node)

	for _, child := range node.Children {
		eachAndRecordTree(child)
	}
}

// 将树拍平为数组  并返回头节点CCId
func recordTreeTopCCIdArr(node *RawCCIdNode) {
	if node == nil {
		return
	}

	topCCId := node.CCID

	// 树拍平
	topCCIdArr := clapTree2Arr(node)
	// 记录
	subTreeMap[topCCId] = topCCIdArr
}

func clapTree2Arr(node *RawCCIdNode) []string {

	if node == nil {
		return nil
	}
	// 记录当前节点
	tempCCIdArr := []string{node.CCID}

	for _, subNode := range node.Children {
		tempCCIdArr = append(tempCCIdArr, clapTree2Arr(subNode)...)
	}

	return tempCCIdArr
}
