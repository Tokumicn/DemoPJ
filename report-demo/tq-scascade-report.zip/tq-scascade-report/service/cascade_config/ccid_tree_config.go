package cascade_config

import (
	"encoding/json"
	"fmt"
	"tq-scascade-report/pkg/dao"
	"tq-scascade-report/pkg/model"
)

const (
	CascadeCCIDTreeKey   = "svr_system_config"
	CascadeCCIDTreeField = "mutilevel_relationship"
)

type RawCCIdNode struct {
	Name     string         `json:"name"`
	CCID     string         `json:"ccid"`
	Children []*RawCCIdNode `json:"children"`

	Id   int64
	PId  int64
	Show bool
}

// 获取本级控制中心树信息
func GetCascadeCCIDTree() ([]*model.CCIDNode, *RawCCIdNode, error) {

	id = 1
	pid = -1
	list = make([]*model.CCIDNode, 0)

	// 获取控制节点配置信息
	rawData, err := getCascadeCCIDTreeRawData()
	if err != nil {
		return nil, nil, err
	}

	// 将树拆解成数组并生成id与pid
	fillInNodes(pid, rawData)

	// 构建为数组
	buildArray(rawData, false)

	return list, rawData, nil
}

// 根据头部CCId裁剪树
func GetClipCascadeCCIDTreeByTopCCId(topCCId string) ([]*model.CCIDNode, *RawCCIdNode, error) {

	if len(topCCId) <= 0 {
		return GetCascadeCCIDTree() // 使用当前最新控制中心树
	}

	id = 1
	pid = -1
	clipCCIDs = []string{topCCId}
	list = make([]*model.CCIDNode, 0)
	findNode = nil // 初始化

	// 获取控制节点配置信息
	rawNodes, err := getCascadeCCIDTreeRawData()
	if err != nil {
		return nil, nil, err
	}

	// 填充id与pid并根据传入的ccid填充标记
	findSubTreeByTopCCId(topCCId, rawNodes)

	if findNode == nil {
		return nil, nil, fmt.Errorf("topCCId未找到.")
	}

	topTree := findNode
	// 填充
	fillInNodes(-1, topTree)

	// 构建结果值
	buildArray(topTree, false)

	return list, topTree, nil
}

// 获取定时报表创建时，控制中心节点树快照
func GetCronReportCCIDTreeByResultId(resultId int64) ([]*model.CCIDNode, *RawCCIdNode, error) {

	id = 1
	pid = -1
	list = make([]*model.CCIDNode, 0)

	dto := dao.TaskResult{
		Id: resultId,
	}

	taskResult, err := dto.GetById()
	if err != nil {
		return nil, nil, err
	}

	rawData := &RawCCIdNode{}
	err = json.Unmarshal([]byte(taskResult.RawTree), &rawData)
	if err != nil {
		return nil, nil, err
	}

	// 将树拆解成数组并生成id与pid
	fillInNodes(pid, rawData)

	// 构建为数组
	buildArray(rawData, false)

	return list, rawData, nil
}

// 根据ResultId获取并根据TopId修剪控制中心树
func GetResultCCIdListByTop(resultId int64, topCCId string) ([]string, error) {

	id = 1
	pid = -1
	clipCCIDs = []string{topCCId}
	list = make([]*model.CCIDNode, 0)
	findNode = nil // 初始化

	// 获取控制节点配置信息
	_, rawNodes, err := GetCronReportCCIDTreeByResultId(resultId)
	if err != nil {
		return nil, err
	}

	findAllSubTreeMap := FindAllSubTreeMap(rawNodes)

	if subCCIdArr, ok := findAllSubTreeMap[topCCId]; ok {
		return subCCIdArr, nil
	}

	return nil, fmt.Errorf("未找到对应的子树 [topCCId: %s]", topCCId)
}

// 获取最新并根据TopId修剪控制中心树
func GetLogDetailCCIdListByTop(topCCId string) ([]string, error) {

	_, rawNodes, err := GetCascadeCCIDTree()
	if err != nil {
		return nil, err
	}
	findAllSubTreeMap := FindAllSubTreeMap(rawNodes)

	if subCCIdArr, ok := findAllSubTreeMap[topCCId]; ok {
		return subCCIdArr, nil
	}

	return nil, fmt.Errorf("未找到对应的子树 [topCCId: %s]", topCCId)
}

// 将树对象拍平为数组，方便作为查询参数
func ClapAllNodesArr(nodes []*model.CCIDNode) []string {
	ccIdArr := make([]string, 0)

	for _, n := range nodes {
		ccIdArr = append(ccIdArr, n.CCID)
	}
	return ccIdArr
}

// 寻找所有子树:以topCCId为顶节点的子树  topCCID : [子节点CCId列表]
func FindAllSubTreeMap(node *RawCCIdNode) map[string][]string {
	subTreeMap = make(map[string][]string)
	eachAndRecordTree(node)
	return subTreeMap
}
