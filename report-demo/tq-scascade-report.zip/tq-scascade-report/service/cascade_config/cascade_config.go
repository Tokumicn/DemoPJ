// 级联配置信息
package cascade_config

import (
	"encoding/json"
	"tq-scascade-report/pkg/redis"
)

const (
	CascadeConfigKey   = "svr_system_config"
	CascadeConfigField = "scascade_upload_config"
)

type CascadeConfig struct {
	Enabled        int    `json:"enabled"`    // 数据级联配置总开关，0关闭1开启
	NodeLevel      int    `json:"level"`      // 级联节点级别 识当前是最上级，还是最下级，还是中间级。  最下级1  中间级 2  最上级 3   (单选)    默认是最下级。
	LogDBHost      string `json:"logdb_host"` // 本级clickhouse日志存储服务地址
	LogDBPort      int    `json:"logdb_port"` // 本级clickhouse日志存储服务端口
	LogDBUser      string `json:"logdb_user"`
	LogDBPassword  string `json:"logdb_pass"`
	PGHost         string `json:"pg_host"` // 本级资产PG存储服务地址
	PGPort         int    `json:"pg_port"` // 本级资产PG存储服务端口
	PGUser         string `json:"pg_user"`
	PGPassword     string `json:"pg_pass"`
	LogAutoClear   int    `json:"log_autoclear"`   // 自动删除N天前上传的日志 1
	LogExpiredDays int    `json:"log_expireddays"` // 保留天数配置 180
}

func GetCascadeConfig() (*CascadeConfig, error) {

	data, err := redis.RedisDB.HGet(CascadeConfigKey, CascadeConfigField).Bytes()
	if err != nil {
		return nil, err
	}

	// 从天擎PG获取多级级联配置信息
	conf := &CascadeConfig{}
	err = json.Unmarshal(data, conf)
	if err != nil {
		return nil, err
	}

	return conf, nil
}
