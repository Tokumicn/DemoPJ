package setup

import (
	"bytes"
	"flag"
	"git-biz.qianxin-inc.cn/eps/skylar/apps/libs/tianqing.git/net/http_cli"
	"github.com/arl/statsviz"
	"io/ioutil"
	"log"
	"net/http"
	"os"
	"tq-scascade-report/handler"
	"tq-scascade-report/pkg/clickhouse"
	"tq-scascade-report/pkg/config"
	"tq-scascade-report/pkg/executor"
	"tq-scascade-report/pkg/job"
	"tq-scascade-report/pkg/postgres"
	"tq-scascade-report/pkg/tools"
	"tq-scascade-report/service"
	"tq-scascade-report/service/local_cron_job"
	"tq-scascade-report/service/log_details/custom_column"

	"git-biz.qianxin-inc.cn/eps/skylar/apps/libs/tianqing.git/logs"
	"github.com/gin-gonic/gin"
)

func ServerInit() {

	selfConf := config.Cfg()

	// scheduler Init
	job.InitScheduler()
	executor.InitExecutor()

	// click house Init
	clickhouse.ClickHouseInit(selfConf.CHConf)
	// 多级级联PG初始化
	postgres.InitPostgresDB(config.Cfg().PGConf)

	err := custom_column.InitDefaultCustomConfigMapFromJson()
	if err != nil {
		panic(err)
	}

	// 启动程序时从DB将定时任务加载到内存
	err = service.LoadTaskForScheduler()
	if err != nil {
		panic(err)
	}

	if selfConf.ServerConf.Debug {
		go func() {
			statsviz.RegisterDefault()
			log.Println(http.ListenAndServe(":6066", nil))
		}()
	}

	http_cli.InitHttpClient()

	// 定时清理历史数据
	go local_cron_job.LocalCronJobRun()

	// gin Init
	r := gin.Default()
	r.Use(gin.Recovery())
	handlerSetup(r)
	go r.Run(selfConf.ServerConf.Address)
}

func handlerSetup(r gin.IRouter) {
	var rs = r.Group("reportJob/v1")
	rs.GET("/ping", func(context *gin.Context) {
		context.Writer.Write([]byte("pong"))
	})

	//rs.GET("/internal/version.json", func(context *gin.Context) {
	//	var version = config.Version()
	//	context.JSON(http.StatusOK, &version)
	//})

	var app = rs.Group("/")
	app.Use(writeOperateLog)

	handler.HandlerInit(app)
}

func writeOperateLog(c *gin.Context) {
	if c.Request.Method == "POST" || c.Request.Method == "PUT" || c.Request.Method == "DELETE" {
		var s string
		b, err := ioutil.ReadAll(c.Request.Body)
		if err != nil {
			s = ""
		}
		c.Request.Body = ioutil.NopCloser(bytes.NewBuffer(b))
		s = string(b[:len(b)])

		logs.Info(
			"[Operate] User: ", c.Request.Header["X-User-Id"],
			" ", c.Request.Header["X-Platform"],
			" ", c.Request.Method,
			" ", c.Request.URL,
			" ", s,
		)
	}
}

const LogFileName = "tq-scascade-report.log"

func logsInit() {

	// 命令行参数汇总获取log_dir地址
	flag.VisitAll(func(f *flag.Flag) {
		if f.Name == "log_dir" {
			config.Cfg().LogConfig.FileConfig.Path = f.Value.String()
			log.Printf("日志目录: %s.", f.Value.String())
		}
	})

	// 创建日志文件夹
	fileFullPath := ""
	if len(config.Cfg().LogConfig.FileConfig.Path) > 0 {
		fileFullPath = config.Cfg().LogConfig.FileConfig.Path

	} else {
		pwdPath, _ := os.Getwd()
		fileFullPath = pwdPath
	}

	err := tools.Mkdir(fileFullPath)
	if err != nil {
		log.Printf("创建日志文件夹失败.[path: %s] [err: %v] \n", config.Cfg().LogConfig.FileConfig.Path, err)
	}

	config.Cfg().LogConfig.FileConfig.Path += LogFileName
	// 日志初始化
	logs.Init(config.Cfg().LogConfig)
}
