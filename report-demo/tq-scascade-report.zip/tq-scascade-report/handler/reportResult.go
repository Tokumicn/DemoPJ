package handler

import (
	"git-biz.qianxin-inc.cn/eps/skylar/apps/libs/tianqing.git/qgin"
	"github.com/gin-gonic/gin"
	"net/http"
	"reflect"
	"strconv"
	"tq-scascade-report/pkg/def"
	"tq-scascade-report/pkg/model"
	"tq-scascade-report/service"
	"tq-scascade-report/service/exporter"
	"tq-scascade-report/service/report_show"
)

func ReportResultInit(r gin.IRouter) {

	rg := r.Group("/reportResult")

	rg.POST("/list",
		qgin.OGRequestBodyObject(reflect.TypeOf(model.ListPagingRequest{}), "json"),
		listReportResult)

	rg.POST("/detail",
		qgin.OGRequestBodyObject(reflect.TypeOf(model.ResultQueryRequest{}), "json"),
		detailReportResult)

	//rg.POST("/summarizeDetail",
	//	qgin.OGRequestBodyObject(reflect.TypeOf(model.SummarizeResultQueryRequest{}), "json"),
	//	summarizeDetailReportResult)

	rg.POST("/delete",
		qgin.OGRequestBodyObject(reflect.TypeOf(model.ResultIdRequest{}), "json"),
		deleteReportResult)

	rg.POST("/detailCCIdTree",
		qgin.OGRequestBodyObject(reflect.TypeOf(model.ResultIdRequest{}), "json"),
		detailResultCCIdTree)

	// 导出
	rg.POST("/export",
		qgin.OGRequestBodyObject(reflect.TypeOf(model.ResultExportQueryRequest{}), "json"),
		exportReportResult)
}

func listReportResult(c *gin.Context) {

	reqData := c.MustGet("requestBody").(*model.ListPagingRequest)
	taskName := reqData.TaskName
	pageSize := reqData.PageSize
	current := reqData.Current
	order := reqData.Order
	ordcond := reqData.OrderCondition

	// 默认值
	if pageSize <= 0 {
		pageSize = 20
	}

	if current <= 0 {
		current = 1
	}

	if order <= 0 {
		order = 1
	}

	// 排序、分页、过滤
	lists, cnt, err := service.GetReportResultList(pageSize, current, taskName, order, ordcond)
	if err != nil {
		c.JSON(http.StatusOK, &qgin.Response{Code: def.Err_GetErr, Msg: err.Error()})
		return
	}

	result := struct {
		Detail []*model.ReportResultViewModel `json:"detail"`
		Total  int64                          `json:"total"`
	}{
		Detail: lists,
		Total:  cnt,
	}

	c.Header("X-total-count", strconv.Itoa(int(cnt)))
	c.JSON(http.StatusOK, &qgin.Response{Data: result})

}

// 获取报表详情
func detailReportResult(c *gin.Context) {

	reqData := c.MustGet("requestBody").(*model.ResultQueryRequest)
	resultId := reqData.ResultId

	if resultId <= 0 {
		c.JSON(http.StatusOK, qgin.NewError(def.Err_InvalidParameter, "resultId 参数无效"))
		return
	}
	if len(reqData.ReportType) <= 0 {
		c.JSON(http.StatusOK, qgin.NewError(def.Err_InvalidParameter, "reportType 参数无效"))
		return
	}
	if len(reqData.TopCCId) <= 0 {
		c.JSON(http.StatusOK, qgin.NewError(def.Err_InvalidParameter, "tpCCId 参数无效"))
		return
	}

	details, err := report_show.GetReportDetailById(reqData)
	if err != nil {
		c.JSON(http.StatusOK, &qgin.Response{Code: def.Err_GetErr, Msg: err.Error()})
		return
	}

	c.JSON(http.StatusOK, &qgin.Response{Data: details})
	return
}

func deleteReportResult(c *gin.Context) {

	reqData := c.MustGet("requestBody").(*model.ResultIdRequest)
	resultId := reqData.ResultId

	if resultId <= 0 {
		c.JSON(http.StatusOK, qgin.NewError(def.Err_InvalidParameter, "resultId 参数无效"))
		return
	}

	err := report_show.DeleteTaskResultWithDetail(resultId)
	if err != nil {
		c.JSON(http.StatusOK, &qgin.Response{Code: def.Err_DeleteErr, Msg: err.Error()})
		return
	}

	c.JSON(http.StatusOK, &qgin.Response{Data: "success"})
	return
}

func detailResultCCIdTree(c *gin.Context) {
	reqData := c.MustGet("requestBody").(*model.ResultIdRequest)
	resultId := reqData.ResultId

	if resultId <= 0 {
		c.JSON(http.StatusOK, qgin.NewError(def.Err_InvalidParameter, "resultId 参数无效"))
		return
	}

	ccidTree, err := report_show.GetReportDetailCCIdTree(reqData)
	if err != nil {
		c.JSON(http.StatusOK, &qgin.Response{Code: def.Err_GetErr, Msg: err.Error()})
		return
	}

	c.JSON(http.StatusOK, &qgin.Response{Data: ccidTree})
	return
}

func exportReportResult(c *gin.Context) {
	reqData := c.MustGet("requestBody").(*model.ResultExportQueryRequest)
	resultId := reqData.ResultId

	if resultId <= 0 {
		c.JSON(http.StatusOK, qgin.NewError(def.Err_InvalidParameter, "resultId 参数无效"))
		return
	}
	if len(reqData.TopCCId) <= 0 {
		c.JSON(http.StatusOK, qgin.NewError(def.Err_InvalidParameter, "tpCCId 参数无效"))
		return
	}
	if len(reqData.ReportTypes) <= 0 {
		c.JSON(http.StatusOK, qgin.NewError(def.Err_InvalidParameter, "reportTypes 参数无效"))
		return
	}
	if reqData.Uid <= 0 {
		c.JSON(http.StatusOK, qgin.NewError(def.Err_InvalidParameter, "Uid 参数无效"))
		return
	}

	err := exporter.ExportAndNotification(reqData)
	if err != nil {
		c.JSON(http.StatusOK, &qgin.Response{Code: def.Err_ExportErr, Msg: err.Error()})
		return
	}

	c.JSON(http.StatusOK, &qgin.Response{Data: "success"})
	return
}
