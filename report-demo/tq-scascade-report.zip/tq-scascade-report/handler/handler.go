package handler

import "github.com/gin-gonic/gin"

func HandlerInit(r gin.IRouter) {
	CronReportInit(r)
	ReportResultInit(r)
	LogDetailsInit(r)
	ClearUselessDataInit(r)
}
