package handler

import (
	"net/http"
	"reflect"
	"strconv"
	"tq-scascade-report/service"

	"tq-scascade-report/pkg/def"
	"tq-scascade-report/pkg/model"

	"git-biz.qianxin-inc.cn/eps/skylar/apps/libs/tianqing.git/qgin"
	"github.com/gin-gonic/gin"
)

func CronReportInit(r gin.IRouter) {
	rg := r.Group("/cronReport")

	rg.POST("/detail",
		qgin.OGRequestBodyObject(reflect.TypeOf(model.TaskIdRequest{}), "json"),
		getDetail)

	rg.POST("/list",
		qgin.OGRequestBodyObject(reflect.TypeOf(model.ListPagingRequest{}), "json"),
		listCronReport)

	rg.POST("/nameExist",
		qgin.OGRequestBodyObject(reflect.TypeOf(model.TaskNameRequest{}), "json"),
		nameExist)

	rg.POST("/delete",
		qgin.OGRequestBodyObject(reflect.TypeOf(model.TaskIdRequest{}), "json"),
		deleteCronReport)

	rg.POST("/runNow",
		qgin.OGRequestBodyObject(reflect.TypeOf(model.TaskIdRequest{}), "json"),
		runNow)

	rg.POST("/create",
		qgin.OGRequestBodyObject(reflect.TypeOf(model.ReportTaskRequest{}), "json"),
		createCronReport)

	rg.POST("/edit",
		qgin.OGRequestBodyObject(reflect.TypeOf(model.ReportTaskRequest{}), "json"),
		editCronReport)
}

func getDetail(c *gin.Context) {

	reqData := c.MustGet("requestBody").(*model.TaskIdRequest)
	taskId := reqData.TaskId
	if taskId <= 0 {
		c.JSON(http.StatusOK, qgin.NewError(def.Err_InvalidParameter, "taskId 参数无效"))
		return
	}

	taskInfo, err := service.GetTaskInfoById(taskId)
	if err != nil {
		c.JSON(http.StatusOK, &qgin.Response{Code: def.Err_GetErr, Msg: err.Error()})
		return
	}

	c.JSON(http.StatusOK, &qgin.Response{Data: taskInfo})
	return
}

func listCronReport(c *gin.Context) {

	reqData := c.MustGet("requestBody").(*model.ListPagingRequest)
	taskName := reqData.TaskName
	pageSize := reqData.PageSize
	current := reqData.Current
	order := reqData.Order
	ordcond := reqData.OrderCondition

	// 默认值
	if pageSize <= 0 {
		pageSize = 20
	}

	if current <= 0 {
		current = 1
	}

	if order <= 0 {
		order = 1
	}

	// 排序、分页、过滤
	lists, cnt, err := service.GetTaskList(pageSize, current, taskName, order, ordcond)
	if err != nil {
		c.JSON(http.StatusOK, &qgin.Response{Code: def.Err_GetErr, Msg: err.Error()})
		return
	}

	result := struct {
		Detail []*model.ReportTaskViewModel `json:"detail"`
		Total  int64                        `json:"total"`
	}{
		Detail: lists,
		Total:  cnt,
	}

	c.Header("X-total-count", strconv.Itoa(int(cnt)))
	c.JSON(http.StatusOK, &qgin.Response{Data: result})
}

func nameExist(c *gin.Context) {

	reqData := c.MustGet("requestBody").(*model.TaskNameRequest)
	name := reqData.TaskName
	if len(name) <= 0 {
		c.JSON(http.StatusOK, qgin.NewError(def.Err_InvalidParameter, "name 参数无效"))
		return
	}

	exist, err := service.TaskNameIsExist(name)
	if err != nil {
		c.JSON(http.StatusOK, &qgin.Response{Code: def.Err_GetErr, Msg: err.Error()})
		return
	}

	c.JSON(http.StatusOK, &qgin.Response{Data: exist})
	return
}

func deleteCronReport(c *gin.Context) {

	reqData := c.MustGet("requestBody").(*model.TaskIdRequest)
	taskId := reqData.TaskId
	if taskId <= 0 {
		c.JSON(http.StatusOK, qgin.NewError(def.Err_InvalidParameter, "taskId 参数无效"))
		return
	}

	err := service.DeleteTask(taskId)
	if err != nil {
		c.JSON(http.StatusOK, &qgin.Response{Code: def.Err_DeleteErr, Msg: err.Error()})
		return
	}

	c.JSON(http.StatusOK, &qgin.Response{Data: "success"})
	return
}

func runNow(c *gin.Context) {

	reqData := c.MustGet("requestBody").(*model.TaskIdRequest)
	taskId := reqData.TaskId
	if taskId <= 0 {
		c.JSON(http.StatusOK, qgin.NewError(def.Err_InvalidParameter, "taskId 参数无效"))
		return
	}

	err := service.RunTaskNow(taskId)
	if err != nil {
		c.JSON(http.StatusOK, &qgin.Response{Code: def.Err_GetErr, Msg: err.Error()})
		return
	}

	c.JSON(http.StatusOK, &qgin.Response{Data: "success"})
	return
}

func createCronReport(c *gin.Context) {

	reqData := c.MustGet("requestBody").(*model.ReportTaskRequest)
	if len(reqData.Name) <= 0 {
		c.JSON(http.StatusOK, qgin.NewError(def.Err_InvalidParameter, "name 参数无效"))
		return
	}
	if len(reqData.Business) <= 0 {
		c.JSON(http.StatusOK, qgin.NewError(def.Err_InvalidParameter, "business 参数无效"))
		return
	}
	if len(reqData.ReportTypes) <= 0 {
		c.JSON(http.StatusOK, qgin.NewError(def.Err_InvalidParameter, "reportTypes 参数无效"))
		return
	}
	if len(reqData.TopCCId) <= 0 {
		c.JSON(http.StatusOK, qgin.NewError(def.Err_InvalidParameter, "topCCId 参数无效"))
		return
	}
	if len(reqData.CronType) <= 0 {
		c.JSON(http.StatusOK, qgin.NewError(def.Err_InvalidParameter, "cronType 参数无效"))
		return
	}
	if len(reqData.TimeRange) <= 0 {
		c.JSON(http.StatusOK, qgin.NewError(def.Err_InvalidParameter, "timeRange 参数无效"))
		return
	}

	// 指定时间范围
	if reqData.TimeRange == def.CustomRange {
		if reqData.StartTime == nil || reqData.StartTime.T.Unix() <= 0 {
			c.JSON(http.StatusOK, qgin.NewError(def.Err_InvalidParameter, "startTime 参数无效"))
			return
		}
		if reqData.EndTime == nil || reqData.EndTime.T.Unix() <= 0 {
			c.JSON(http.StatusOK, qgin.NewError(def.Err_InvalidParameter, "endTime 参数无效"))
			return
		}
		if reqData.EndTime.T.Unix() < reqData.StartTime.T.Unix() {
			c.JSON(http.StatusOK, qgin.NewError(def.Err_InvalidParameter, "自定义时间范围 参数无效"))
			return
		}
	}

	err := service.CreateTask(reqData)
	if err != nil {
		c.JSON(http.StatusOK, &qgin.Response{Code: def.Err_CreateErr, Msg: err.Error()})
		return
	}

	c.JSON(http.StatusOK, &qgin.Response{Data: "success"})
	return
}

func editCronReport(c *gin.Context) {

	reqData := c.MustGet("requestBody").(*model.ReportTaskRequest)
	if reqData.Id <= 0 {
		c.JSON(http.StatusOK, qgin.NewError(def.Err_InvalidParameter, "taskId 参数无效"))
		return
	}

	err := service.EditTask(reqData.Id, reqData)
	if err != nil {
		c.JSON(http.StatusOK, &qgin.Response{Code: def.Err_CreateErr, Msg: err.Error()})
		return
	}

	c.JSON(http.StatusOK, &qgin.Response{Data: "success"})
	return
}
