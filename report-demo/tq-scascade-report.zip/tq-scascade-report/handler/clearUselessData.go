package handler

import (
	"git-biz.qianxin-inc.cn/eps/skylar/apps/libs/tianqing.git/qgin"
	"github.com/gin-gonic/gin"
	"net/http"
	"tq-scascade-report/service"
)

// 清理过期数据接口
func ClearUselessDataInit(r gin.IRouter) {
	r.GET("/internal/clearUselessData",
		clearUselessData)
}

func clearUselessData(c *gin.Context) {

	service.ClearUselessData()

	c.JSON(http.StatusOK, &qgin.Response{Data: "success"})
	return
}
