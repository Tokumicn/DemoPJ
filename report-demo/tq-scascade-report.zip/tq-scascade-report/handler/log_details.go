package handler

import (
	"git-biz.qianxin-inc.cn/eps/skylar/apps/libs/tianqing.git/logs"
	"git-biz.qianxin-inc.cn/eps/skylar/apps/libs/tianqing.git/qgin"
	"github.com/gin-gonic/gin"
	"net/http"
	"reflect"
	"tq-scascade-report/pkg/def"
	"tq-scascade-report/pkg/model"
	"tq-scascade-report/service/cascade_config"
	"tq-scascade-report/service/exporter"
	"tq-scascade-report/service/log_details"
	"tq-scascade-report/service/log_details/custom_column"
)

func LogDetailsInit(r gin.IRouter) {
	rg := r.Group("/logDetail")

	// 自定义列信息获取
	rg.POST("/getCustomColumns",
		qgin.OGRequestBodyObject(reflect.TypeOf(model.GetCustomColumnRequest{}), "json"),
		getCustomColumns)

	// 更新自定义列
	rg.POST("/updateCustomColumns",
		qgin.OGRequestBodyObject(reflect.TypeOf(model.UpdateCustomColumnRequest{}), "json"),
		updateCustomColumns)

	// 高级筛选模板列表获取
	rg.POST("/getFilterTlpList",
		qgin.OGRequestBodyObject(reflect.TypeOf(model.GetConditionTemplateRequest{}), "json"),
		getFilterTemplateList)

	// 高级筛选模板更新
	rg.POST("/saveFilterTlp",
		qgin.OGRequestBodyObject(reflect.TypeOf(model.UpdateConditionTemplateRequest{}), "json"),
		updateFilterTemplate)

	// 高级筛选模板删除
	rg.POST("/deleteFilterTlp",
		qgin.OGRequestBodyObject(reflect.TypeOf(model.DeleteConditionTemplateRequest{}), "json"),
		deleteFilterTemplateById)

	// 高级筛选字段信息详情
	rg.POST("/getFilterFieldsConfig",
		qgin.OGRequestBodyObject(reflect.TypeOf(model.GetFilterFieldsConfigRequest{}), "json"),
		getFilterFieldsConfig)

	// 查询接口
	rg.POST("/queryByFilter",
		qgin.OGRequestBodyObject(reflect.TypeOf(model.QueryLogDetailsRequest{}), "json"),
		queryByFilter)

	// 获取最新的 控制中心节点树
	rg.POST("/getCCIDTree",
		getCCIDTree)

	// 导出
	rg.POST("/export",
		qgin.OGRequestBodyObject(reflect.TypeOf(model.QueryLogDetailsRequest{}), "json"),
		exportLogDetails)
}

func getCustomColumns(c *gin.Context) {
	reqData := c.MustGet("requestBody").(*model.GetCustomColumnRequest)
	businessCode := reqData.BusinessCode
	if len(businessCode) <= 0 {
		c.JSON(http.StatusOK, qgin.NewError(def.Err_InvalidParameter, "business 参数无效"))
		return
	}

	columnViewModel, err := custom_column.GetCustomColumns(businessCode)
	if err != nil {
		c.JSON(http.StatusOK, &qgin.Response{Code: def.Err_GetErr, Msg: err.Error()})
		return
	}

	c.JSON(http.StatusOK, &qgin.Response{Data: columnViewModel})
	return
}

func updateCustomColumns(c *gin.Context) {
	reqData := c.MustGet("requestBody").(*model.UpdateCustomColumnRequest)
	businessCode := reqData.BusinessCode
	if len(businessCode) <= 0 {
		c.JSON(http.StatusOK, qgin.NewError(def.Err_InvalidParameter, "business 参数无效"))
		return
	}

	err := custom_column.UpdateCustomColumns(reqData)
	if err != nil {
		c.JSON(http.StatusOK, &qgin.Response{Code: def.Err_GetErr, Msg: err.Error()})
		return
	}

	c.JSON(http.StatusOK, &qgin.Response{Data: "success"})
	return
}

func getFilterTemplateList(c *gin.Context) {
	reqData := c.MustGet("requestBody").(*model.GetConditionTemplateRequest)
	businessCode := reqData.BusinessCode
	if len(businessCode) <= 0 {
		c.JSON(http.StatusOK, qgin.NewError(def.Err_InvalidParameter, "business 参数无效"))
		return
	}

	templateList, err := log_details.GetConditionTemplateList(businessCode)
	if err != nil {
		c.JSON(http.StatusOK, &qgin.Response{Code: def.Err_GetErr, Msg: err.Error()})
		return
	}

	c.JSON(http.StatusOK, &qgin.Response{Data: templateList})
	return
}

func updateFilterTemplate(c *gin.Context) {
	reqData := c.MustGet("requestBody").(*model.UpdateConditionTemplateRequest)

	if len(reqData.Name) <= 0 {
		c.JSON(http.StatusOK, qgin.NewError(def.Err_InvalidParameter, "name 参数无效"))
		return
	}
	if len(reqData.BusinessCode) <= 0 {
		c.JSON(http.StatusOK, qgin.NewError(def.Err_InvalidParameter, "business 参数无效"))
		return
	}
	if len(reqData.Conditions) <= 0 {
		c.JSON(http.StatusOK, qgin.NewError(def.Err_InvalidParameter, "conditions 参数无效"))
		return
	}
	if len(reqData.RelationTemplate) <= 0 {
		c.JSON(http.StatusOK, qgin.NewError(def.Err_InvalidParameter, "relationTemplate 参数无效"))
		return
	}

	err := log_details.UpdateConditionTemplate(reqData)
	if err != nil {
		c.JSON(http.StatusOK, &qgin.Response{Code: def.Err_UpdateErr, Msg: err.Error()})
		return
	}

	c.JSON(http.StatusOK, &qgin.Response{Data: "success"})
	return
}

func deleteFilterTemplateById(c *gin.Context) {
	reqData := c.MustGet("requestBody").(*model.DeleteConditionTemplateRequest)

	if reqData.TemplateId <= 0 {
		c.JSON(http.StatusOK, qgin.NewError(def.Err_InvalidParameter, "templateId 参数无效"))
		return
	}

	err := log_details.DeleteConditionTemplate(reqData.TemplateId)
	if err != nil {
		c.JSON(http.StatusOK, &qgin.Response{Code: def.Err_GetErr, Msg: err.Error()})
		return
	}

	c.JSON(http.StatusOK, &qgin.Response{Data: "success"})
	return
}

func getFilterFieldsConfig(c *gin.Context) {

	reqData := c.MustGet("requestBody").(*model.GetFilterFieldsConfigRequest)
	businessCode := reqData.BusinessCode
	if len(businessCode) <= 0 {
		c.JSON(http.StatusOK, qgin.NewError(def.Err_InvalidParameter, "business 参数无效"))
		return
	}

	queryFieldsConf, err := log_details.GetQueryFields(businessCode)
	if err != nil {
		c.JSON(http.StatusOK, &qgin.Response{Code: def.Err_GetErr, Msg: err.Error()})
		return
	}

	c.JSON(http.StatusOK, &qgin.Response{Data: queryFieldsConf})
	return
}

func getCCIDTree(c *gin.Context) {

	ccidTree, _, err := cascade_config.GetCascadeCCIDTree()
	if err != nil {
		c.JSON(http.StatusOK, &qgin.Response{Code: def.Err_GetErr, Msg: err.Error()})
		return
	}

	c.JSON(http.StatusOK, &qgin.Response{Data: ccidTree})
	return
}

func exportLogDetails(c *gin.Context) {
	reqData := c.MustGet("requestBody").(*model.QueryLogDetailsRequest)

	logs.Debugf("日志详情导出参数: [uid: %d] [business: %s] [topccid: %s] ", reqData.Uid, reqData.BusinessCode, reqData.TopCCId)

	if len(reqData.BusinessCode) <= 0 {
		c.JSON(http.StatusOK, qgin.NewError(def.Err_InvalidParameter, "business 参数无效"))
		return
	}
	if len(reqData.TopCCId) <= 0 {
		c.JSON(http.StatusOK, qgin.NewError(def.Err_InvalidParameter, "topCCId 参数无效"))
		return
	}
	if reqData.Uid <= 0 {
		c.JSON(http.StatusOK, qgin.NewError(def.Err_InvalidParameter, "Uid 参数无效"))
		return
	}

	if reqData.StartTime != nil && reqData.StartTime.T.Unix() <= 0 {
		reqData.StartTime = nil
	}
	if reqData.EndTime != nil && reqData.EndTime.T.Unix() <= 0 {
		reqData.EndTime = nil
	}

	err := exporter.ExportForLogDetail(reqData)
	if err != nil {
		c.JSON(http.StatusOK, &qgin.Response{Code: def.Err_ExportErr, Msg: err.Error()})
		return
	}

	c.JSON(http.StatusOK, &qgin.Response{Data: "success"})
	return
}

func queryByFilter(c *gin.Context) {
	reqData := c.MustGet("requestBody").(*model.QueryLogDetailsRequest)

	if len(reqData.BusinessCode) <= 0 {
		c.JSON(http.StatusOK, qgin.NewError(def.Err_InvalidParameter, "business 参数无效"))
		return
	}

	if len(reqData.TopCCId) <= 0 {
		c.JSON(http.StatusOK, qgin.NewError(def.Err_InvalidParameter, "topCCId 参数无效"))
		return
	}

	// 默认值
	if reqData.Current <= 0 {
		reqData.Current = 1
	}
	if reqData.PageSize <= 0 {
		reqData.PageSize = 20
	}

	if reqData.StartTime != nil && reqData.StartTime.T.Unix() <= 0 {
		reqData.StartTime = nil
	}
	if reqData.StartTime != nil && reqData.EndTime.T.Unix() <= 0 {
		reqData.EndTime = nil
	}

	logDetails, err := log_details.QueryByFilter(reqData)
	if err != nil {
		c.JSON(http.StatusOK, &qgin.Response{Code: def.Err_GetErr, Msg: err.Error()})
		return
	}

	c.JSON(http.StatusOK, &qgin.Response{Data: logDetails})
	return
}
