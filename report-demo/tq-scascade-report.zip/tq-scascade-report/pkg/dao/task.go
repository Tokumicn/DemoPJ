package dao

import (
	"git-biz.qianxin-inc.cn/eps/skylar/apps/libs/tianqing.git/utils"
	"tq-scascade-report/pkg/postgres"
)

type CronQueryTask struct {
	Id          int64           `gorm:"primary_key;column:id"`
	Name        string          `gorm:"column:name"`         // 报表展示名
	JobName     string          `gorm:"column:job_name"`     // 报表任务名
	Business    string          `gorm:"column:business"`     // 所属业务
	ReportTypes string          `gorm:"column:report_types"` // 报表类型
	TopCCId     string          `gorm:"column:top_ccid"`
	CCIDsTree   string          `gorm:"column:ccids_tree"` // 控制中心Json树
	RawTree     string          `gorm:"column:raw_tree"`   // 控制中心Raw树
	DataCover   bool            `gorm:"column:data_cover"` // 覆盖原报表
	CronType    string          `gorm:"column:cron_type"`  // 时间周期类型： 天、周、月 daily/weekly/monthly/now
	Day         int             `gorm:"column:day"`        // 日期详情：1~30(周一到周日、日期1号到30号)
	Hours       int             `gorm:"column:hours"`      // 0~23
	Minutes     int             `gorm:"column:minutes"`    // 0~59
	TimeScale   string          `gorm:"column:time_scale"`
	TimeRange   string          `gorm:"column:time_range"`
	StartTime   string          `gorm:"column:start_time"`
	EndTime     string          `gorm:"column:end_time"`
	CreateTime  *utils.JSONTime `gorm:"column:create_time"`
	UpdateTime  *utils.JSONTime `gorm:"column:update_time"`
}

func cronQueryTaskDB() *postgres.ORM {

	return postgres.GetDefaultPostgresORM().Table("cron_task")
}

func (task *CronQueryTask) Create() error {

	if err := cronQueryTaskDB().Create(task).Error; err != nil {
		return err
	}
	return nil
}

func (task *CronQueryTask) Delete() error {

	if err := cronQueryTaskDB().Delete(task).Error; err != nil {
		return err
	}
	return nil
}

// 根据Id获取
func (task *CronQueryTask) Get() (*CronQueryTask, error) {

	e := &CronQueryTask{}
	if err := cronQueryTaskDB().Where("id = ?", task.Id).First(e).Error; err != nil {
		return nil, err
	}
	return e, nil
}

func (task *CronQueryTask) Update(id int64) (*CronQueryTask, int64, bool, error) {

	aff := cronQueryTaskDB().Model(&CronQueryTask{}).Where("id = ?", id).Save(task).RowsAffected

	e := &CronQueryTask{}
	if err := cronQueryTaskDB().Where("id = ?", id).First(e).Error; err != nil {
		if err == postgres.ErrRecordNotFound {
			return nil, aff, false, nil
		} else {
			return nil, aff, false, err
		}
	}
	return e, aff, true, nil
}

func (task *CronQueryTask) List(pageSize, current int64, filer map[string]interface{}, rawq string, order int64, ordcond string) ([]*CronQueryTask, int64, error) {

	result := make([]*CronQueryTask, 0)
	db := cronQueryTaskDB().Model(CronQueryTask{})
	if filer != nil {
		db = db.Where(filer)
	}

	if len(rawq) > 0 {
		db = db.Where(rawq)
	}

	if order > 0 {
		db = db.Order("id asc")
	} else if order < 0 {
		db = db.Order("id desc")
	} else if len(ordcond) > 0 {
		db = db.Order(ordcond)
	}

	offset := (current - 1) * pageSize
	if offset > 0 {
		db = db.Offset(int(offset))
	}
	if pageSize > 0 {
		db = db.Limit(int(pageSize))
	}

	if err := db.Find(&result).Error; err != nil {
		return nil, 0, err
	}

	var total int64
	if err := db.Count(&total).Error; err != nil {
		return nil, 0, err
	}

	return result, total, nil
}

func (task *CronQueryTask) NameExist() (bool, error) {

	var total int64
	if err := cronQueryTaskDB().Where("name = ?", task.Name).Count(&total).Error; err != nil {
		return false, err
	}

	return total > 0, nil
}
