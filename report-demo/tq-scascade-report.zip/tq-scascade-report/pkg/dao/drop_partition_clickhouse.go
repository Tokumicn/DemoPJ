package dao

// 根据用户设置的过期时间删除过期的ClickHouse数据
import (
	"log"
	"strings"
	"time"
	"tq-scascade-report/pkg/clickhouse"
	"tq-scascade-report/pkg/def"
)

type Partition struct {
	Par string `json:"partition"`
}

const (
	queryUselessPartitionSql = `SELECT partition
								       FROM system.parts
								       WHERE table = (?) AND partition < (?);`

	dropPartitionSql = "ALTER TABLE	{tableName} DROP PARTITION (?)"
)

func DropPartition(tableName string, uselessDate time.Time) error {

	// uselessDate : 格式要求 YYYYMMDD ==> 例如,20200717
	dropDate := uselessDate.Format(def.YYYYMMDD)

	db := clickhouse.GetClickHouseDB()

	// 查询需要删除的Partition
	partitions, err := queryToDelPartitions(db, tableName, dropDate)
	if err != nil {
		return err
	}

	// 删除无效Partition
	for _, dropPar := range partitions {
		err := dropPartitions(db, tableName, dropPar)
		if err != nil {
			log.Printf("drop [partition: %s] [err: %s]", dropPar, err.Error())
			continue
		}
	}

	return nil
}

func queryToDelPartitions(db *clickhouse.DB, tableName, dropDate string) ([]string, error) {
	rows, err := db.Queryx(queryUselessPartitionSql, tableName, dropDate)
	if err != nil {
		log.Fatal(err)
	}
	defer rows.Close()

	sliceRes := []string{}
	for rows.Next() {
		temp := &Partition{}
		err = rows.StructScan(temp)
		if err != nil {
			log.Println("struct scan err: ", err)
			continue
		}
		sliceRes = append(sliceRes, temp.Par)
	}

	return sliceRes, nil
}

func dropPartitions(db *clickhouse.DB, tableName, partitionName string) error {
	dropSql := strings.Replace(dropPartitionSql, "{tableName}", tableName, -1)

	_, err := db.Exec(dropSql, partitionName)
	if err != nil {
		return err
	}

	return nil
}
