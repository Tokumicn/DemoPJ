package dao

import (
	"fmt"
	"git-biz.qianxin-inc.cn/eps/skylar/apps/libs/tianqing.git/logs"
	"git-biz.qianxin-inc.cn/eps/skylar/apps/libs/tianqing.git/utils"
	"testing"
	"time"
	"tq-scascade-report/pkg/postgres"
)

func init() {

	logs.Init(logs.Config{
		Writer: "console",
		Level:  "debug",
	})

	postgres.InitPostgresDB(&postgres.Config{
		Debug:           true,
		Host:            "10.44.203.3",
		Port:            "5432",
		User:            "postgres",
		Password:        "postgres",
		DBName:          "scascade",
		ApplicationName: "tq-scascade-report",
		MaxIdle:         2,
		MaxOpen:         4,
		MaxLife:         600,
	})
}

func TestDBTaskResult(t *testing.T) {
	var tempId = 1100
	for i := 0; i < 50; i++ {

		res := &TaskResult{
			TaskId:        int64(tempId + i),
			TaskName:      fmt.Sprintf("testTask%d", i),
			CronExpr:      fmt.Sprintf("testCronExpr%d", i),
			Condition:     fmt.Sprintf("testCondition%d", i),
			PlanStartTime: &utils.JSONTime{T: time.Now()},
			RealStartTime: &utils.JSONTime{T: time.Now()},
			FinishTime:    &utils.JSONTime{T: time.Now()},
		}

		newId, err := res.Create()
		if err != nil {
			t.Error(err)
		}
		t.Log("新增Id: ", newId)

		if newId <= 0 {
			t.Fatal()
		}
	}

	Ids := []int64{}
	res := &TaskResult{}
	current := 1
	pageSize := 10
	for {
		results, err := res.List(int64(pageSize), int64(current), nil, "", 1, "")
		if err != nil {
			t.Fatal()
		}

		for _, r := range results {
			Ids = append(Ids, r.Id)
		}

		if len(results) < pageSize {
			break
		}

		current++
	}

	// clear test data
	r := &TaskResult{
		Id: 0,
	}
	for _, id := range Ids {
		r.Id = id
		err := r.Delete()
		if err != nil {
			t.Log(err)
			continue
		}
	}

}

func TestQueryUselessResultList(t *testing.T) {

	dto := TaskResult{}

	var YYYMMDD = "2006-01-02"

	dropTimeStr := time.Now().AddDate(0, 0, -6).Format(YYYMMDD)
	dropTime, err := time.Parse(YYYMMDD, dropTimeStr)
	if err != nil {
		t.Fatal(err)
	}

	uselessIds, err := dto.ListOfUselessIds(dropTime)
	if err != nil {
		t.Fatal(err)
	}

	t.Log(uselessIds)
}
