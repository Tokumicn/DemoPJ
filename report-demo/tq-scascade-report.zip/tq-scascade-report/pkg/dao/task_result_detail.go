package dao

import (
	"encoding/json"
	"fmt"
	"git-biz.qianxin-inc.cn/eps/skylar/apps/libs/tianqing.git/logs"
	"github.com/jmoiron/sqlx"
	"tq-scascade-report/pkg/def"
	"tq-scascade-report/pkg/postgres"
	"tq-scascade-report/pkg/tools"
)

type Condition struct {
	TopCCId     string `json:"topCCId"`
	Business    string `json:"business"`    // 所属业务 -- 确定表名
	ReportTypes string `json:"reportTypes"` // 报表类型 -- 确定查询类型（Group By、SUM、TOP等）
	TimeScale   string `json:"timeScale"`   // 时间刻度
	StartTime   string `json:"startTime"`
	EndTime     string `json:"endTime"`
}

func GetReportDetailCondition(resultId int64) (*Condition, error) {

	resDto := TaskResult{
		Id: resultId,
	}
	taskRes, err := resDto.GetById()
	if err != nil {
		return nil, err
	}

	condition := &Condition{}
	err = json.Unmarshal([]byte(taskRes.Condition), condition)
	if err != nil {
		return nil, err
	}

	return condition, nil
}

// 获取日志详情所在表
func getReportDetailTableNameList(resultId int64) ([]string, error) {

	condition, err := GetReportDetailCondition(resultId)
	if err != nil {
		return nil, nil
	}
	reportTypeArr := tools.SplitStrWithoutEmpty(condition.ReportTypes, ",")

	tableList := []string{}
	for _, typ := range reportTypeArr {
		tableName, err := def.GetTableNameByType(condition.Business, typ)
		if err != nil {
			logs.Error("[GetTableNameByType] error: ", err.Error())
			continue
		}
		tableList = append(tableList, tableName)
	}

	return tableList, err
}

// 根据reportTypes 删除全部涉及到的表
func DeleteReportDetailData(resultId int64) error {

	tableNames, err := getReportDetailTableNameList(resultId)
	if err != nil {
		return err
	}

	for _, tName := range tableNames {
		delSql := fmt.Sprintf("DELETE FROM %s WHERE result_id = :resultId;", tName)
		delArgs := map[string]interface{}{
			"resultId": resultId,
		}

		res, err := postgres.GetDefaultPostgresDB().NamedExec(delSql, delArgs)
		if err != nil {
			logs.Error("[DeleteReportDetailData] 删除报表详情数据[tableNames: %v] [resultId: %d]", tableNames, resultId)
			continue
		}

		rowsAffected, err := res.RowsAffected()
		if err != nil {
			continue
		}

		logs.Debugf("[DeleteReportDetailData] 删除报表详情数据 [resultId: %d] [rowsAffected: %d]", resultId, rowsAffected)
	}

	return nil
}

func GetSummarizeReportDetailData(resultId int64, tableName string, topCCId string) ([]map[string]interface{}, int, error) {

	qSql := fmt.Sprintf("SELECT * FROM %s WHERE result_id = :resultId AND top_ccid = :topCCId", tableName)
	stmt, err := postgres.GetDefaultPostgresDB().PrepareNamed(qSql)
	if err != nil {
		return nil, -1, err
	}

	args := map[string]interface{}{
		"resultId": resultId,
		"topCCId":  topCCId,
	}
	rows, err := stmt.Queryx(args)
	if err != nil {
		return nil, -1, err
	}
	defer rows.Close()

	var res []map[string]interface{}
	for rows.Next() {
		m := map[string]interface{}{}
		err := rows.MapScan(m)
		if err != nil {
			return nil, -1, err
		}
		res = append(res, m)
	}

	return res, len(res), nil
}

func getReportDetailTotal(totalSql string, args map[string]interface{}) (int, error) {
	db := postgres.GetDefaultPostgresDB()

	query, arg, err := sqlx.Named(totalSql, args)
	query, arg, err = sqlx.In(query, arg...)
	query = db.Rebind(query)
	rows, err := db.Queryx(query, arg...)
	if err != nil {
		return -1, err
	}

	defer rows.Close()

	var total int64 = 0
	for rows.Next() {
		m := map[string]interface{}{}
		err := rows.MapScan(m)
		if err != nil {
			return -1, err
		}

		if val, ok := m["total"]; ok {
			total = val.(int64)
			break
		}
	}

	return int(total), nil
}

func getReportDetail(querySql string, args map[string]interface{}) ([]map[string]interface{}, error) {
	db := postgres.GetDefaultPostgresDB()
	query, arg, err := sqlx.Named(querySql, args)
	query, arg, err = sqlx.In(query, arg...)
	query = db.Rebind(query)
	rows, err := db.Queryx(query, arg...)
	if err != nil {
		return nil, err
	}

	defer rows.Close()

	var res []map[string]interface{}
	for rows.Next() {
		m := map[string]interface{}{}
		err := rows.MapScan(m)
		if err != nil {
			return nil, err
		}
		res = append(res, m)
	}

	return res, nil
}

func GetReportDetailDataWithQuery(querySql, totalSql string, args map[string]interface{}) ([]map[string]interface{}, int, error) {

	// 获取Total
	total, err := getReportDetailTotal(totalSql, args)
	if err != nil {
		return nil, -1, err
	}

	res, err := getReportDetail(querySql, args)
	if err != nil {
		return nil, -1, err
	}

	return res, total, nil
}
