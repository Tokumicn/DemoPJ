package dao

import (
	"git-biz.qianxin-inc.cn/eps/skylar/apps/libs/tianqing.git/utils"
	"tq-scascade-report/pkg/postgres"
)

// 高级搜索条件相关配置
type XXXQueryFieldsConfigXXX struct {
	Id            int64           `gorm:"primary_key;column:id"`
	BusinessCode  string          `gorm:"column:business_code"`  // 所属业务
	DisplayName   string          `gorm:"column:display_name"`   // 展示名
	FieldName     string          `gorm:"column:filed_name"`     // 筛选Key
	Operation     string          `gorm:"column:operation"`      // 可选操作 JSON:{ "key": ">", "value": "大于" }, {...}, ...
	OptionalValue string          `gorm:"column:optional_value"` // 可选值   JSON:{ "key": 1, "value": "笔记本" }, {...}, ...
	CreateTime    *utils.JSONTime `gorm:"column:create_time"`
	UpdateTime    *utils.JSONTime `gorm:"column:update_time"`
}

func queryFieldsConfigDB() *postgres.ORM {

	return postgres.GetDefaultPostgresORM().Table("query_condition_tlp")
}

func (conf *XXXQueryFieldsConfigXXX) Create() error {

	if err := queryFieldsConfigDB().Create(conf).Error; err != nil {
		return err
	}
	return nil
}

func (conf *XXXQueryFieldsConfigXXX) Delete() error {

	if err := queryFieldsConfigDB().Delete(conf).Error; err != nil {
		return err
	}
	return nil
}

// 根据Id获取
func (conf *XXXQueryFieldsConfigXXX) Get() (*XXXQueryFieldsConfigXXX, error) {

	e := &XXXQueryFieldsConfigXXX{}
	if err := queryFieldsConfigDB().Where("id = ?", conf.Id).First(e).Error; err != nil {
		return nil, err
	}
	return e, nil
}

// 根据业务类型获取
func (conf *XXXQueryFieldsConfigXXX) GetByBusinessCode() (*XXXQueryFieldsConfigXXX, error) {

	e := &XXXQueryFieldsConfigXXX{}
	if err := queryFieldsConfigDB().Where("business_code = ?", conf.BusinessCode).First(e).Error; err != nil {
		return nil, err
	}
	return e, nil
}

func (conf *XXXQueryFieldsConfigXXX) Update(id int64) (*XXXQueryFieldsConfigXXX, int64, bool, error) {

	aff := queryFieldsConfigDB().Model(&XXXQueryFieldsConfigXXX{}).Where("id = ?", id).Save(conf).RowsAffected

	e := &XXXQueryFieldsConfigXXX{}
	if err := queryFieldsConfigDB().Where("id = ?", id).First(e).Error; err != nil {
		if err == postgres.ErrRecordNotFound {
			return nil, aff, false, nil
		} else {
			return nil, aff, false, err
		}
	}
	return e, aff, true, nil
}
