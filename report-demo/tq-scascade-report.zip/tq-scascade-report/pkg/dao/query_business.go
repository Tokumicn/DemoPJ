package dao

import (
	"git-biz.qianxin-inc.cn/eps/skylar/apps/libs/tianqing.git/utils"
	"gorm.io/gorm"
	"tq-scascade-report/pkg/postgres"
)

// 自定义列
type QueryCustomColumn struct {
	Id             int64           `gorm:"primary_key;column:id"`
	BusinessCode   string          `gorm:"column:business_code"`   // 所属业务标识
	TableName      string          `gorm:"column:table_name"`      // 所在表
	CustomColumn   string          `gorm:"column:custom_column"`   // 自定义显示列(初始化为默认显示列)
	OptionalColumn string          `gorm:"column:optional_column"` // 可选显示列
	AllColumnMap   string          `gorm:"column:all_column_map"`  // 全列kv
	CreateTime     *utils.JSONTime `gorm:"column:create_time"`
	UpdateTime     *utils.JSONTime `gorm:"column:update_time"`
}

func queryBusinessDB() *postgres.ORM {

	return postgres.GetDefaultPostgresORM().Table("query_custom_column")
}

func (lo *QueryCustomColumn) Create() error {

	if err := queryBusinessDB().Create(lo).Error; err != nil {
		return err
	}
	return nil
}

func (lo *QueryCustomColumn) Delete() error {

	if err := queryBusinessDB().Delete(lo).Error; err != nil {
		return err
	}
	return nil
}

func (lo *QueryCustomColumn) List() ([]*QueryCustomColumn, error) {

	result := make([]*QueryCustomColumn, 0)
	if err := queryBusinessDB().Where("id > 0").Find(&result).Error; err != nil {
		return nil, err
	}

	return result, nil
}

// 根据Id获取
func (lo *QueryCustomColumn) Get() (*QueryCustomColumn, error) {

	e := &QueryCustomColumn{}
	if err := queryBusinessDB().Where("id = ?", lo.Id).First(e).Error; err != nil {
		return nil, err
	}
	return e, nil
}

// 根据业务类型获取
func (lo *QueryCustomColumn) GetByBusinessCode() (*QueryCustomColumn, error) {

	e := &QueryCustomColumn{}
	if err := queryBusinessDB().Where("business_code = ?", lo.BusinessCode).First(e).Error; err != nil {
		if err == gorm.ErrRecordNotFound {
			return nil, nil
		}
		return nil, err
	}
	return e, nil
}

func (lo *QueryCustomColumn) Update(id int64) (*QueryCustomColumn, int64, bool, error) {

	aff := queryBusinessDB().Model(&QueryCustomColumn{}).Where("id = ?", id).Save(lo).RowsAffected

	e := &QueryCustomColumn{}
	if err := queryBusinessDB().Where("id = ?", id).First(e).Error; err != nil {
		if err == postgres.ErrRecordNotFound {
			return nil, aff, false, nil
		} else {
			return nil, aff, false, err
		}
	}
	return e, aff, true, nil
}
