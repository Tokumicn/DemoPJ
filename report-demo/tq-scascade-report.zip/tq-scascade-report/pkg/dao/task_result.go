package dao

import (
	"git-biz.qianxin-inc.cn/eps/skylar/apps/libs/tianqing.git/utils"
	"time"
	"tq-scascade-report/pkg/postgres"
)

type TaskResult struct {
	Id            int64           `gorm:"primary_key;column:id"`
	TaskId        int64           `gorm:"column:task_id"`
	TaskName      string          `gorm:"column:task_name"` //
	RawTree       string          `gorm:"column:raw_tree"`  // 生成结果时记录ccid树快照
	CronExpr      string          `gorm:"column:cron_expr"` // cron表达式
	Condition     string          `gorm:"column:condition"`
	PlanStartTime *utils.JSONTime `gorm:"column:plan_start_time"`
	RealStartTime *utils.JSONTime `gorm:"column:real_start_time"`
	FinishTime    *utils.JSONTime `gorm:"column:finish_time"`
}

func queryResultDB() *postgres.ORM {
	return postgres.GetDefaultPostgresORM().Table("cron_task_result")
}

func (res *TaskResult) GetByTaskId() ([]*TaskResult, error) {
	results := make([]*TaskResult, 0)
	if err := queryResultDB().
		Where("task_id = ?", res.TaskId).
		Order("id desc").
		Find(&results).Error; err != nil {
		return nil, err
	}

	return results, nil
}

func (res *TaskResult) Create() (int64, error) {
	if err := queryResultDB().Create(res).Error; err != nil {
		return 0, err
	}

	return res.Id, nil
}

func (res *TaskResult) GetById() (*TaskResult, error) {
	out := &TaskResult{}
	if err := queryResultDB().Where("id = ?", res.Id).First(&out).Error; err != nil {
		return nil, err
	}

	return out, nil
}

func (res *TaskResult) Delete() error {
	if err := queryResultDB().Delete(res).Error; err != nil {
		return err
	}
	return nil
}

func (res *TaskResult) List(pageSize, current int64, filer map[string]interface{}, rawq string, order int64, ordcond string) ([]*TaskResult, int64, error) {
	result := make([]*TaskResult, 0)
	db := queryResultDB().Model(TaskResult{})
	if filer != nil {
		db = db.Where(filer)
	}

	if len(rawq) > 0 {
		db = db.Where(rawq)
	}

	if order > 0 {
		db = db.Order("id asc")
	} else if order < 0 {
		db = db.Order("id desc")
	} else if len(ordcond) > 0 {
		db = db.Order(ordcond)
	}

	offset := (current - 1) * pageSize
	if offset > 0 {
		db = db.Offset(int(offset))
	}
	if pageSize > 0 {
		db = db.Limit(int(pageSize))
	}

	if err := db.Find(&result).Error; err != nil {
		return nil, 0, err
	}

	var total int64
	if err := db.Count(&total).Error; err != nil {
		return nil, 0, err
	}

	return result, total, nil
}

// 获取过期的报表结果Id列表
func (res *TaskResult) ListOfUselessIds(uselessDate time.Time) ([]int64, error) {
	out := make([]*TaskResult, 0)
	if err := queryResultDB().Where("finish_time < ?", uselessDate).Find(&out).Error; err != nil {
		return nil, err
	}

	uselessResultIds := []int64{}
	for _, res := range out {
		uselessResultIds = append(uselessResultIds, res.Id)
	}

	return uselessResultIds, nil
}
