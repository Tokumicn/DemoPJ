package dao

import (
	"git-biz.qianxin-inc.cn/eps/skylar/apps/libs/tianqing.git/utils"
	"tq-scascade-report/pkg/postgres"
)

type ConditionTemplate struct {
	Id               int64           `gorm:"primary_key;column:id"`
	Name             string          `gorm:"column:name"` // 展示名
	BusinessCode     string          `gorm:"column:business_code"`
	Conditions       string          `gorm:"column:conditions"`
	RelationTemplate string          `gorm:"column:relation_tlp"`
	CreateTime       *utils.JSONTime `gorm:"column:create_time"`
	UpdateTime       *utils.JSONTime `gorm:"column:update_time"`
}

func queryConditionTlpDB() *postgres.ORM {

	return postgres.GetDefaultPostgresORM().Table("query_condition_tlp")
}

func (tlp *ConditionTemplate) Create() error {

	if err := queryConditionTlpDB().Create(tlp).Error; err != nil {
		return err
	}
	return nil
}

func (tlp *ConditionTemplate) Delete() error {

	if err := queryConditionTlpDB().Delete(tlp).Error; err != nil {
		return err
	}
	return nil
}

// 根据Id获取
func (tlp *ConditionTemplate) Get() (*ConditionTemplate, error) {

	e := &ConditionTemplate{}
	if err := queryConditionTlpDB().Where("id = ?", tlp.Id).First(e).Error; err != nil {
		return nil, err
	}
	return e, nil
}

// 根据业务类型获取条件列表
func (tlp *ConditionTemplate) GetByBusinessCode() ([]*ConditionTemplate, error) {

	e := make([]*ConditionTemplate, 0)
	if err := queryConditionTlpDB().Where("business_code = ?", tlp.BusinessCode).Find(&e).Error; err != nil {
		return nil, err
	}
	return e, nil
}

func (tlp *ConditionTemplate) GetByNameAndCode() ([]*ConditionTemplate, error) {

	e := make([]*ConditionTemplate, 0)
	if err := queryConditionTlpDB().Where("business_code = ? AND name = ?", tlp.BusinessCode, tlp.Name).Find(&e).Error; err != nil {
		return nil, err
	}
	return e, nil
}

func (tlp *ConditionTemplate) Update(id int64) (*ConditionTemplate, int64, bool, error) {

	aff := queryConditionTlpDB().Model(&ConditionTemplate{}).Where("id = ?", id).Save(tlp).RowsAffected

	e := &ConditionTemplate{}
	if err := queryConditionTlpDB().Where("id = ?", id).First(e).Error; err != nil {
		if err == postgres.ErrRecordNotFound {
			return nil, aff, false, nil
		} else {
			return nil, aff, false, err
		}
	}
	return e, aff, true, nil
}
