package tools

import (
	"testing"
)

func TestStringSplit(t *testing.T) {
	//ccids := ""
	//CCIds := strings.Split(ccids, ",")
	//t.Log("1: ", len(CCIds))
	//
	//ccids = "AAA,BBB,CCC"
	//CCIds = strings.Split(ccids, ",")
	//t.Log("\n2: ", len(CCIds))
	//
	//ccids = ","
	//CCIds = strings.Split(ccids, ",")
	//t.Log("\n3: ", len(CCIds))

	ccids := ""
	CCIds := SplitStrWithoutEmpty(ccids, ",")
	t.Log("1: ", len(CCIds))

	ccids = "AAA,BBB,CCC"
	CCIds = SplitStrWithoutEmpty(ccids, ",")
	t.Log("\n2: ", len(CCIds))

	ccids = ","
	CCIds = SplitStrWithoutEmpty(ccids, ",")
	t.Log("\n3: ", len(CCIds))

}
