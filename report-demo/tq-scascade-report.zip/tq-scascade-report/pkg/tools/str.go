package tools

import "strings"

func SplitStrWithoutEmpty(str string, sep string) []string {

	var strArr []string
	tempArr := strings.Split(str, sep)

	for _, v := range tempArr {
		if len(v) > 0 {
			strArr = append(strArr, v)
		}
	}

	return strArr
}
