package tools

import (
	"fmt"
	"testing"
	"time"
	"tq-scascade-report/pkg/def"
)

func TestGetLastWeekFirstDate(t *testing.T) {
	s, e := GetLastWeekDateRange(time.Now())
	t.Log(fmt.Sprintf("开始时间: %s --- 结束时间: %s", s.Format(def.YYYYMMDDHHSSmm), e.Format(def.YYYYMMDDHHSSmm)))
}

func TestGetThisMonthDateRange(t *testing.T) {
	s, e := GetThisMonthDateRange(time.Now())
	t.Log(fmt.Sprintf("开始时间: %s --- 结束时间: %s", s.Format(def.YYYYMMDDHHSSmm), e.Format(def.YYYYMMDDHHSSmm)))
}

func TestGetQuarterDateRange(t *testing.T) {
	s, e := GetThisQuarterDateRange(time.Now())
	t.Log(fmt.Sprintf("开始时间: %s --- 结束时间: %s", s.Format(def.YYYYMMDDHHSSmm), e.Format(def.YYYYMMDDHHSSmm)))
}

func TestGetYearDateRange(t *testing.T) {
	s, e := GetThisYearDateRange(time.Now())
	t.Log(fmt.Sprintf("开始时间: %s --- 结束时间: %s", s.Format(def.YYYYMMDDHHSSmm), e.Format(def.YYYYMMDDHHSSmm)))
}
