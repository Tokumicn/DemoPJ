package tools

import "errors"

func TryParseInt(i interface{}) (int, error) {
	var res int
	switch i.(type) {
	case int:
		res = i.(int)
	case uint8:
		res = int(i.(uint8))
	case uint16:
		res = int(i.(uint16))
	case uint32:
		res = int(i.(uint32))
	case uint64:
		res = int(i.(uint64))
	case int8:
		res = int(i.(int8))
	case int16:
		res = int(i.(int16))
	case int32:
		res = int(i.(int32))
	case int64:
		res = int(i.(int32))
	default:
		return 0, errors.New("error type for integer.")
	}

	return res, nil
}
