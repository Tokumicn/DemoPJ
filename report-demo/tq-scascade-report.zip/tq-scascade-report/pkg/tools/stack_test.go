package tools

import "testing"

func Test_Stack(t *testing.T) {
	s := NewStack()

	s.Push('(')
	s.Push('(')
	s.Pop()
	if s.IsEmpty() {
		t.Fatal()
	}
	s.Pop()
	if !s.IsEmpty() {
		t.Fatal()
	}
}
