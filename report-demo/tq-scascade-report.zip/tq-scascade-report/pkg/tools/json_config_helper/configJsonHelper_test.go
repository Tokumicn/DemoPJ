package json_config_helper

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"log"
	"os"
	"testing"
	"tq-scascade-report/pkg/def"
	"tq-scascade-report/service/log_details/custom_column"
)

// 配置文件源对象--修改该对象后，生成对应的json文件即可
var defaultCustomConfigMap = map[string]*custom_column.CustomColumnConfig{
	// 扫描分数
	def.SCORE: {
		TableName: def.SCORE_SCOURSE_DATA_TABLENAME,
		CustomColumn: map[string]string{
			"event_time":              "时间",
			"client_name":             "计算机名",
			"client_ip":               "IP地址",
			"client_mac":              "MAC地址",
			"client_groupname":        "分组",
			"ccid":                    "所属控制中心",
			"client_os":               "操作系统",
			"client_third_login_user": "实名账号",
			"exam_score":              "分数", // 业务特有字段
		},
		OptionalColumn: map[string]string{},
	},

	// 病毒分析
	def.VIRUS: {
		TableName: def.VIRUS_SCOURSE_DATA_TABLENAME,
		CustomColumn: map[string]string{
			"event_time":              "时间",
			"client_name":             "计算机名",
			"client_ip":               "IP地址",
			"client_mac":              "MAC地址",
			"client_groupname":        "分组",
			"ccid":                    "所属控制中心",
			"client_os":               "操作系统",
			"client_third_login_user": "实名账号",
			"task_id":                 "触发方式", // 业务特有字段 // 需要特殊处理
			"from":                    "病毒来源", // 业务特有字段
			"vname":                   "病毒名称", // 业务特有字段
			"md5":                     "MD5",  // 业务特有字段
			"sha1":                    "SHA1", // 业务特有字段
			"op":                      "处理结果", // 业务特有字段 // 需要特殊处理
			"path":                    "文件路径", // 业务特有字段
			// "":                        "实名姓名",
		},
		OptionalColumn: map[string]string{},
	},

	// 漏洞分析
	def.LEAK: {
		TableName: def.LEAK_SCOURSE_DATA_TABLENAME,
		CustomColumn: map[string]string{
			"event_time":              "时间",
			"client_name":             "计算机名",
			"client_ip":               "IP地址",
			"client_mac":              "MAC地址",
			"client_groupname":        "分组",
			"ccid":                    "所属控制中心",
			"client_os":               "操作系统",
			"client_third_login_user": "实名账号",
			"leak_name":               "补丁名",  // 业务特有字段
			"leak_type":               "漏洞级别", // 业务特有字段
			"event_action":            "操作",   // 特殊处理
			// "":                        "实名姓名",
		},
		OptionalColumn: map[string]string{
			"kbid":   "补丁号",
			"reason": "漏洞原因",
		},
	},

	// 告警事件
	def.ALERT: {
		TableName: def.ALERT_SCOURSE_DATA_TABLENAME,
		CustomColumn: map[string]string{
			"event_time":              "时间",
			"client_name":             "计算机名",
			"client_ip":               "IP地址",
			"client_mac":              "MAC地址",
			"client_groupname":        "分组",
			"ccid":                    "所属控制中心",
			"client_os":               "操作系统",
			"client_third_login_user": "实名账号",
			"type":                    "事件类型", // 业务特有字段
			"format_content":          "详细内容", // 业务特有字段
			// "":                        "实名姓名",
		},
		OptionalColumn: map[string]string{
			"content":  "事件详情",
			"datetime": "发生时间",
			"account":  "告警账号",
		},
	},

	// 审计事件
	def.AUDIT: {
		TableName: "skylar_scascade.audit",
		CustomColumn: map[string]string{
			"event_time":              "时间",
			"client_name":             "计算机名",
			"client_ip":               "IP地址",
			"client_mac":              "MAC地址",
			"client_groupname":        "分组",
			"ccid":                    "所属控制中心",
			"client_os":               "操作系统",
			"client_third_login_user": "实名账号",
			"type":                    "类型", // 业务特有字段
			"content":                 "事件详情",
			"format_content":          "详细信息", // 业务特有字段
			// "":                        "实名姓名",
		},
		OptionalColumn: map[string]string{
			"account": "告警账号",
		},
	},

	// 资产汇总
	def.ASSET: {
		TableName: def.ASSET_SCOURSE_DATA_TABLENAME,
		CustomColumn: map[string]string{
			"id":                 "id",
			"client_name":        "计算机名",
			"client_ip":          "IP地址",
			"client_mac":         "MAC地址",
			"client_group_name":  "分组",
			"client_group_path":  "分组全路径",
			"ccid":               "所属控制中心",
			"client_os":          "操作系统",
			"client_login_user":  "实名账号",
			"ext_main_ver":       "主程序版本",
			"ext_virus_lib_date": "病毒库时间",
			"ext_leaklib_ver":    "补丁库版本",
		},
		OptionalColumn: map[string]string{
			"last_time":                           "最后在线时间",
			"nac_user_user_name":                  "用户名称",
			"nac_user_full_name":                  "实名姓名",
			"client_os_domain_name":               "登录域",
			"client_type":                         "系统平台", // 特殊处理
			"client_os_small_version_edition_id":  "Windows10版本号",
			"client_hardware_summary_device_type": "计算机类型",
			"client_hardware_summary_description": "计算机型号",
			"hardware_summary_cpu":                "CPU",
			"hardware_summary_memory":             "内存",
			"hardware_summary_harddisk":           "硬盘",
			"hardware_summary_displaycard":        "显卡",
			"hardware_summary_monitor":            "显示器",
			"hardware_harddisk_serial_number":     "硬盘序列号",
			"hardware_summary_serial_number":      "SN序列号",
			"os_lang":                             "系统语言",
			"os_osspa":                            "激活状态",
			"os_install_date":                     "系统安装时间",
			"hardware_summary_device_use":         "设备用途",
			"hardware_summary_username":           "使用人",
			"hardware_summary_user_number":        "工号",
			"hardware_summary_mobile":             "手机",
			"hardware_summary_email":              "邮箱",
			"hardware_summary_location":           "物理位置",
			"hardware_summary_telephone":          "座机",
			"hardware_summary_memo":               "备注",
			"client_hardware_cpu_core_count":      "CPU核心数",
			"client_hardware_cpu_frequency":       "主频",
			"client_hardware_harddisk_size":       "硬盘大小",
			"client_hardware_memory_size":         "内存大小",
			"client_hardware_monitor_size":        "显示器尺寸",
			// "client_hardware_summary_device_type":    "设备类型", // 字段重复 client_hardware_summary_device_type 计算机类型
			// "":                                    "使用部门", // 字段重复 client_groupname 分组
		},
	},
}

func TestBuildCustomColumnsConfigFile(t *testing.T) {
	path, err := getConfigPath("CustomColsConf")
	if err != nil {
		t.Log(err)
	}
	writeJsonConfig(path)
}

func getConfigPath(code string) (string, error) {
	getwd, err := os.Getwd()
	if err != nil {
		return "", err
	}
	path := getwd

	switch code {
	case "CustomColsConf":
		path = "../../../config/custom_cols.json"
	}

	return path, nil
}

func writeJsonConfig(filePath string) {
	bytes, err := json.Marshal(defaultCustomConfigMap)
	if err != nil {
		fmt.Println(err)
	}

	if err := ioutil.WriteFile(filePath, bytes, 777); err != nil {
		log.Println(err.Error())
	}
}
