package tools

import (
	"time"
	"tq-scascade-report/pkg/def"
)

// 获取最近十天时间范围
func GetPastTenDayDateRange(anchor time.Time) (start time.Time, end time.Time) {
	start = anchor.AddDate(0, 0, -9)
	end = anchor
	return
}

// 获取上周时间范围
func GetLastWeekDateRange(anchor time.Time) (start time.Time, end time.Time) {

	//now := time.Now()
	now := anchor
	offset := int(time.Monday - now.Weekday())
	if offset > 0 {
		offset = -6
	}
	start = time.Date(now.Year(), now.Month(), now.Day(), 0, 0, 0, 0, time.Local).AddDate(0, 0, offset-7)
	end = start.AddDate(0, 0, 7)
	return
}

// 获取本月时间范围
func GetThisMonthDateRange(anchor time.Time) (start time.Time, end time.Time) {

	//now := time.Now()
	now := anchor
	year, month, _ := now.Date()
	thisMonth := time.Date(year, month, 1, 0, 0, 0, 0, time.Local)
	start = thisMonth
	end = start.AddDate(0, 1, -1)
	return
}

// 获得当前季度的初始和结束日期
func GetThisQuarterDateRange(anchor time.Time) (start time.Time, end time.Time) {
	//now := time.Now()
	now := anchor
	year := now.Format("2006")
	month := int(time.Now().Month())
	var (
		firstOfQuarter string
		lastOfQuarter  string
	)

	if month >= 1 && month <= 3 {
		//1月1号
		firstOfQuarter = year + "-01-01 00:00:00"
		lastOfQuarter = year + "-03-31 23:59:59"
	} else if month >= 4 && month <= 6 {
		firstOfQuarter = year + "-04-01 00:00:00"
		lastOfQuarter = year + "-06-30 23:59:59"
	} else if month >= 7 && month <= 9 {
		firstOfQuarter = year + "-07-01 00:00:00"
		lastOfQuarter = year + "-09-30 23:59:59"
	} else {
		firstOfQuarter = year + "-10-01 00:00:00"
		lastOfQuarter = year + "-12-31 23:59:59"
	}
	start, _ = time.Parse(def.YYYYMMDDHHSSmm, firstOfQuarter)
	end, _ = time.Parse(def.YYYYMMDDHHSSmm, lastOfQuarter)
	return
}

// 获取本年是时间范围
func GetThisYearDateRange(anchor time.Time) (start time.Time, end time.Time) {
	//now := time.Now()
	now := anchor
	year := now.Year()

	start = time.Date(year, 1, 1, 0, 0, 0, 0, time.Local)
	end = time.Date(year, 12, 1, 0, 0, 0, 0, time.Local)
	return
}
