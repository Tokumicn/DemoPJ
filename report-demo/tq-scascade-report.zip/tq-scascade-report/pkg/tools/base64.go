package tools

import "encoding/base64"

func Base64Decode(str string) (string, error) {
	decodeBytes, err := base64.StdEncoding.DecodeString(str)
	if err != nil {
		return "", err
	}

	return string(decodeBytes), nil
}
