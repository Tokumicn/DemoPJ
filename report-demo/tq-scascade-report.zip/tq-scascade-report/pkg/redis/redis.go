package redis

import (
	"github.com/alicebob/miniredis/v2"
	"github.com/go-redis/redis"
	"log"
	"time"
)

var (
	RedisDB   *redis.Client
	FakeRedis *miniredis.Miniredis
)

type Config struct {
	Addr         string `toml:"addr"`
	DB           int    `toml:"db"`
	Password     string `toml:"password"`
	DialTimeout  int    `toml:"dial_timeout"`
	ReadTimeout  int    `toml:"read_timeout"`
	WriteTimeout int    `toml:"write_timeout"`
	IdleTimeout  int    `toml:"idle_timeout"`
	PoolSize     int    `toml:"pool_size"`
	PoolTimeout  int    `toml:"pool_timeout"`
}

func InitFakeRedis() {
	var err error
	// 初始化测试
	FakeRedis, err = miniredis.Run()
	if err != nil {
		panic(err)
	}

	InitRedis(&Config{
		Addr: FakeRedis.Addr(),
	})
}

func InitRedis(config *Config) {
	options := redisOptions(config)
	RedisDB = redis.NewClient(options)

	statusCmd := RedisDB.Ping()
	if statusCmd.Err() != nil {
		panic(statusCmd.Err())
	}

	log.Println("redis init success.")
}

func redisOptions(c *Config) *redis.Options {
	return &redis.Options{
		Addr:         c.Addr,
		DB:           c.DB,
		Password:     c.Password,
		DialTimeout:  time.Duration(c.DialTimeout) * time.Second,
		ReadTimeout:  time.Duration(c.ReadTimeout) * time.Second,
		WriteTimeout: time.Duration(c.WriteTimeout) * time.Second,
		IdleTimeout:  time.Duration(c.IdleTimeout) * time.Second,
		PoolSize:     c.PoolSize,
		PoolTimeout:  time.Duration(c.PoolTimeout) * time.Second,
	}
}

func Close() {
	if RedisDB == nil {
		return
	}

	err := RedisDB.Close()
	if err != nil {
		log.Printf("close redis err: %s", err.Error())
	}
}
