package clickhouse

import (
	"testing"
)

func Test_buildDataSourceStr(t *testing.T) {
	config := &Config{
		Host:         "10.44.203.4:9997",
		Debug:        true,
		User:         "",
		Password:     "",
		DBName:       "click",
		MaxIdle:      1,
		MaxOpen:      2,
		MaxLife:      60,
		ReadTimeout:  120,
		WriteTimeout: 120,
		AltHosts:     "",
	}

	targetStr := `tcp://10.44.203.4:9997?username=&password=&debug=true&database=click&read_timeout=120&write_timeout=120`

	str := buildDataSourceStr(config)
	t.Log(str)
	if targetStr != str {
		t.Fatal()
	}
}
