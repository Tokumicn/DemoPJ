package clickhouse

import (
	"fmt"
	"git-biz.qianxin-inc.cn/eps/skylar/apps/libs/tianqing.git/logs"
	"time"

	_ "github.com/ClickHouse/clickhouse-go"
	"github.com/jmoiron/sqlx"
)

const DriverName = "clickhouse"

var (
	clickHPool *Pool
)

type DB = sqlx.DB

type Pool struct {
	ClickHouse *DB
}

type Config struct {
	Host         string `toml:"host"` // Host:Port
	User         string `toml:"user"`
	Password     string `toml:"password"`
	DBName       string `toml:"dbName"`
	MaxIdle      int    `toml:"max_idle"`
	MaxOpen      int    `toml:"max_open"`
	MaxLife      int    `toml:"max_life"` //秒
	Debug        bool   `toml:"debug"`
	ReadTimeout  int    `toml:"read_timeout"`  // 秒
	WriteTimeout int    `toml:"write_timeout"` // 秒
	AltHosts     string `toml:"alt_hosts"`     // 作为负载的其他机器
}

func ClickHouseInit(conf *Config) {

	newPool, err := newPool(conf)
	if err != nil {
		panic(err)
	}
	clickHPool = newPool
}

func GetClickHouseDB() *DB {
	return clickHPool.ClickHouse
}

func Close() {
	if clickHPool == nil || clickHPool.ClickHouse == nil {
		return
	}

	err := clickHPool.ClickHouse.Close()
	if err != nil {
		logs.Errorf("close click house connection err: %s", err.Error())
	}
}

func newPool(conf *Config) (*Pool, error) {
	pool := &Pool{}

	db, err := connect(conf)
	if err != nil {
		return nil, fmt.Errorf("init clickhouse connect host:%s err:%s", conf.Host, err.Error())
	}

	pool.ClickHouse = db

	return pool, nil
}

func connect(conf *Config) (*sqlx.DB, error) {

	dst := buildDataSourceStr(conf)

	conn, err := sqlx.Open(DriverName, dst)
	if err != nil {
		return nil, err
	}

	conn.SetMaxIdleConns(conf.MaxIdle)
	conn.SetMaxOpenConns(conf.MaxOpen)
	conn.SetConnMaxLifetime(time.Duration(conf.MaxLife) * time.Second)

	err = conn.Ping()
	if err != nil {
		return nil, err
	}

	return conn, nil
}

func buildDataSourceStr(conf *Config) string {
	dst := fmt.Sprintf("tcp://%s?username=%s&password=%s",
		conf.Host, conf.User, conf.Password)

	if conf.Debug {
		dst += "&debug=true"
	} else {
		dst += "&debug=false"
	}

	if len(conf.DBName) > 0 {
		dst += fmt.Sprintf("&database=%s", conf.DBName)
	}

	if conf.ReadTimeout > 0 {
		dst += fmt.Sprintf("&read_timeout=%d", conf.ReadTimeout)
	}

	if conf.WriteTimeout > 0 {
		dst += fmt.Sprintf("&write_timeout=%d", conf.WriteTimeout)
	}

	if len(conf.AltHosts) > 0 {
		dst += fmt.Sprintf("&alt_hosts=%s", conf.AltHosts)
	}

	logs.Debugf("clickhouse connection config : ", dst)

	return dst
}
