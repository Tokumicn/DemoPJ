package executor

import (
	"encoding/json"
	"fmt"
	"git-biz.qianxin-inc.cn/eps/skylar/apps/libs/tianqing.git/logs"
	"git-biz.qianxin-inc.cn/eps/skylar/apps/libs/tianqing.git/utils"
	"time"
	"tq-scascade-report/pkg/dao"
	"tq-scascade-report/pkg/job_common"
)

// 任务执行器
// 1. 做并行查询的流量控制
// 2. Sql语句的构建
// 3.
type Executor struct {
}

var (
	G_executor *Executor
)

func InitExecutor() {
	G_executor = &Executor{}
}

// 执行一个任务
// 采用同步方式，因此对于长时间无法结束的任务，同步方式可以有效的防止同种任务多次触发
// INFO: 该执行过程，由于汇总报表由多次查询和存储过程组成，如果失败需要前端以默认形式展示
func (e *Executor) ExecuteJob(info *job_common.JobExecuteInfo) []error {

	startTime := info.Job.StartTime
	endTime := info.Job.EndTime

	var (
		resultId int64
		err      error
	)
	exeErrors := []error{}
	// 覆盖旧数据
	if info.Job.DataCover {
		resultId, err = checkResultExistAndReturnId(info.Job.Id)
		if err != nil {
			logs.Errorf("[checkResultExistAndReturnId] info:[%#v] err:[%s]", info, err.Error())
			exeErrors = append(exeErrors, err)
			return exeErrors
		}

		// 如果获取不到result 则需要新建相当于无需覆盖
		if resultId <= 0 {
			resultId, err = createExecutorResult(info)
			if err != nil {
				logs.Errorf("[checkResultExistAndReturnId] info:[%#v] err:[%s]", info, err.Error())
				exeErrors = append(exeErrors, err)
				return exeErrors
			}
		} else {
			err := dao.DeleteReportDetailData(resultId)
			if err != nil {
				logs.Errorf("[checkResultExistAndReturnId] info:[%#v] err:[%s]", info, err.Error())
				exeErrors = append(exeErrors, err)
				return exeErrors
			}
		}

	} else {
		// 不覆盖则新产生一条结果信息
		// 触发执行结束事件，记录相关结果信息
		resultId, err = createExecutorResult(info)
		if err != nil {
			logs.Errorf("[createExecutorResult] info:[%#v] err:[%s]", info, err.Error())
			exeErrors = append(exeErrors, err)
			return exeErrors
		}
	}

	for _, exec := range info.Job.ReportExecs {
		for _, subReport := range exec.SubReport {
			// 填入时间范围
			subReport.QuerySourceConfig.Args["startTime"] = startTime
			subReport.QuerySourceConfig.Args["endTime"] = endTime

			// 获取查询结果
			err := subReport.Query()
			if err != nil {
				logs.Errorf("task[id: %d] [name: %s] execut failed. [err: %s]",
					info.Job.Id,
					info.Job.JobName,
					err.Error())
				exeErrors = append(exeErrors, err)
			}

			// 更新结果Id,为后续数据关联提供依据
			subReport.DataConvertConfig.ResultId = resultId

			// 整理数据
			err = subReport.Convert()
			if err != nil {
				logs.Error(err)
				exeErrors = append(exeErrors, err)
				continue
			}

			// 存储查询结果
			err = subReport.Save()
			if err != nil {
				logs.Error(err)
				exeErrors = append(exeErrors, err)
				continue
			}
		}
	}

	return exeErrors
}

func checkResultExistAndReturnId(taskId int64) (int64, error) {

	dto := &dao.TaskResult{
		TaskId: taskId,
	}

	taskResults, err := dto.GetByTaskId()
	if err != nil {
		return 0, err
	}

	if len(taskResults) <= 0 {
		return 0, nil
	}

	return taskResults[0].Id, nil

}

func createExecutorResult(info *job_common.JobExecuteInfo) (int64, error) {

	if info.Job == nil {
		return -1, fmt.Errorf("JobExecuteInfo.Job is nil")
	}

	if info.Job.ReportExecs == nil {
		return -1, fmt.Errorf("JobExecuteInfo.Job.ReportExec is nil")
	}

	// 获取CCIDsTree
	taskDTO := &dao.CronQueryTask{
		Id: info.Job.Id,
	}

	cronQueryTask, err := taskDTO.Get()
	if err != nil {
		return -1, err
	}

	var conditionStr = ""
	conditionStr, err = buildCondition(cronQueryTask, info.Job.StartTime, info.Job.EndTime)
	if err != nil {
		logs.Errorf("[buildCondition] json marshal err: %s", err.Error())
	}

	dto := &dao.TaskResult{
		TaskId:        info.Job.Id,
		TaskName:      info.Job.TaskName,
		CronExpr:      info.Job.CronExpr,
		Condition:     conditionStr,
		PlanStartTime: &utils.JSONTime{T: info.PlanTime},
		RealStartTime: &utils.JSONTime{T: info.RealTime},
		FinishTime:    &utils.JSONTime{T: time.Now()},
		RawTree:       cronQueryTask.RawTree,
	}

	newId, err := dto.Create()
	if err != nil {
		return -1, err
	}

	return newId, nil
}

func buildCondition(task *dao.CronQueryTask, start, end string) (string, error) {

	conditionShoot := &dao.Condition{
		TopCCId:     task.TopCCId,
		Business:    task.Business,
		ReportTypes: task.ReportTypes,
		TimeScale:   task.TimeScale,
		StartTime:   start,
		EndTime:     end,
	}

	qCondition, err := json.Marshal(conditionShoot)
	if err != nil {
		return "", err
	}
	return string(qCondition), nil
}
