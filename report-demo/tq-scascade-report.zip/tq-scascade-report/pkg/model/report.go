package model

import "git-biz.qianxin-inc.cn/eps/skylar/apps/libs/tianqing.git/utils"

const (
	REPORT_STATUS_NORMAL  = "Normal"  // 正常可以操作
	REPORT_STATUS_RUNNING = "Running" //正在生成
)

// 报表
type ReportTaskRequest struct {
	Id int64 `json:"taskId"`
	// 查询通用条件
	Name        string          `json:"name"`
	TopCCId     string          `json:"topCCId"`     // 父节点CCId
	Business    string          `json:"business"`    // 所属业务
	ReportTypes string          `json:"reportTypes"` // 报表类型a
	DataCover   bool            `json:"dataCover"`   // 是否覆盖
	TimeScale   string          `json:"timeScale"`
	StartTime   *utils.JSONTime `json:"startTime"`
	EndTime     *utils.JSONTime `json:"endTime"`
	TimeRange   string          `json:"timeRange"` // 时间范围
	// 生成周期相关配置
	CronType string `json:"cronType"` // 时间周期类型： 天、周、月 daily/weekly/monthly
	Day      int    `json:"day"`      // 日期详情：1~30(周一到周日、日期1号到30号)
	Hours    int    `json:"hours"`    // 0~23
	Minutes  int    `json:"minutes"`  // 0~59
}

type ReportTaskViewModel struct {
	Id             int64  `json:"id"`
	Name           string `json:"name"`           // 报表名(展示用)
	JobName        string `json:"jobName"`        // 任务名
	Business       string `json:"business"`       // 所属业务
	ReportTypes    string `json:"reportTypes"`    // 报表类型
	IsCyclicity    bool   `json:"isCyclicity"`    // 是否是周期性报表
	BuildCycleDesc string `json:"buildCycleDesc"` // 生成周期
	GeneratedTime  string `json:"generatedTime"`  // 生成时间
	DataCover      bool   `json:"dataCover"`      // 覆盖原报表
	ExecStatus     bool   `json:"execStatus"`     // 运行状态
}

// 请求结构体
type TaskIdRequest struct {
	TaskId int64 `json:"taskId"`
}

type TaskNameRequest struct {
	TaskName string `json:"name"`
}

type ListPagingRequest struct {
	TaskName       string `json:"taskName"`
	PageSize       int64  `json:"pageSize"` // 当前页容量 默认20
	Current        int64  `json:"current"`  // 当前页码 默认1
	Order          int64  `json:"order"`    // 1正序/0自定义/-1逆序
	OrderCondition string `json:"ordcond"`  // order=0时有效排序字段
}
