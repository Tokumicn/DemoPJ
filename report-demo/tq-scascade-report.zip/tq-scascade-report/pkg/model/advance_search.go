package model

import (
	"git-biz.qianxin-inc.cn/eps/skylar/apps/libs/tianqing.git/utils"
	"tq-scascade-report/service/log_details/security"
)

type BasicSearch struct {
	CCIDs     []string
	StartTime *utils.JSONTime
	EndTime   *utils.JSONTime
	AuditType string // 只针对审计日志查询时使用
}

type PagingArgs struct {
	DBType   string
	Current  int64
	PageSize int64
}

type OrderArgs struct {
	Order          int64
	OrderCondition string
}

type AdvancedSearch struct {
	BusinessCode   string
	Select         string
	Group          string
	OrderArgs      *OrderArgs
	PagingArgs     *PagingArgs
	BasicSearch    *BasicSearch // 基础查询
	AdvancedQuery  *Query       // 高级查询
	SecurityConfig *security.ColumnsConfig
}

type Condition struct {
	Op    string      `json:"op"`
	Key   string      `json:"key"`
	Value interface{} `json:"value"`
	//ParamKey   string
	//ParamValue interface{}
}

type Query struct {
	Conditions       []*Condition `json:"conditions"`
	RelationTemplate string       `json:"relationTlp"`
}
