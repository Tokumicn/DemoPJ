package model

// 高级搜索模板
type GetConditionTemplateRequest struct {
	BusinessCode string `json:"business"`
}

type DeleteConditionTemplateRequest struct {
	TemplateId int64 `json:"id"`
}

type ConditionTemplateViewModel struct {
	Id               int64        `json:"id"`
	Name             string       `json:"name"` // 展示名
	BusinessCode     string       `json:"business"`
	Conditions       []*Condition `json:"conditions"`
	RelationTemplate string       `json:"relationTlp"`
}

type UpdateConditionTemplateRequest struct {
	Id               int64        `json:"id"`
	Name             string       `json:"name"` // 展示名
	BusinessCode     string       `json:"business"`
	Conditions       []*Condition `json:"conditions"`
	RelationTemplate string       `json:"relationTlp"`
}
