package model

type QueryFieldViewModel struct {
	Id            int64  `json:"id"`
	BusinessCode  string `json:"business"`      // 所属业务
	DisplayName   string `json:"displayName"`   // 展示名
	FieldName     string `json:"filedName"`     // 筛选Key
	Operation     string `json:"operation"`     // 可选操作 JSON:{ "key": ">", "value": "大于" }, {...}, ...
	OptionalValue string `json:"optionalValue"` // 可选值   JSON:{ "key": 1, "value": "笔记本" }, {...}, ...
}
