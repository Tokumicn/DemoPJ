package model

type CustomColumnViewModel struct {
	Id             int64  `json:"id"`
	BusinessCode   string `json:"business"` // 所属业务标识
	AllColumns     map[string]string
	CustomColumn   []string `json:"customColumn"`   // 自定义显示列
	OptionalColumn []string `json:"optionalColumn"` // 可选自定义列
}

// 自定义列
type GetCustomColumnRequest struct {
	BusinessCode string `json:"business"` // 业务标识
}

type UpdateCustomColumnRequest struct {
	BusinessCode   string   `json:"business"`       // 所属业务标识
	CustomColumn   []string `json:"customColumn"`   // 自定义显示列
	OptionalColumn []string `json:"optionalColumn"` // 可选自定义列
}

type CustomColumn struct {
}
