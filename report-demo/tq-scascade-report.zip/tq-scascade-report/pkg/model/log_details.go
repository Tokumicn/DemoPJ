package model

import (
	"git-biz.qianxin-inc.cn/eps/skylar/apps/libs/tianqing.git/utils"
)

// 高级搜索条件详情
type GetFilterFieldsConfigRequest struct {
	BusinessCode string `json:"business"`
}

// 查询日志详情
type QueryLogDetailsRequest struct {
	BusinessCode   string          `json:"business"` // 业务标识
	TopCCId        string          `json:"topCCId"`  // 控制中心父节点
	CCIds          []string        `json:"-"`
	StartTime      *utils.JSONTime `json:"startTime"`     // 查询开始时间
	EndTime        *utils.JSONTime `json:"endTime"`       // 查询结束时间
	PageSize       int64           `json:"pageSize"`      // 当前页容量 默认20
	Current        int64           `json:"current"`       // 当前页码 默认1
	Order          int64           `json:"order"`         // 1正序/0自定义/-1逆序
	OrderCondition string          `json:"ordcond"`       // order=0时有效排序字段
	AdvanceSearch  *AdvanceSearch  `json:"advanceSearch"` // 高级搜索条件
	Ext            *ExtQuery       `json:"ext"`

	Uid int64 `json:"uid"`
}

// 针对部分业务的特殊查询条件
type ExtQuery struct {
	AuditType string `json:"auditType"`
}

type AdvanceSearch struct {
	Select           string       `json:"select"`
	Conditions       []*Condition `json:"conditions"`
	RelationTemplate string       `json:"relationTlp"`
}

type LogDetailViewModel struct {
	Total  int                      `json:"total"`
	Detail []map[string]interface{} `json:"detail"`
}
