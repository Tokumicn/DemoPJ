package model

type CCIDNode struct {
	Id   int64  `json:"id"`
	PId  int64  `json:"pid"`
	Name string `json:"name"`
	CCID string `json:"ccid"`
}
