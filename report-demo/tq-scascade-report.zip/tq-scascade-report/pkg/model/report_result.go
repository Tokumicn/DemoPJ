package model

type ReportResultViewModel struct {
	Id          int64  `json:"id"`
	TaskName    string `json:"taskName"`    // 报表名
	Business    string `json:"business"`    // 所属业务
	IsCyclicity bool   `json:"isCyclicity"` // 报表类型: true:周期报表  false:非周期报表
	FinishTime  string `json:"finishTime"`  // 生成时间
}

type ReportDetailViewModel struct {
	Total  int             `json:"total"`
	Detail []*ReportDetail `json:"detail"`
}

type ReportDetail struct {
	Code string                   `json:"type"`
	Data []map[string]interface{} `json:"report"`
}

// 请求结构体
type ResultIdRequest struct {
	ResultId int64 `json:"resultId"`
}

type SummarizeResultQueryRequest struct {
	ResultId int64  `json:"resultId"`
	TopCCId  string `json:"topCCId"` // 父级CCId
	Tpl      string `json:"tpl"`
}

type ResultQueryRequest struct {
	ResultId       int64    `json:"resultId"`
	TopCCId        string   `json:"topCCId"`
	CCIds          []string `json:"-"`
	ReportType     string   `json:"reportType"`
	WhereArgs      string   `json:"whereArgs"`
	PageSize       int64    `json:"pageSize"` // 当前页容量 默认20
	Current        int64    `json:"current"`  // 当前页码 默认1
	Order          int64    `json:"order"`    // 1正序/-1逆序
	OrderCondition string   `json:"ordcond"`  // 有效排序字段
}

type ResultExportQueryRequest struct {
	ResultId       int64    `json:"resultId"`
	TopCCId        string   `json:"topCCId"`
	CCIds          []string `json:"-"`
	ReportTypes    string   `json:"reportTypes"`
	WhereArgs      string   `json:"whereArgs"`
	PageSize       int64    `json:"pageSize"` // 当前页容量 默认20
	Current        int64    `json:"current"`  // 当前页码 默认1
	Order          int64    `json:"order"`    // 1正序/-1逆序
	OrderCondition string   `json:"ordcond"`  // 有效排序字段
	Uid            int64    `json:"uid"`
	Tpl            string   `json:"-"`
}
