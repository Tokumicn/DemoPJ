package job_common

import (
	"context"
	"errors"
	"fmt"
	"git-biz.qianxin-inc.cn/eps/skylar/apps/libs/tianqing.git/logs"
	"github.com/gorhill/cronexpr"
	"math/rand"
	"time"
	"tq-scascade-report/pkg/def"
	"tq-scascade-report/pkg/tools"
	"tq-scascade-report/service/report"
)

func init() {
	rand.Seed(time.Now().UnixNano())
}

// 任务数据类型结构体
type Job struct {
	Id              int64
	TaskName        string `json:"taskName"`
	JobName         string `json:"name"`     //  任务名
	CronExpr        string `json:"cronExpr"` // cron表达式
	CronDescription string // 生成时间文字描述

	ReportExecs []*report.ReportExec
	// 业务相关
	DataCover bool   // 新执行结果是否覆盖原结果
	TimeRange string // 查询时间的范围标识
	StartTime string
	EndTime   string
}

// 变化事件
type JobEvent struct {
	Id          int64
	JobName     string
	TaskName    string
	EventType   int                  //  SAVE, DELETE
	ReportExecs []*report.ReportExec // 报表执行器

	CronType  string // 时间周期类型： 天、周、月 daily/weekly/monthly
	Day       int    // 日期详情：1~30(周一到周日、日期1号到30号)
	Hours     int    // 0~23
	Minutes   int    // 0~59
	DataCover bool   // 新执行结果是否覆盖原结果
	TimeRange string
	StartTime string
	EndTime   string
}

type CronConfig struct {
	// 生成周期相关配置
	CronType string // 时间周期类型： 天、周、月 daily/weekly/monthly
	Day      int    // 日期详情：1~30(周一到周日、日期1号到30号)
	Hours    int    // 0~23
	Minutes  int    // 0~59
}

// 任务调度计划
type JobSchedulePlan struct {
	Job      *Job                 // 要调度的任务信息
	Expr     *cronexpr.Expression // 解析好的cronexpr表达式
	NextTime time.Time            // 下次调度时间
}

// 任务执行状态
type JobExecuteInfo struct {
	Job        *Job               // 任务信息
	PlanTime   time.Time          // 理论上的调度时间
	RealTime   time.Time          // 实际的调度时间
	CancelCtx  context.Context    // 执行任务的context
	CancelFunc context.CancelFunc // 用于取消未执行完成的cancel函数
}

// 任务执行结果
type JobExecuteResult struct {
	ExecuteInfo *JobExecuteInfo // 执行状态
	Message     string          // 脚本输出
	Err         error           // 脚本错误原因
	StartTime   time.Time       // 启动时间
	EndTime     time.Time       // 结束时间
}

// 任务执行日志
type JobLog struct {
	JobName      string `json:"jobName"`      // 任务名字
	Err          string `json:"err"`          // 错误原因
	PlanTime     int64  `json:"planTime"`     // 计划开始时间
	ScheduleTime int64  `json:"scheduleTime"` // 实际调度时间
	StartTime    int64  `json:"startTime"`    // 任务执行开始时间
	EndTime      int64  `json:"endTime"`      // 任务执行结束时间
}

func JobNameGenerator() string {
	n := time.Now().UnixNano()
	//n := rand.Int63n(999999)
	return fmt.Sprintf("CJ%d", n)
}

func CalcCronPlanByType(conf *CronConfig) (*cronexpr.Expression, string, time.Time, error) {
	var tempCronExpr string
	switch conf.CronType {
	case def.DAILY:
		tempCronExpr = fmt.Sprintf("0 %d %d * * * *", conf.Minutes, conf.Hours)
	case def.WEEKLY:
		tempCronExpr = fmt.Sprintf("0 %d %d * * %d *", conf.Minutes, conf.Hours, conf.Day)
	case def.MONTHLY:
		tempCronExpr = fmt.Sprintf("0 %d %d %d * * *", conf.Minutes, conf.Hours, conf.Day)
	case def.NOW: // 立即执行的任务定时触发时长设置为2099年，仅通过手动触发执行
		tempCronExpr = fmt.Sprintf("* * * * * * 2099")
	default:
		logs.Error("CronExpr error.")
	}

	expression, err := cronexpr.Parse(tempCronExpr)
	if err != nil {
		return nil, "", time.Time{}, err
	}

	now := time.Now()
	next := expression.Next(now)

	return expression, tempCronExpr, next, nil
}

//{Seconds} {Minutes} {Hours} {Day of Month} {Month} {Day of Week} {Year}
// 天: `0 Minutes Hours * * * *`
// 周: `0 Minutes Hours * * {Week} *`
// 月: `0 Minutes Hours * {Month}} * *`
func CreateJobPlan(jobEvent *JobEvent) (*JobSchedulePlan, error) {

	if jobEvent == nil {
		return nil, errors.New("jobEvent is nil.")
	}

	expression, cronExpr, nextPlanTime, err := CalcCronPlanByType(&CronConfig{
		CronType: jobEvent.CronType,
		Day:      jobEvent.Day,
		Hours:    jobEvent.Hours,
		Minutes:  jobEvent.Minutes,
	})
	if err != nil {
		return nil, err
	}

	formatDes := nextPlanTime.Format(def.YYYYMMDDHHSSmm)

	jobPlan := &JobSchedulePlan{
		Job: &Job{
			Id:              jobEvent.Id,
			JobName:         jobEvent.JobName,
			TaskName:        jobEvent.TaskName,
			CronExpr:        cronExpr,
			CronDescription: formatDes,
			ReportExecs:     jobEvent.ReportExecs,
			DataCover:       jobEvent.DataCover,
			TimeRange:       jobEvent.TimeRange,
		},
		Expr:     expression,
		NextTime: nextPlanTime,
	}

	if jobEvent.CronType == def.NOW {
		nextPlanTime = time.Now()
	}

	// 计算查询时间范围
	newStart, newEnd, err := calcQueryTimeRange(jobEvent.TimeRange, nextPlanTime, jobEvent.StartTime, jobEvent.EndTime)
	if err != nil {
		logs.Errorf("新建查询时间范围失败.[taskName: %s] [JobName: %s] [TimeRange: %s] [Start: %s] [End: %s] [NextTime: %s] ",
			jobEvent.TaskName, jobEvent.JobName, jobEvent.TimeRange, jobEvent.StartTime, jobEvent.EndTime, nextPlanTime.Format(def.YYYYMMDDHHSSmm))
	} else {
		jobPlan.Job.StartTime = newStart
		jobPlan.Job.EndTime = newEnd
	}

	return jobPlan, nil
}

func BuildJobExecuteResult(jobExecuteInfo *JobExecuteInfo, err error) *JobExecuteResult {
	return &JobExecuteResult{
		ExecuteInfo: jobExecuteInfo,
		Message:     err.Error(),
		Err:         err,
		StartTime:   jobExecuteInfo.RealTime,
		EndTime:     time.Now(),
	}
}

// 构造执行状态信息
func BuildJobExecuteInfo(jobSchedulePlan *JobSchedulePlan) (jobExecuteInfo *JobExecuteInfo) {

	nextExecuteTime := jobSchedulePlan.NextTime

	jobExecuteInfo = &JobExecuteInfo{
		Job:      jobSchedulePlan.Job,
		PlanTime: nextExecuteTime, // 计算调度时间
		RealTime: time.Now(),      // 真实调度时间
	}
	jobExecuteInfo.CancelCtx, jobExecuteInfo.CancelFunc = context.WithCancel(context.TODO())
	return
}

// 计算查询需要的时间范围
func calcQueryTimeRange(timeRange string, planStartTime time.Time, start, end string) (string, string, error) {

	var (
		startTime time.Time
		endTime   time.Time
	)

	switch timeRange {
	case def.PastTenDayRange: // 最近十天
		startTime, endTime = tools.GetPastTenDayDateRange(planStartTime)
	case def.LastWeekRange: // 上周
		startTime, endTime = tools.GetLastWeekDateRange(planStartTime)
	case def.MonthRange: // 本月
		startTime, endTime = tools.GetThisMonthDateRange(planStartTime)
	case def.QuarterRange: // 本季度
		startTime, endTime = tools.GetThisQuarterDateRange(planStartTime)
	case def.YearRange: // 本年
		startTime, endTime = tools.GetThisYearDateRange(planStartTime)
	case def.CustomRange: // 自定义
		return start, end, nil
	default:
		return "", "", fmt.Errorf("timeRange: %s 参数有误", timeRange)
	}

	return startTime.Format(def.YYYYMMDDHHSSmm), endTime.Format(def.YYYYMMDDHHSSmm), nil
}

func ResetJobQueryTimeRange(jobPlan *JobSchedulePlan) {
	// 更新查询需要的搜索时间
	newStart, newEnd, err := calcQueryTimeRange(jobPlan.Job.TimeRange, jobPlan.NextTime, jobPlan.Job.StartTime, jobPlan.Job.EndTime)
	if err != nil {
		logs.Errorf("更新查询时间范围失败. [JobName: %s] [TimeRange: %s] [Start: %s] [End: %s] [NextTime: %s] ",
			jobPlan.Job.JobName, jobPlan.Job.TimeRange, jobPlan.Job.StartTime, jobPlan.Job.EndTime, jobPlan.NextTime.Format(def.YYYYMMDDHHSSmm))
	} else {
		jobPlan.Job.StartTime = newStart
		jobPlan.Job.EndTime = newEnd
	}
}
