package postgres

import (
	"errors"
	"fmt"
	"git-biz.qianxin-inc.cn/eps/skylar/apps/libs/tianqing.git/logs"
	"gorm.io/gorm"
	"sync"
	"time"
	"tq-scascade-report/pkg/tools"

	"github.com/jmoiron/sqlx"
	_ "github.com/lib/pq"
)

const DriverName = "postgres"

var (
	pgPools       map[string]*Pool
	defaultDBName string
	lock          sync.RWMutex
)

// ErrRecordNotFound 查找结果为空的错误字符串
var ErrRecordNotFound = gorm.ErrRecordNotFound

type DB = sqlx.DB
type ORM = gorm.DB

type Pool struct {
	PostgresDB  *DB
	PostgresORM *ORM
}

type Config struct {
	Host            string `toml:"host"`
	Port            string `toml:"port"`
	User            string `toml:"user"`
	Password        string `toml:"password"`
	DBName          string `toml:"dbName"`
	ApplicationName string `toml:"appName"`
	MaxIdle         int    `toml:"max_idle"`
	MaxOpen         int    `toml:"max_open"`
	MaxLife         int    `toml:"max_life"` //秒
	Debug           bool   `toml:"debug"`
	Mock            bool   `toml:"mock"`
}

func InitPostgresDB(conf *Config) {

	pgPools = make(map[string]*Pool)

	dbNameArr := tools.SplitStrWithoutEmpty(conf.DBName, ",")
	for _, name := range dbNameArr {
		if len(name) > 0 {
			createPools(name, conf)
		}

		if len(defaultDBName) <= 0 {
			defaultDBName = name // 第一个库设置为默认库
		}
	}
}

func createPools(dbName string, conf *Config) {
	conf.DBName = dbName
	pgPool, err := newPool(conf)
	if err != nil {
		panic(err)
	}

	lock.Lock()
	defer lock.Unlock()
	pgPools[dbName] = pgPool
}

func GetDefaultPostgresDB() *DB {
	return GetPostgresDB(defaultDBName)
}

func GetPostgresDB(dbName string) *DB {
	if pgPools == nil {
		panic(errors.New("please initialize postgres pool first."))
	}

	if len(dbName) <= 0 {
		panic(errors.New("dbName is empty."))
	}

	pool, ok := pgPools[dbName]
	if !ok {
		logs.Errorf("[dbname: %s] connection does not exist.", dbName)
		return nil
	}

	return pool.PostgresDB
}

func Close() {
	if pgPools == nil || len(pgPools) <= 0 {
		return
	}

	for _, pool := range pgPools {
		if pool == nil {
			continue
		}
		err := pool.PostgresDB.Close()
		if err != nil {
			logs.Errorf("close db connection error: %s .", err.Error())
		}

		sqlDB, err := pool.PostgresORM.DB()
		if err != nil {
			logs.Errorf("get sql db connection error: %s .", err.Error())
		} else {
			err = sqlDB.Close()
			if err != nil {
				logs.Errorf("close db orm connection error: %s .", err.Error())
			}
		}
	}
	return
}

func newPool(conf *Config) (*Pool, error) {
	pool := &Pool{}

	db, err := connect(conf)
	if err != nil {
		return nil, fmt.Errorf("init postgres db connect host:%s err:%s", conf.Host, err.Error())
	}
	pool.PostgresDB = db

	orm, err := connectORM(conf)
	if err != nil {
		return nil, fmt.Errorf("init postgres db orm connect host:%s err:%s", conf.Host, err.Error())
	}
	pool.PostgresORM = orm

	return pool, nil
}

func connect(conf *Config) (*sqlx.DB, error) {

	dst := buildDataSourceStr(conf)

	conn, err := sqlx.Open(DriverName, dst)
	if err != nil {
		return nil, err
	}

	conn.SetMaxIdleConns(conf.MaxIdle)
	conn.SetMaxOpenConns(conf.MaxOpen)
	conn.SetConnMaxLifetime(time.Duration(conf.MaxLife) * time.Second)

	err = conn.Ping()
	if err != nil {
		return nil, err
	}

	return conn, nil
}

func buildDataSourceStr(conf *Config) string {

	if len(conf.Password) <= 0 {
		conf.Password = "postgres"
	}

	dst := fmt.Sprintf("host=%s port=%s user=%s password=%s dbname=%s sslmode=disable application_name=%s",
		conf.Host, conf.Port, conf.User, conf.Password, conf.DBName, conf.ApplicationName)

	logs.Debugf("postgres db connection config : ", dst)

	return dst
}
