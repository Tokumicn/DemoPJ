package postgres

import (
	"database/sql"
	"errors"
	"git-biz.qianxin-inc.cn/eps/skylar/apps/libs/tianqing.git/logs"
	pg "gorm.io/driver/postgres"
	"gorm.io/gorm"
	"time"
)

func GetDefaultPostgresORM() *ORM {
	return GetPostgresORM(defaultDBName)
}

func GetPostgresORM(dbName string) *ORM {
	if pgPools == nil {
		panic(errors.New("please initialize postgres pool first."))
	}

	if len(dbName) <= 0 {
		panic(errors.New("dbName is empty."))
	}

	pool, ok := pgPools[dbName]
	if !ok {
		logs.Errorf("[dbname: %s] connection does not exist.", dbName)
		return nil
	}

	return pool.PostgresORM
}

func connectORM(conf *Config) (*gorm.DB, error) {
	dst := buildDataSourceStr(conf)

	pgSqlConn, err := sql.Open("postgres", dst)
	if err != nil {
		return nil, err
	}
	pgSqlConn.SetMaxIdleConns(conf.MaxIdle)
	pgSqlConn.SetMaxOpenConns(conf.MaxOpen)
	pgSqlConn.SetConnMaxLifetime(time.Duration(conf.MaxLife) * time.Second)

	orm, err := gorm.Open(pg.New(pg.Config{
		Conn: pgSqlConn,
	}), &gorm.Config{})
	if err != nil {
		return nil, err
	}

	if conf.Debug {
		orm.Debug()
	}

	if conf.Mock {
		orm.Debug()
		orm.DryRun = true
	}
	return orm, nil
}
