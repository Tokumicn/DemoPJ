package job

import (
	"fmt"
	"git-biz.qianxin-inc.cn/eps/skylar/apps/libs/tianqing.git/logs"
	"log"
	"sync"
	"time"
	"tq-scascade-report/pkg/config"
	"tq-scascade-report/pkg/executor"
	"tq-scascade-report/pkg/job_common"
)

const (
	// 保存任务事件
	JOB_EVENT_SAVE = 1

	// 保存任务事件
	JOB_EVENT_CREATE = 5

	// 删除任务事件
	JOB_EVENT_DELETE = 2

	// 强杀任务事件
	JOB_EVENT_KILL = 3

	// 立即执行一个定时任务
	JOB_EVENT_START_RIGHT_NOW = 4
)

var (
	G_scheduler *Scheduler

	lockForPlan      sync.Mutex
	lockForExecuting sync.Mutex
)

// 任务调度
type Scheduler struct {
	jobEventChan      chan *job_common.JobEvent              // 任务事件队列
	jobResultChan     chan *job_common.JobExecuteResult      // 任务结果队列
	jobPlanTable      map[string]*job_common.JobSchedulePlan // 任务调度计划表
	jobExecutingTable map[string]*job_common.JobExecuteInfo  // 任务执行表
}

// 初始化调度器
func InitScheduler() {

	chanSize := 10

	G_scheduler = &Scheduler{
		jobEventChan:      make(chan *job_common.JobEvent, chanSize),
		jobPlanTable:      make(map[string]*job_common.JobSchedulePlan),
		jobExecutingTable: make(map[string]*job_common.JobExecuteInfo),
		jobResultChan:     make(chan *job_common.JobExecuteResult, chanSize),
	}
	// 启动调度协程
	go G_scheduler.scheduleLoop()
	return
}

// 推送任务变化事件
func (scheduler *Scheduler) PushJobEvent(jobEvent *job_common.JobEvent) {
	scheduler.jobEventChan <- jobEvent
}

// 回传任务执行结果
func (scheduler *Scheduler) PushJobResult(jobResult *job_common.JobExecuteResult) {
	scheduler.jobResultChan <- jobResult
}

// 调度协程
func (scheduler *Scheduler) scheduleLoop() {
	var (
		jobEvent      *job_common.JobEvent
		scheduleAfter time.Duration
		scheduleTimer *time.Timer
		jobResult     *job_common.JobExecuteResult
	)

	// 初始调度一次，为生成定时器做准备
	scheduleAfter = scheduler.trySchedule()
	scheduleTimer = time.NewTimer(scheduleAfter)

	for {
		select {
		// 任务列表变化
		case jobEvent = <-scheduler.jobEventChan:
			scheduler.handleJobEvent(jobEvent)
		case <-scheduleTimer.C:
		// 任务执行结果
		case jobResult = <-scheduler.jobResultChan:
			scheduler.handleJobResult(jobResult)
		}
		// 调度下一次任务
		scheduleAfter = scheduler.trySchedule()
		// 重置下一次调度时间
		scheduleTimer.Reset(scheduleAfter)

		// Debug模式显示内存中任务列表信息
		if config.Cfg().ServerConf.Debug {
			scheduler.printSchedulerStatus()
		}
	}
}

// 重新计算任务调度状态
func (scheduler *Scheduler) trySchedule() time.Duration {
	var (
		jobPlan  *job_common.JobSchedulePlan
		now      time.Time
		nearTime *time.Time
	)

	var scheduleAfter time.Duration

	// 任务表为空话  无需工作
	if len(scheduler.jobPlanTable) == 0 {
		scheduleAfter = 1 * time.Minute // 默认执行间隔为1分钟
		return scheduleAfter
	}

	// 当前时间
	now = time.Now()
	// 遍历所有任务
	for _, jobPlan = range scheduler.jobPlanTable {
		if jobPlan.NextTime.Before(now) || jobPlan.NextTime.Equal(now) {
			scheduler.tryStartJob(jobPlan)

			// 更新刚刚调用过的任务下次执行时间
			jobPlan.NextTime = jobPlan.Expr.Next(now)

			// 更新Job内存放的查询时间范围
			job_common.ResetJobQueryTimeRange(jobPlan)
		}

		// 记录最近可执行的任务
		if nearTime == nil || jobPlan.NextTime.Before(*nearTime) {
			nearTime = &jobPlan.NextTime
		}
	}
	// 下次调度间隔（最近要执行的任务调度时间 - 当前时间）
	if nearTime != nil {
		scheduleAfter = (*nearTime).Sub(now)
	}
	return scheduleAfter
}

// 处理任务结果
func (scheduler *Scheduler) handleJobResult(result *job_common.JobExecuteResult) {
	var (
		jobLog *job_common.JobLog
	)
	// 删除执行状态
	scheduler.removeExecutingTable(result.ExecuteInfo.Job.JobName)

	// 生成执行日志
	jobLog = &job_common.JobLog{
		JobName:      result.ExecuteInfo.Job.JobName,
		PlanTime:     result.ExecuteInfo.PlanTime.UnixNano() / 1000 / 1000,
		ScheduleTime: result.ExecuteInfo.RealTime.UnixNano() / 1000 / 1000,
		StartTime:    result.StartTime.UnixNano() / 1000 / 1000,
		EndTime:      result.EndTime.UnixNano() / 1000 / 1000,
	}
	if result.Err != nil {
		jobLog.Err = result.Err.Error()
	} else {
		jobLog.Err = ""
	}

	logs.Infof("[JOB_LOG]任务执行完成: [JobName: %s] [JobInfo: %#v]", result.ExecuteInfo.Job.JobName, jobLog)
}

// 处理任务事件
func (scheduler *Scheduler) handleJobEvent(jobEvent *job_common.JobEvent) {
	var (
		jobSchedulePlan *job_common.JobSchedulePlan
		jobExecuteInfo  *job_common.JobExecuteInfo
		jobExecuting    bool
		err             error
	)
	switch jobEvent.EventType {
	case JOB_EVENT_CREATE: // 保存任务事件
		if jobSchedulePlan, err = job_common.CreateJobPlan(jobEvent); err != nil {
			return
		}
		scheduler.setJobPlanTable(jobSchedulePlan)
	case JOB_EVENT_SAVE: // 保存逻辑是: 先删除，后新建
		scheduler.removeJobPlanTable(jobEvent.JobName)
		if jobSchedulePlan, err = job_common.CreateJobPlan(jobEvent); err != nil {
			return
		}
		scheduler.setJobPlanTable(jobSchedulePlan)
	case JOB_EVENT_DELETE: // 删除任务事件
		scheduler.removeJobPlanTable(jobEvent.JobName)
	case JOB_EVENT_KILL: // 强杀任务事件
		// 判断任务是否在执行中
		if jobExecuteInfo, jobExecuting = scheduler.getExecutingTable(jobEvent.JobName); jobExecuting {
			jobExecuteInfo.CancelFunc() // 触发command杀死shell子进程, 任务得到退出
		}
	case JOB_EVENT_START_RIGHT_NOW: // 立即开始执行一个任务
		scheduler.startJobRightNow(jobEvent.JobName)
	}
}

// 尝试执行任务
func (scheduler *Scheduler) tryStartJob(jobPlan *job_common.JobSchedulePlan) {

	// 相同的任务正在执行，跳过本次调度
	if _, jobExecuting := scheduler.getExecutingTable(jobPlan.Job.JobName); jobExecuting {
		logs.Infof("相同任务[Name: %s]尚未退出,跳过执行。", jobPlan.Job.JobName)
		return
	}

	// 记录执行状态信息
	jobExecuteInfo := job_common.BuildJobExecuteInfo(jobPlan)
	scheduler.setExecutingTable(jobExecuteInfo)

	// 执行任务
	logs.Debugf("执行任务: name: %s, planTime: %v, realTime: %v",
		jobExecuteInfo.Job.JobName,
		jobExecuteInfo.PlanTime,
		jobExecuteInfo.RealTime)

	exeErrors := executor.G_executor.ExecuteJob(jobExecuteInfo)

	var err = fmt.Errorf("执行成功.")
	if len(exeErrors) > 0 {
		// 创建结果
		err = fmt.Errorf("任务执行错误 [taskId: %d] [taskName: %s] [errLen: %d]",
			jobExecuteInfo.Job.Id,
			jobExecuteInfo.Job.JobName,
			len(exeErrors))
	}

	exeResult := job_common.BuildJobExecuteResult(jobExecuteInfo, err)
	G_scheduler.PushJobResult(exeResult)
}

// 立即执行任务
func (scheduler *Scheduler) startJobRightNow(jobName string) {
	if _, exist := scheduler.getExecutingTable(jobName); exist {
		log.Printf("任务[%s]已在执行中.\n", jobName)
		return
	}

	if plan, exist := scheduler.getJobPlanTable(jobName); exist {
		// 更新任务下次执行时间为当前，就可以尽快被调用
		plan.NextTime = time.Now()
		scheduler.setJobPlanTable(plan)
	}

	return
}

func (Scheduler *Scheduler) printSchedulerStatus() {

	planJobs := ""
	lockForPlan.Lock()
	planList := Scheduler.jobPlanTable
	lockForPlan.Unlock()
	for _, p := range planList {
		planJobs += fmt.Sprintf("\n\t\t\t[任务名: %s, 执行时间: %s]", p.Job.JobName, p.Job.CronDescription)
	}

	execJobs := ""
	lockForExecuting.Lock()
	execList := Scheduler.jobExecutingTable
	lockForExecuting.Unlock()
	for _, e := range execList {
		execJobs += e.Job.JobName + " "
	}

	if planJobs == "" {
		planJobs = "无"
	}

	if execJobs == "" {
		execJobs = "暂无"
	}

	fmt.Println("===========任务调度消息===========")
	fmt.Printf("\n计划任务数目: %d, 详情列表: %s\n", len(planList), planJobs)
	fmt.Printf("\n执行任务数目: %d, [任务名: %s]\n", len(execList), execJobs)
	fmt.Println("================================")
}
