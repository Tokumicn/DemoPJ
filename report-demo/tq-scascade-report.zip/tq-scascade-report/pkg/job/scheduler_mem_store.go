package job

import (
	"fmt"
	"git-biz.qianxin-inc.cn/eps/skylar/apps/libs/tianqing.git/logs"
	"tq-scascade-report/pkg/def"
	"tq-scascade-report/pkg/job_common"
)

// 维护当前Scheduler 内存中控制的任务列表
// 1. 查询任务信息以内存中数据为准
// 2. 由于报表任务本身的幂等性(多次执行不影响结果)，因此不做额外的比对内存与DB数据的不一致

func (scheduler *Scheduler) GetJobPlanNextTime(name string) (string, error) {
	if plan, exist := scheduler.getJobPlanTable(name); exist {
		return plan.NextTime.Format(def.YYYYMMDDHHSSmm), nil
	} else {
		return "", fmt.Errorf("job[%s] is not exist.", name)
	}
}

func (scheduler *Scheduler) getJobPlanTable(name string) (*job_common.JobSchedulePlan, bool) {
	lockForPlan.Lock()
	defer lockForPlan.Unlock()

	plan, exist := scheduler.jobPlanTable[name]
	return plan, exist
}

func (scheduler *Scheduler) setJobPlanTable(plan *job_common.JobSchedulePlan) {
	lockForPlan.Lock()
	defer lockForPlan.Unlock()

	scheduler.jobPlanTable[plan.Job.JobName] = plan

	logs.Debugf("@@@设置plan: [nextTime: %s] [jobName: %s] [timeRange: %s]",
		plan.NextTime.Format(def.YYYYMMDDHHSSmm),
		plan.Job.TaskName,
		plan.Job.TimeRange)
}

func (scheduler *Scheduler) removeJobPlanTable(name string) {
	lockForPlan.Lock()
	defer lockForPlan.Unlock()

	if _, exist := scheduler.jobPlanTable[name]; exist {
		delete(scheduler.jobPlanTable, name)
	}
}

func (Scheduler *Scheduler) getExecutingTable(name string) (*job_common.JobExecuteInfo, bool) {
	lockForExecuting.Lock()
	defer lockForExecuting.Unlock()

	info, exist := Scheduler.jobExecutingTable[name]
	return info, exist
}

func (Scheduler *Scheduler) setExecutingTable(info *job_common.JobExecuteInfo) {
	lockForExecuting.Lock()
	defer lockForExecuting.Unlock()

	Scheduler.jobExecutingTable[info.Job.JobName] = info
}

func (scheduler *Scheduler) removeExecutingTable(name string) {
	lockForExecuting.Lock()
	defer lockForExecuting.Unlock()

	if _, exist := scheduler.jobExecutingTable[name]; exist {
		delete(scheduler.jobExecutingTable, name)
	}
}

func (scheduler *Scheduler) GetJobExecutingStatus(name string) bool {
	_, exist := scheduler.getExecutingTable(name)
	return exist
}
