package config

import (
	"git-biz.qianxin-inc.cn/eps/skylar/apps/libs/tianqing.git/logs"
	"github.com/BurntSushi/toml"
	"log"
	"sync"
	"tq-scascade-report/pkg/clickhouse"
	"tq-scascade-report/pkg/postgres"
	"tq-scascade-report/pkg/redis"
)

var (
	cfg  *ReportJobConfig
	once sync.Once
)

type ServerConfig struct {
	Address          string `toml:"address"`
	Debug            bool   `toml:"debug"`
	Interval         int    `toml:"interval"`
	ClearHistoryCron string `toml:"clear_history_cron"`
}

type ExportConfig struct {
	Path          string            `toml:"path"`
	PdfWebAddr    string            `toml:"web_addr"`
	BeanstalkConn string            `toml:"beanstalk_conn"`
	TplMap        map[string]string `toml:"tpls"`
}

type ReportJobConfig struct {
	ServerConf *ServerConfig      `toml:"server"`
	LogConfig  logs.Config        `toml:"logConfig"`
	RedisConf  *redis.Config      `toml:"redis"`
	CHConf     *clickhouse.Config `toml:"clickHouse"`
	PGConf     *postgres.Config   `toml:"postgres"`
	ExportConf *ExportConfig      `toml:"export"`
}

func InitialConfig(confPath string) {
	once.Do(func() {
		var err error
		cfg = &ReportJobConfig{}
		if _, err = toml.DecodeFile(confPath, cfg); err != nil {
			log.Printf("load config fails: %s", err.Error())
			panic(err.Error())
		}
	})
}

func Cfg() *ReportJobConfig {
	return cfg
}
