package advanced_search

import (
	"errors"
	"fmt"
	"git-biz.qianxin-inc.cn/eps/skylar/apps/libs/tianqing.git/logs"
	"strings"
	"tq-scascade-report/pkg/config"
	"tq-scascade-report/pkg/def"
	"tq-scascade-report/pkg/model"
	"tq-scascade-report/pkg/tools"
	"tq-scascade-report/service/log_details/security"
)

var (
	ErrRelationTemplate_IllegalCharacterError = errors.New("模板含非允许字符.")
	ErrRelationTemplate_PairsError            = errors.New("模板括号配对错误.")
	ErrRelationTemplate_SpellingError         = errors.New("单词拼写错误.")
)

type WhereBuilder struct {
	BasicSearch    *model.BasicSearch // 基础查询
	AdvancedQuery  *model.Query       // 高级查询
	SecurityConfig *security.ColumnsConfig
}

// 返回WhereSQL和Parameters
func (where *WhereBuilder) Build() (string, map[string]interface{}, error) {
	var (
		whereStr   string
		parameters = make(map[string]interface{}, 0)
		err        error
	)

	// 基础查询
	whereStr, parameters, err = basicWhereBuilder(where.BasicSearch)
	if err != nil {
		return "", nil, err
	}

	// 高级查询
	if where.AdvancedQuery != nil {

		adWhereStr, adParams, err := advanceWhereBuilder(where.AdvancedQuery.Conditions, where.AdvancedQuery.RelationTemplate)
		if err != nil {
			return "", nil, err
		}

		if len(adWhereStr) > 0 {
			whereStr = fmt.Sprintf("%s AND ( %s )", whereStr, adWhereStr)
		}

		if len(adParams) > 0 {
			for k, v := range adParams {
				parameters[k] = v
			}
		}
	}

	if config.Cfg().ServerConf.Debug {
		fmt.Println("====================Where Builder====================")
		fmt.Println("WhereStr: ", whereStr)
		if len(parameters) > 0 {
			fmt.Printf("Parameters: %v\n", parameters)
		}
		fmt.Printf("====================Where Builder End====================\n\n\n\n")
	}

	return whereStr, parameters, nil
}

// 基础搜索条件构建
func basicWhereBuilder(basicSearch *model.BasicSearch) (string, map[string]interface{}, error) {
	var (
		whereStr   string
		parameters = make(map[string]interface{})
	)

	if basicSearch == nil {
		return "", nil, fmt.Errorf("[BasicSearch]查询条件有误.")
	}

	if len(basicSearch.CCIDs) > 0 {
		whereStr += " ccid IN (:ccIds)"
		parameters["ccIds"] = basicSearch.CCIDs
	} else {
		whereStr += " ccid <> '' "
	}

	if basicSearch.StartTime != nil && basicSearch.EndTime != nil {
		whereStr += " AND event_time >= :startTime AND event_time <= :endTime"
		parameters["startTime"] = basicSearch.StartTime
		parameters["endTime"] = basicSearch.EndTime
	}

	return whereStr, parameters, nil
}

// 高级搜索条件构建
func advanceWhereBuilder(conditions []*model.Condition, relationStr string) (string, map[string]interface{}, error) {
	var (
		parameters = make(map[string]interface{}, 0)
		pKey       string
		whereStr   string
	)

	whereStr = relationStr
	for index, cond := range conditions {

		// like参数前后加%
		if cond.Op == def.LIKE {
			cond.Value = "%" + cond.Value.(string) + "%"
		}
		// 添加参数列表
		pKey, parameters = parametersAppend(parameters, cond.Key, cond.Value)

		var tempValue string
		tempKey := fmt.Sprint("$", index+1)

		// in参数加括号
		if cond.Op == def.IN || cond.Op == def.NOTIN {
			tempValue = fmt.Sprintf("%s %s (:%s)", cond.Key, cond.Op, pKey)
		} else {
			tempValue = fmt.Sprintf("%s %s :%s", cond.Key, cond.Op, pKey)
		}

		// 按模板拼接Where语句
		whereStr = strings.Replace(whereStr, tempKey, tempValue, -1)
	}

	return whereStr, parameters, nil
}

// 查询参数化: 参数重命名,例如: key > 1 Or key < 2时 ===> 参数名: key=1 key1=2
func parametersAppend(params map[string]interface{}, key string, val interface{}) (string, map[string]interface{}) {

	paramKey := key
	if _, ok := params[key]; ok {
		paramIndex := 1
		for {
			tempKey := fmt.Sprintf("%s%d", key, paramIndex)
			if _, ok := params[tempKey]; ok {
				paramIndex++
				continue
			} else {
				params[tempKey] = val
				paramKey = tempKey
				break
			}
		}
	} else {
		params[key] = val
	}

	return paramKey, params
}

// 翻译高级搜索条件
func conditionsTransform(conditions []*model.Condition, fieldsConfigMap map[string]*def.OptionalFieldsConfig) ([]*model.Condition, error) {

	completedConditions := make([]*model.Condition, 0)
	for _, item := range conditions {

		newCondition, err := getCompletedCondition(item, fieldsConfigMap)
		if err != nil {
			logs.Errorf("转换查询条件失败. current condition is [%#v]", item)
			continue
		}

		completedConditions = append(completedConditions, newCondition)
	}

	return completedConditions, nil

}

// 获取转换完成的查询条件
func getCompletedCondition(old *model.Condition, FieldsConf map[string]*def.OptionalFieldsConfig) (*model.Condition, error) {

	var (
		op  string
		ok  bool
		val interface{}
	)
	// Op
	op, ok = def.OpTranslateMap[old.Op]
	if !ok {
		return nil, fmt.Errorf("非法Op[%s] condition[%#v]", old.Op, old)
	}

	// Key
	conf, ok := FieldsConf[old.Key]
	if !ok {
		return nil, fmt.Errorf("非法Key[%s] condition[%#v]", old.Key, old)
	}

	// Value
	if op == def.IN || op == def.NOTIN {
		// 多个参数
		valueKeys := tools.SplitStrWithoutEmpty(old.Value.(string), ",")
		if len(valueKeys) <= 0 {
			return nil, fmt.Errorf("参数有误. [Op: %s] [Key: %s] [Value: %v]", old.Op, old.Key, old.Value)
		}

		arrValue := make([]interface{}, 0)

		for _, k := range valueKeys {
			if currentVal, ok := conf.ValueTranslateMap[k]; ok {
				arrValue = append(arrValue, currentVal)
			} else {
				continue
			}
		}

		val = arrValue
	} else {
		// 输入类型
		if conf.ValueTranslateMap == nil {
			val = old.Value
		} else {
			// 单个参数
			if currentVal, ok := conf.ValueTranslateMap[old.Value.(string)]; ok {
				val = currentVal
			}
		}
	}

	newCond := &model.Condition{
		Op:    op,
		Key:   conf.DBField,
		Value: val,
	}

	return newCond, nil
}
