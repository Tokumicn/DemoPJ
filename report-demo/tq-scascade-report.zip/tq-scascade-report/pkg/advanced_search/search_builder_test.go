package advanced_search

import (
	"fmt"
	"git-biz.qianxin-inc.cn/eps/skylar/apps/libs/tianqing.git/logs"
	"testing"
	"tq-scascade-report/pkg/def"
	"tq-scascade-report/pkg/model"
)

func init() {
	logs.Init(logs.Config{
		Writer: "console",
		Level:  "debug",
	})
}

func TestRelationCheck(t *testing.T) {

	checker := ArgsChecker{}

	tlp := "$1 and ($2 or $3 or $4) and $5"
	checker.ToCheckRelationTemplate = tlp
	err := checker.RelationCheck()
	if err != nil {
		t.Fatal(err)
	}

	tlp2 := "($1 and ($2 or $3 or $4) and $5)"
	checker.ToCheckRelationTemplate = tlp2
	err = checker.RelationCheck()
	if err != nil {
		t.Fatal(err)
	}

	// 括号不匹配
	tlp3 := ")$1 and ($2 or $3 or $4) and $5("
	checker.ToCheckRelationTemplate = tlp3
	err = checker.RelationCheck()
	if err == nil {
		t.Fatal(err)
	}

	// 非法单词 orr
	tlp4 := "($1 and ($2 orr $3 or $4) and $5)"
	checker.ToCheckRelationTemplate = tlp4
	err = checker.RelationCheck()
	if err == nil {
		t.Fatal(err)
	}

	// 非法单词  andd
	tlp5 := "($1 and ($2 or $3 or $4) andd $5)"
	checker.ToCheckRelationTemplate = tlp5
	err = checker.RelationCheck()
	if err == nil {
		t.Fatal(err)
	}

	// 非法字符u
	tlp6 := "($1 and ($2 or $3 or $4) aud $5)"
	checker.ToCheckRelationTemplate = tlp6
	err = checker.RelationCheck()
	if err == nil {
		t.Fatal(err)
	}
}

func TestRelationCheckBySpelling(t *testing.T) {
	tlp := "($1 and ($2 orr $3 or $4) and $5)"
	err := relationCheckBySpelling(tlp)
	if err == nil {
		t.Fatal(err)
	}
}

func TestSearchBuilder(t *testing.T) {

	s := &model.AdvancedSearch{
		BusinessCode: def.LEAK,
		Select:       "[SelectKeys]",
		//OrderArgs: &model.OrderArgs{
		//	OrderCondition: "",
		//	Order:          0,
		//},
		PagingArgs: nil,
		Group:      "aaa,bbb,ccc",
		BasicSearch: &model.BasicSearch{
			CCIDs: []string{"AAA,BBB"},
		},
		AdvancedQuery: &model.Query{
			Conditions: []*model.Condition{
				&model.Condition{
					Op:    "contain",
					Key:   "patch_name",
					Value: "patch_name_XXXX",
				},
				&model.Condition{
					Op:    "include",
					Key:   "patch_level",
					Value: "1,2,3,4",
				},
				&model.Condition{
					Op:    "not_include",
					Key:   "patch_level",
					Value: "3,4",
				},
			},
			RelationTemplate: "$1 OR ($2 AND $3)",
		},
	}

	sqlStr, _, params, err := SqlBuilder(s)
	if err != nil {
		t.Fatal()
	}

	fmt.Println("SQL: ", sqlStr)
	fmt.Printf("Parameters: %#v", params)
}
