// 查询条件相关检查
package advanced_search

import (
	"fmt"
	"strings"
	"tq-scascade-report/pkg/model"
	"tq-scascade-report/pkg/tools"
)

var (
	ArgsCheckerErr_IllegalQueryKey = func(illegalKey string) error {
		return fmt.Errorf("查询参数不合法. key: %s", illegalKey)
	}
	ArgsCheckerErr_IllegalOrderKey = func(illegalKey string) error {
		return fmt.Errorf("排序参数不合法. key: %s", illegalKey)
	}
)

// 参数检查器
type ArgsChecker struct {
	// 用户输入的  待检查条件参数
	ToCheckConditions []*model.Condition
	// 用户输入的  待检查条件关系模板
	ToCheckRelationTemplate string
	// 用户输入的  待检查排序参数
	ToCheckOrderKeys string

	// 允许的查询字段: Key检查
	AllowQueryKeysMap map[string]int
	// 允许参与排序的字段: Key检查
	AllowOrderKeysMap map[string]int
}

// 排序参数检查
func (checker *ArgsChecker) OrderCheck() error {
	orderKeys := checker.ToCheckOrderKeys
	if len(orderKeys) <= 0 {
		return nil
	}

	orderArr := tools.SplitStrWithoutEmpty(orderKeys, ",")

	for _, k := range orderArr {
		if _, ok := checker.AllowOrderKeysMap[k]; !ok {
			return ArgsCheckerErr_IllegalOrderKey(k)
		}
	}

	return nil
}

// 检查key合法性检查  有不合法字段直接返回错误
func (checker *ArgsChecker) KeyCheck() error {

	for _, c := range checker.ToCheckConditions {
		if _, ok := checker.AllowQueryKeysMap[c.Key]; !ok {
			return ArgsCheckerErr_IllegalQueryKey(c.Key)
		}
	}
	return nil
}

// 关系模板检查
func (checker *ArgsChecker) RelationCheck() error {

	relationTlp := checker.ToCheckRelationTemplate

	if len(relationTlp) <= 0 {
		return fmt.Errorf("查询关系模板有误.")
	}

	// 括号配对检查
	err := relationCheckByPairs(relationTlp)
	if err != nil {
		return err
	}

	// 词检测  or / and
	err = relationCheckBySpelling(relationTlp)
	if err != nil {
		return err
	}

	// 字符检查
	return relationCheckByRune(relationTlp)
}

// 词语拼写检查
func relationCheckBySpelling(relationTlp string) error {

	relationTlp = strings.ToLower(relationTlp)

	allowFieldsMap := map[string]int{
		"or":  1,
		"and": 1,
	}

	// 模板只允许or和and两个单词
	isOrAnd := func(s string) bool {
		containDollar := strings.Contains(s, "$")
		containLBracket := strings.Contains(s, "(")
		containRBracket := strings.Contains(s, ")")

		if containDollar || containLBracket || containRBracket {
			return false
		}

		return true
	}

	fields := strings.Fields(relationTlp)

	for _, f := range fields {
		if isOrAnd(f) {
			if _, ok := allowFieldsMap[f]; !ok {
				return ErrRelationTemplate_SpellingError
			}
		} else {
			continue
		}
	}

	return nil
}

// 字符合法性检查
func relationCheckByRune(relationTlp string) error {

	allowCharMap := map[rune]int{
		' ': 1,
		'(': 1,
		')': 1,
		'$': 1,
		'a': 1,
		'A': 1,
		'n': 1,
		'N': 1,
		'd': 1,
		'D': 1,
		'o': 1,
		'O': 1,
		'r': 1,
		'R': 1,
		'1': 1,
		'2': 1,
		'3': 1,
		'4': 1,
		'5': 1,
		'6': 1,
		'7': 1,
		'8': 1,
		'9': 1,
		'0': 1,
	}

	for _, char := range relationTlp {
		if _, ok := allowCharMap[char]; ok {
			continue
		} else {
			return ErrRelationTemplate_IllegalCharacterError
		}
	}

	return nil
}

// 括号配对检查
func relationCheckByPairs(relationTlp string) error {
	var (
		pushKey = '('
		popKey  = ')'
	)

	stack := tools.NewStack()
	for _, char := range relationTlp {
		if char == pushKey {
			stack.Push(pushKey)
		} else if char == popKey {
			e := stack.Pop()
			if e == nil {
				return ErrRelationTemplate_PairsError
			}
		}
	}

	// 括号配对检查
	if !stack.IsEmpty() {
		return ErrRelationTemplate_PairsError
	}

	return nil
}
