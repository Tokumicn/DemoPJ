package advanced_search

import (
	"fmt"
	"strings"
	"text/template"
	"tq-scascade-report/pkg/def"
	"tq-scascade-report/pkg/model"
)

type Search struct {
	S         string
	T         string
	W         string
	G         string
	OrderArgs *model.OrderArgs
	PageArgs  *model.PagingArgs
}

const (
	sqlAdvancedTemplate = `SELECT {{.S}} FROM {{.T}} WHERE {{.W}} {{grouping .G}} ORDER BY {{ordering .OrderArgs}} {{paging .PageArgs}}`

	sqlTotalTemplate = `SELECT COUNT(*) as total FROM {{.T}} WHERE {{.W}}`
)

func (search *Search) BuildSQL() (string, error) {
	funcMap := template.FuncMap{
		"ordering": orderSQLBuilder,
		"paging":   pageSQLBuilder,
		"grouping": groupSQLBuilder,
	}

	tmpl, err := template.New("buildAdvancedSqlTlp").Funcs(funcMap).Parse(sqlAdvancedTemplate)
	if err != nil {
		return "", err
	}
	strBuf := &strings.Builder{}
	err = tmpl.Execute(strBuf, search)
	if err != nil {
		return "", err
	}

	return strBuf.String(), nil
}

// 仅需传入 T 和 W即可
func (search *Search) BuildTotalSQL() (string, error) {

	tmpl, err := template.New("buildTotalSqlTlp").Parse(sqlTotalTemplate)
	if err != nil {
		return "", err
	}
	strBuf := &strings.Builder{}
	err = tmpl.Execute(strBuf, search)
	if err != nil {
		return "", err
	}

	return strBuf.String(), nil
}

func pageSQLBuilder(args *model.PagingArgs) string {
	if args == nil {
		return ""
	}
	if args.Current <= 0 && args.PageSize <= 0 {
		return ""
	}

	var (
		pagingStr string
		current   = args.Current
		pageSize  = args.PageSize
	)

	switch args.DBType {
	case def.POSTGRES_DBType:
		pagingStr = fmt.Sprintf("OFFSET %d LIMIT %d ", (current-1)*pageSize, pageSize)
	case def.CLICKHOUSE_DBType:
		pagingStr = fmt.Sprintf(" LIMIT %d,%d", (current-1)*pageSize, pageSize)
	}

	return pagingStr
}

func orderSQLBuilder(args *model.OrderArgs) string {

	if args == nil {
		args = &model.OrderArgs{}
	}

	orderCondition := args.OrderCondition
	sort := args.Order

	var orderSql string
	if len(orderCondition) <= 0 {

		orderSql = fmt.Sprintf("%s %s", "event_time", "DESC")
	} else {

		sortFlag := "DESC"
		sortKey := orderCondition
		if sort > 0 {
			sortFlag = "ASC"
		}

		orderSql = fmt.Sprintf("%s %s", sortKey, sortFlag)
	}

	return orderSql
}

func groupSQLBuilder(group string) string {

	groupStr := ""
	if len(group) > 0 {
		groupStr = "GROUP BY " + group
	}

	return groupStr
}
