package advanced_search

import (
	"fmt"
	"git-biz.qianxin-inc.cn/eps/skylar/apps/libs/tianqing.git/logs"
	"tq-scascade-report/pkg/def"
	"tq-scascade-report/pkg/model"
	"tq-scascade-report/service/log_details/security"
)

func SqlBuilder(s *model.AdvancedSearch) (string, string, map[string]interface{}, error) {

	// 获取允许查询字段相关配置
	securityConfig, ok := security.BusinessSecurityColumnsConfigMap[s.BusinessCode]
	if !ok {
		return "", "", nil, fmt.Errorf("[Security.SecurityColumnsConfig]非法BusinessCode[%s]", s.BusinessCode)
	}

	// (1)验证Order 合法性
	checker := ArgsChecker{}
	if s.OrderArgs != nil {
		checker.ToCheckOrderKeys = s.OrderArgs.OrderCondition
		checker.AllowOrderKeysMap = securityConfig.AllowOrderColumns

		// Order参数检查
		err := checker.OrderCheck()
		if err != nil {
			return "", "", nil, fmt.Errorf("[Security.OrderKeyCheck]非法OrderKey[err: %s]", err.Error())
		}
	}

	// (2)如有高级搜索条件  则验证其合法性
	if s.AdvancedQuery != nil &&
		len(s.AdvancedQuery.Conditions) > 0 &&
		len(s.AdvancedQuery.RelationTemplate) > 0 {

		// 获取查询参数配置
		fieldsConfig, err := def.GetOptionalFieldsFilterConfig(s.BusinessCode)
		if err != nil {
			return "", "", nil, fmt.Errorf("[OptionalFieldsFilter]非法BusinessCode[%s]", s.BusinessCode)
		}

		// 转换高级搜索信息 "gt" ==> ">"  rawKey ==> dbKey
		completeConditions, err := conditionsTransform(s.AdvancedQuery.Conditions, fieldsConfig)
		if err != nil {
			return "", "", nil, err
		}

		if completeConditions == nil || len(completeConditions) <= 0 {
			return "", "", nil, fmt.Errorf("查询条件不符合查询规范.")
		}

		s.AdvancedQuery.Conditions = completeConditions

		checker.ToCheckConditions = s.AdvancedQuery.Conditions
		checker.ToCheckRelationTemplate = s.AdvancedQuery.RelationTemplate
		checker.AllowQueryKeysMap = securityConfig.AllowQueryColumns

		// 关系模板参数检查
		err = checker.RelationCheck()
		if err != nil {
			return "", "", nil, fmt.Errorf("[Security.RelationCheck]非法RelationTlp[err: %s]", err.Error())
		}

		// Where参数检查
		err = checker.KeyCheck()
		if err != nil {
			return "", "", nil, fmt.Errorf("[Security.QueryKeyCheck]非法QueryKey[err: %s]", err.Error())
		}
	}

	// 构建Where语句
	w := WhereBuilder{
		BasicSearch:    s.BasicSearch,
		AdvancedQuery:  s.AdvancedQuery,
		SecurityConfig: s.SecurityConfig,
	}

	whereStr, parameters, err := w.Build()
	if err != nil {
		logs.Errorf("[SqlBuilder]--[WhereBuilder] [search: %v] [err: %s]", s, err.Error())
		return "", "", nil, err
	}

	search := &Search{
		S:         s.Select,
		T:         securityConfig.TableName,
		W:         whereStr,
		G:         s.Group,
		OrderArgs: s.OrderArgs,
		PageArgs:  s.PagingArgs,
	}

	querySql, err := search.BuildSQL()
	if err != nil {
		logs.Errorf("[SqlBuilder]--[BuildSQL] [search: %v] [err: %s]", search, err.Error())
		return "", "", nil, err
	}

	totalSql, err := search.BuildTotalSQL()
	if err != nil {
		logs.Errorf("[SqlBuilder]--[BuildTotalSQL] [search: %v] [err: %s]", search, err.Error())
		return "", "", nil, err
	}

	return querySql, totalSql, parameters, nil
}
