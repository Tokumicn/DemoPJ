package advanced_search

import (
	"git-biz.qianxin-inc.cn/eps/skylar/apps/libs/tianqing.git/utils"
	"testing"
	"time"
	"tq-scascade-report/pkg/def"
	"tq-scascade-report/pkg/model"
	"tq-scascade-report/service/log_details/security"
)

// 输入型条件
func TestWhereBuilder01(t *testing.T) {

	businessCode := def.SCORE
	w := WhereBuilder{
		BasicSearch: &model.BasicSearch{
			CCID:      "CCID_AAA,CCID_BBB",
			StartTime: &utils.JSONTime{T: time.Now().AddDate(0, -1, 0)},
			EndTime:   &utils.JSONTime{T: time.Now()},
		},
		AdvancedQuery: &model.Query{
			RelationTemplate: "$1 OR $2",
			Conditions: []*model.Condition{
				{
					Op:    "gt",
					Key:   "score",
					Value: 88,
				},
				{
					Op:    "lte",
					Key:   "score",
					Value: 98,
				},
			},
		},
		SecurityConfig: security.BusinessSecurityColumnsConfigMap[businessCode],
	}

	_, _, err := w.Build()
	if err != nil {
		t.Fatal(err)
	}
}

// 组合多个 简单条件
func TestWhereBuilder02(t *testing.T) {
	businessCode := def.ASSET
	w := WhereBuilder{
		BasicSearch: &model.BasicSearch{
			CCID:      "CCID_AAA,CCID_BBB",
			StartTime: &utils.JSONTime{T: time.Now().AddDate(0, -1, 0)},
			EndTime:   &utils.JSONTime{T: time.Now()},
		},
		AdvancedQuery: &model.Query{
			RelationTemplate: "$1 AND $2 AND $3 AND $4 OR $5",
			Conditions: []*model.Condition{
				&model.Condition{
					Op:    "eq",
					Key:   "cpu",
					Value: "2",
				},
				&model.Condition{
					Op:    "eq",
					Key:   "mem",
					Value: "4",
				},
				&model.Condition{
					Op:    "lt",
					Key:   "disk",
					Value: "4",
				},
				&model.Condition{
					Op:    "lte",
					Key:   "cpu_hz",
					Value: "3",
				},
				&model.Condition{
					Op:    "lt",
					Key:   "monitor",
					Value: "3",
				},
			},
		},
		SecurityConfig: security.BusinessSecurityColumnsConfigMap[businessCode],
	}

	_, _, err := w.Build()
	if err != nil {
		t.Fatal(err)
	}
}

// IN型条件
func TestWhereBuilder03(t *testing.T) {

	businessCode := def.LEAK
	w := WhereBuilder{
		BasicSearch: &model.BasicSearch{
			CCID:      "CCID_AAA,CCID_BBB",
			StartTime: &utils.JSONTime{T: time.Now().AddDate(0, -1, 0)},
			EndTime:   &utils.JSONTime{T: time.Now()},
		},
		AdvancedQuery: &model.Query{
			RelationTemplate: "$1 OR ($2 AND $3)",
			Conditions: []*model.Condition{
				&model.Condition{
					Op:    "contain",
					Key:   "patch_name",
					Value: "patch_name_XXXX",
				},
				&model.Condition{
					Op:    "include",
					Key:   "patch_level",
					Value: "1,2,3,4",
				},
				&model.Condition{
					Op:    "not_include",
					Key:   "patch_level",
					Value: "3,4",
				},
			},
		},
		SecurityConfig: security.BusinessSecurityColumnsConfigMap[businessCode],
	}

	_, _, err := w.Build()
	if err != nil {
		t.Fatal(err)
	}
}
