package def

// DBType
const (
	POSTGRES_DBType   = "PG"
	CLICKHOUSE_DBType = "CH"
)
