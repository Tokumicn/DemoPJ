package def

// 数据源表配置

const (
	// 资产
	ASSET_SCOURSE_DATA_TABLENAME = "assets"

	// 扫描分数
	SCORE_SCOURSE_DATA_TABLENAME = "skylar_scascade.exam"

	// 病毒分析
	VIRUS_SCOURSE_DATA_TABLENAME = "skylar_scascade.sd"

	// 漏洞分析
	LEAK_SCOURSE_DATA_TABLENAME = "skylar_scascade.leak_repair"

	// 告警事件
	ALERT_SCOURSE_DATA_TABLENAME = "skylar_scascade.secevent"

	// 审计信息
	AUDIT_SCOURSE_DATA_TABLENAME = "skylar_scascade.audit"
)

// 需要数据清理的源数据表--ClickHouse
var DropUselessSourceDataTableArr = []string{
	SCORE_SCOURSE_DATA_TABLENAME,
	VIRUS_SCOURSE_DATA_TABLENAME,
	LEAK_SCOURSE_DATA_TABLENAME,
	ALERT_SCOURSE_DATA_TABLENAME,
	AUDIT_SCOURSE_DATA_TABLENAME,
}
