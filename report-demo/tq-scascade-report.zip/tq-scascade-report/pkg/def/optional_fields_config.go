package def

import "git-biz.qianxin-inc.cn/eps/skylar/apps/libs/tianqing.git/logs"

type OptionalFieldsConfig struct {
	Display           string                 `json:"display"`       // 展示名
	Operation         map[string]string      `json:"operation"`     // 可选操作 JSON:{ "key": ">", "value": "大于" }, {...}, ...
	OptionalValue     map[string]string      `json:"optionalValue"` // 可选值   JSON:{ "key": 1, "value": "笔记本" }, {...}, ...
	DBField           string                 `json:"-"`             // 对应DB中字段名
	ValueTranslateMap map[string]interface{} `json:"-"`             // 选项值映射表
}

var DefaultOptionalFieldsFilterMap = map[string]*OptionalFieldsConfig{
	"clientName": {
		DBField: "client_name",
		Display: "计算机名",
		Operation: map[string]string{
			"eq":      "等于",
			"contain": "包含",
		},
		OptionalValue: nil, // 用户输入填写
	},
	"clientIP": {
		DBField: "client_ip",
		Display: "IP地址",
		Operation: map[string]string{
			"eq":      "等于",
			"contain": "包含",
		},
		OptionalValue: nil, // 用户输入填写
	},
	"clientMAC": {
		DBField: "client_mac",
		Display: "MAC地址",
		Operation: map[string]string{
			"eq":      "等于",
			"contain": "包含",
		},
		OptionalValue: nil, // 用户输入填写
	},
	//"clientOS": {
	//	DBField: "client_os",
	//	Display: "操作系统",
	//	Operation: map[string]string{
	//		"eq":      "等于",
	//		"contain": "包含",
	//	},
	//	OptionalValue: nil, // 用户输入填写
	//},
}

var BusinessOptionalFieldsFilterMap = map[string]map[string]*OptionalFieldsConfig{

	// 资产
	ASSET: {
		"cpu": &OptionalFieldsConfig{
			DBField: "client_hardware_cpu_core_count",
			Display: "CPU",
			Operation: map[string]string{
				"gt":  "大于",
				"gte": "大于等于",
				"eq":  "等于",
				"lt":  "小于",
				"lte": "小于等于",
			},
			OptionalValue: map[string]string{
				"1": "单核",
				"2": "双核",
				"3": "四核",
			},
			ValueTranslateMap: map[string]interface{}{
				"1": 1,
				"2": 2,
				"3": 3,
			},
		},
		"mem": &OptionalFieldsConfig{
			DBField: "client_hardware_memory_size",
			Display: "内存",
			Operation: map[string]string{
				"gt":  "大于",
				"gte": "大于等于",
				"eq":  "等于",
				"lt":  "小于",
				"lte": "小于等于",
			},
			OptionalValue: map[string]string{
				"1": "2G",
				"2": "4G",
				"3": "8G",
				"4": "16G",
			},
			ValueTranslateMap: map[string]interface{}{
				"1": 2 * 1024,
				"2": 4 * 1024,
				"3": 8 * 1024,
				"4": 16 * 1024,
			},
		},
		"disk": &OptionalFieldsConfig{
			DBField: "client_hardware_harddisk_size",
			Display: "硬盘",
			Operation: map[string]string{
				"gt":  "大于",
				"gte": "大于等于",
				"eq":  "等于",
				"lt":  "小于",
				"lte": "小于等于",
			},
			OptionalValue: map[string]string{
				"1": "250G",
				"2": "500G",
				"3": "1TB",
				"4": "2TB",
			},
			ValueTranslateMap: map[string]interface{}{
				"1": 250,
				"2": 500,
				"3": 1024,
				"4": 2048,
			},
		},
		"cpu_hz": &OptionalFieldsConfig{
			DBField: "client_hardware_cpu_frequency",
			Display: "主频",
			Operation: map[string]string{
				"gt":  "大于",
				"gte": "大于等于",
				"eq":  "等于",
				"lt":  "小于",
				"lte": "小于等于",
			},
			OptionalValue: map[string]string{
				"1": "2.0GHz",
				"2": "3.0GHz",
				"3": "4.0GHz",
			},
			ValueTranslateMap: map[string]interface{}{
				"1": 2.0,
				"2": 3.0,
				"3": 4.0,
			},
		},
		"monitor": &OptionalFieldsConfig{
			DBField: "client_hardware_monitor_size",
			Display: "显示器",
			Operation: map[string]string{
				"gt":  "大于",
				"gte": "大于等于",
				"eq":  "等于",
				"lt":  "小于",
				"lte": "小于等于",
			},
			OptionalValue: map[string]string{
				"1": "17寸",
				"2": "20寸",
				"3": "30寸",
			},
			ValueTranslateMap: map[string]interface{}{
				"1": 17,
				"2": 20,
				"3": 30,
			},
		},
		"userName": {
			DBField: "hardware_summary_username",
			Display: "使用人",
			Operation: map[string]string{
				"eq":      "等于",
				"contain": "包含",
			},
			OptionalValue: nil, // 用户输入填写
		},
		"userNumber": {
			DBField: "hardware_summary_user_number",
			Display: "工号",
			Operation: map[string]string{
				"eq":      "等于",
				"contain": "包含",
			},
			OptionalValue: nil, // 用户输入填写
		},
		"mobile": {
			DBField: "hardware_summary_mobile",
			Display: "手机号",
			Operation: map[string]string{
				"eq":      "等于",
				"contain": "包含",
			},
			OptionalValue: nil, // 用户输入填写
		},
		"telephone": {
			DBField: "hardware_summary_telephone",
			Display: "座机号",
			Operation: map[string]string{
				"eq":      "等于",
				"contain": "包含",
			},
			OptionalValue: nil, // 用户输入填写
		},
		"email": {
			DBField: "hardware_summary_email",
			Display: "邮箱",
			Operation: map[string]string{
				"eq":      "等于",
				"contain": "包含",
			},
			OptionalValue: nil, // 用户输入填写
		},
		"location": {
			DBField: "hardware_summary_location",
			Display: "物理位置",
			Operation: map[string]string{
				"eq":      "等于",
				"contain": "包含",
			},
			OptionalValue: nil, // 用户输入填写
		},
		"clientLoginUser": {
			DBField: "client_login_user",
			Display: "登录用户",
			Operation: map[string]string{
				"eq":      "等于",
				"contain": "包含",
			},
			OptionalValue: nil, // 用户输入填写
		},
		"memo": {
			DBField: "hardware_summary_memo",
			Display: "备注",
			Operation: map[string]string{
				"eq":      "等于",
				"contain": "包含",
			},
			OptionalValue: nil, // 用户输入填写
		},
		"deviceType": {
			DBField: "hardware_summary_device_type",
			Display: "设备类型",
			Operation: map[string]string{
				"eq":      "等于",
				"contain": "包含",
			},
			OptionalValue: nil, // 用户输入填写
		},
		"leakLibVersion": {
			DBField: "ext_leaklib_ver",
			Display: "补丁库版本",
			Operation: map[string]string{
				"eq":      "等于",
				"contain": "包含",
			},
			OptionalValue: nil, // 用户输入填写
		},
		"mainVersion": {
			DBField: "ext_main_ver",
			Display: "主程序版本",
			Operation: map[string]string{
				"eq":      "等于",
				"contain": "包含",
			},
			OptionalValue: nil, // 用户输入填写
		},
		"virusLibDate": {
			DBField: "ext_virus_lib_date",
			Display: "病毒库时间",
			Operation: map[string]string{
				"eq":      "等于",
				"contain": "包含",
			},
			OptionalValue: nil, // 用户输入填写
		},
		"deviceUse": {
			DBField: "hardware_summary_device_use",
			Display: "设备用途",
			Operation: map[string]string{
				"eq":      "等于",
				"contain": "包含",
			},
			OptionalValue: nil, // 用户输入填写
		},
	},

	// 扫描分数
	SCORE: {
		"score": {
			DBField: "exam_score",
			Display: "扫描分数",
			Operation: map[string]string{
				"gt":  "大于",
				"gte": "大于等于",
				"eq":  "等于",
				"lt":  "小于",
				"lte": "小于等于",
			},
			OptionalValue: nil, // 用户输入填写
		},
	},

	// 病毒分析
	VIRUS: {
		"virusName": {
			DBField: "vname",
			Display: "病毒名",
			Operation: map[string]string{
				"eq":      "等于",
				"contain": "包含",
			},
			OptionalValue: nil,
		},
		"md5": &OptionalFieldsConfig{
			DBField: "md5",
			Display: "MD5",
			Operation: map[string]string{
				"eq":      "等于",
				"contain": "包含",
			},
			OptionalValue: nil, // 用户输入填写
		},
		"virusCat": &OptionalFieldsConfig{
			DBField: "virus_cat",
			Display: "病毒类型",
			Operation: map[string]string{
				"not_include": "不包含",
				"include":     "包含",
			},
			OptionalValue: map[string]string{
				"0":    "未知",
				"1":    "木马",
				"2":    "感染文件",
				"3":    "高危程序",
				"4":    "文件篡改",
				"5":    "危险程序",
				"6":    "广告程序",
				"7":    "禁止启动",
				"8":    "驱动禁止启动",
				"9":    "被木马利用的程序",
				"10":   "文件缺失",
				"11":   "文件不存在的启动项",
				"12":   "启动项被劫持",
				"13":   "被劫持的系统文件",
				"14":   "路由器WAN口DNS被篡改",
				"15":   "数据库弱密码",
				"100":  "MBR病毒",
				"101":  "已经清除过的ROOTKIT",
				"102":  "未知或损坏的压缩包",
				"1000": "自动启动的非可执行文件",
				"2000": "关键目录里未知的可执行文件",
				"4000": "恶评插件",
				"5000": "被篡改的IE设置",
				"6000": "被篡改的系统设置",
				"9999": "深度扫描最大的风险类型值",
			},
			ValueTranslateMap: map[string]interface{}{
				"0":    0,
				"1":    1,
				"2":    2,
				"3":    3,
				"4":    4,
				"5":    5,
				"6":    6,
				"7":    7,
				"8":    8,
				"9":    9,
				"10":   10,
				"11":   11,
				"12":   12,
				"13":   13,
				"14":   14,
				"15":   15,
				"100":  100,
				"101":  101,
				"102":  102,
				"1000": 1000,
				"2000": 2000,
				"4000": 4000,
				"5000": 5000,
				"6000": 6000,
				"9999": 9999,
			},
		},
	},

	// 漏洞分析
	LEAK: {
		"patchName": {
			DBField: "leak_name",
			Display: "补丁名称",
			Operation: map[string]string{
				"eq":      "等于",
				"contain": "包含",
			},
			OptionalValue: nil, // 用户输入填写
		},
		"patchId": {
			DBField: "kbid",
			Display: "补丁号",
			Operation: map[string]string{
				"eq":      "等于",
				"contain": "包含",
			},
			OptionalValue: nil, // 用户输入填写
		},
		"patchLevel": {
			DBField: "leak_type",
			Display: "补丁级别",
			Operation: map[string]string{
				"include":     "包含",
				"not_include": "不包含",
			},
			OptionalValue: map[string]string{
				"1": "高危",
				"2": "软件安全更新",
				"3": "高危可选",
				"4": "其他",
			},
			ValueTranslateMap: map[string]interface{}{
				"1": 1,
				"2": 2,
				"3": 3,
				"4": 4,
			},
		},
	},

	// 告警事件
	ALERT: {
		"account": {
			DBField: "account",
			Display: "告警账号",
			Operation: map[string]string{
				"eq":      "等于",
				"contain": "包含",
			},
			OptionalValue: nil,
		},
		"alertType": {
			DBField: "type",
			Display: "事件类型",
			Operation: map[string]string{
				"include":     "包含",
				"not_include": "不包含",
			},
			OptionalValue: map[string]string{
				"netout":                "违规外联",
				"deviceout":             "接入外联设",
				"usbstorage":            "U盘使用告警",
				"peripherals":           "外设插入告警",
				"network":               "网络防护",
				"process":               "进程违规运行",
				"process_red":           "红名单进程检查",
				"desktop_configuration": "系统配置变更",
				"account_change":        "系统账号变更",
				"remotedesktop":         "远程受控",
				"process_regedit":       "使用注册表编辑器违规",
				"weak_password":         "弱口令告警",
				"cancle_pcoff":          "定时关机 取消关机",
				"network_flow":          "流量告警",
				"client_uninst":         "客户端卸载",
				"msconfig_change":       "启动项变更",
				"pc_onoff":              "开关机",
				"update_ipormac":        "ip、mac变更",
				/*
				   illegal_ssid_connection 非法ssid连接
				   update_systemtime 修改系统时间
				   password_attempt 密码错误
				   Multisystem 多操作系统
				   service_alarm 服务管理告警
				   error_protect_pwd 卸载密码错误
				   error_exit_pwd 退出密码错误
				   dualnet_connection 有线无线共用
				   internet_ip    互联网出口上报
				   ip_collision   终端ip冲突事件上报格式
				   new_accesss  新设备发现数据上报格式
				   ip_offline    设备下线数据上报格式
				   service_change  服务变更上报
				*/
			},
			ValueTranslateMap: map[string]interface{}{
				"netout":                "netout",
				"deviceout":             "deviceout",
				"usbstorage":            "usbstorage",
				"peripherals":           "peripherals",
				"network":               "network",
				"process":               "process",
				"process_red":           "process_red",
				"desktop_configuration": "desktop_configuration",
				/*
				   "account_change":        "系统账号变更",
				   "remotedesktop":         "远程受控",
				   "process_regedit":       "使用注册表编辑器违规",
				   "weak_password":         "弱口令告警",
				   "cancle_pcoff":          "定时关机 取消关机",
				   "network_flow":          "流量告警",
				   "client_uninst":         "客户端卸载",
				   "msconfig_change":       "启动项变更",
				   "pc_onoff":              "开关机",
				   "update_ipormac":        "ip、mac变更",
				   illegal_ssid_connection 非法ssid连接
				   update_systemtime 修改系统时间
				   password_attempt 密码错误
				   Multisystem 多操作系统
				   service_alarm 服务管理告警
				   error_protect_pwd 卸载密码错误
				   error_exit_pwd 退出密码错误
				   dualnet_connection 有线无线共用
				   internet_ip    互联网出口上报
				   ip_collision   终端ip冲突事件上报格式
				   new_accesss  新设备发现数据上报格式
				   ip_offline    设备下线数据上报格式
				   service_change  服务变更上报
				*/
			},
		},
	},

	// 审计
	AUDIT: {
		"alert_type": {
			DBField: "type",
			Display: "审计类型",
			Operation: map[string]string{
				"include":     "包含",
				"not_include": "不包含",
			},
			OptionalValue: map[string]string{
				"audit_software":   "软件使用日志",
				"audit_device":     "外设使用日志",
				"audit_power":      "开关机日志",
				"audit_account":    "系统账号日志",
				"audit_network":    "网络访问日志",
				"audit_safe_udisk": "安全U盘日志",
				"file_op":          "文件操作日志",
				"print_n":          "文件打印日志",
				"mail_n":           "邮件记录日志",
				"im_audit":         "IM审计日志",
			},
			ValueTranslateMap: map[string]interface{}{
				"audit_software":   "audit_software",
				"audit_device":     "audit_device",
				"audit_power":      "audit_power",
				"audit_account":    "audit_account",
				"audit_network":    "audit_network",
				"audit_safe_udisk": "audit_safe_udisk",
				"file_op":          "file_rp,file_usb,file_browser",
				"print_n":          "print_n",
				"mail_n":           "mail_n",
				"im_audit":         "im_audit",
			},
		},
	},
}

// 操作符映射表
var OpTranslateMap = map[string]string{
	"gt":          GT,
	"gte":         GTE,
	"eq":          EQ,
	"lt":          LT,
	"lte":         LTE,
	"include":     IN,    // 包含
	"not_include": NOTIN, // 不包含
	"contain":     LIKE,  // 类似
}

const (
	GT    = ">"
	GTE   = ">="
	EQ    = "="
	LT    = "<"
	LTE   = "<="
	IN    = "IN"
	NOTIN = "NOT IN"
	LIKE  = "LIKE"
)

func GetOptionalFieldsFilterConfig(businessCode string) (map[string]*OptionalFieldsConfig, error) {
	defaultConf := DefaultOptionalFieldsFilterMap

	configs, ok := BusinessOptionalFieldsFilterMap[businessCode]
	if !ok {
		logs.Errorf("获取查询字段选项信息失败. businessCode[%s]", businessCode)
		return defaultConf, nil
	}

	for k, v := range defaultConf {
		configs[k] = v
	}

	return configs, nil
}
