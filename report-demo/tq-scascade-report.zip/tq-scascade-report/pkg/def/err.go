package def

const (
	Err_InvalidParameter = 1001 //请求参数无效

	Err_CreateErr = 1100 //创建失败
	Err_UpdateErr = 1101 //更新失败
	Err_DeleteErr = 1102 //删除失败
	Err_GetErr    = 1103 //获取失败
	Err_ExportErr = 1104 //导出失败

	Err_AlreadyExist = 1108 // 名字已存在
)
