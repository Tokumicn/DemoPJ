package def

// 报表写入表配置

import "fmt"

const (

	// 扫描分数
	TableScoreCCID      = "scascade_score_ccid"
	TableScoreSummarize = "scascade_score_summarize"

	// 病毒分析
	TableVirusSummarize = "scascade_virus_summarize"
	TableVirusCCID      = "scascade_virus_ccid"
	TableVirusClient    = "scascade_virus_client"
	TableVirusName      = "scascade_virus_name"

	// 漏洞分析
	TableLeakSummarize = "scascade_leak_summarize"
	TableLeakCCID      = "scascade_leak_ccid"
	TableLeakClient    = "scascade_leak_client"
	TableLeakPatch     = "scascade_leak_patch"

	// 告警事件
	TableAlertSummarize = "scascade_alert_summarize"
)

func GetTableNameByType(business, reportType string) (string, error) {
	switch business {
	case SCORE: // 扫描分数
		if reportType == SUMMARIZE {
			return TableScoreSummarize, nil
		} else if reportType == CCID {
			return TableScoreCCID, nil
		}

	case VIRUS: // 病毒分析
		if reportType == SUMMARIZE {
			return TableVirusSummarize, nil
		} else if reportType == CCID {
			return TableVirusCCID, nil
		} else if reportType == CLIENT {
			return TableVirusClient, nil
		} else if reportType == VIRUS {
			return TableVirusName, nil
		}

	case LEAK: // 漏洞分析
		if reportType == SUMMARIZE {
			return TableLeakSummarize, nil
		} else if reportType == CCID {
			return TableLeakCCID, nil
		} else if reportType == CLIENT {
			return TableLeakClient, nil
		} else if reportType == PATCHES {
			return TableLeakPatch, nil
		}

	case ALERT: // 告警事件
		if reportType == SUMMARIZE {
			return TableAlertSummarize, nil
		}

	//case ASSET: // 资产
	//case AUDIT: // 审计

	default:
		return "", fmt.Errorf("business[%s] reportType[%s] parameter error.", business, reportType)
	}

	return "", fmt.Errorf("business[%s] reportType[%s] parameter error.", business, reportType)
}
