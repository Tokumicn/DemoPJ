package def

import "os"

const (
	CUSTOM_COLS_PATH = `.` + string(os.PathSeparator) + `config` + string(os.PathSeparator) + `custom_cols.json`
)
