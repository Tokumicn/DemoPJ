package def

// 定时任务生成时间类型
const (
	NOW     = "now" // 立即生成
	DAILY   = "daily"
	WEEKLY  = "weekly"
	MONTHLY = "monthly"
)

// 查询时间范围类型
const (
	PastTenDayRange = "day"     // 最近十天
	LastWeekRange   = "week"    // 上周
	MonthRange      = "month"   // 按月
	QuarterRange    = "quarter" // 按季度
	YearRange       = "year"    // 按年
	CustomRange     = "custom"  // 指定时间范围
)

// 趋势图时间刻度
const (
	DayScale     = "day" // 最近十天
	WeekScale    = "week"
	MonthScale   = "month"   // 按年统计-按月展示
	QuarterScale = "quarter" // 按季度 -- 暂时不用
)

var TimeScaleDic = map[string]string{
	DayScale:     DayScale,
	WeekScale:    WeekScale,
	MonthScale:   MonthScale,
	QuarterScale: QuarterScale,
}

var CronTypeDic = map[string]int{
	NOW:     51,
	DAILY:   52,
	WEEKLY:  53,
	MONTHLY: 54,
}

const (
	YYYYMMDDHHSSmm = "2006-01-02 15:04:05"
	YYYYMMDD       = "2006-01-02"
)
