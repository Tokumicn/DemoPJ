package def

// 业务类型
const (
	SCORE = "Score"
	VIRUS = "Virus"
	LEAK  = "Leak"
	ALERT = "Alert"
	ASSET = "Asset"
	AUDIT = "Audit"
)

// 统计报表类型
const (
	SUMMARIZE         = "Summarize"
	CCID              = "CCId"
	CLIENT            = "Client"
	PATCHES           = "Patch"
	BreakRuleCOUNT    = "BreakRuleCount"
	BreakRuleDURATION = "BreakRuleDuration"
)

// 报表结果类型 ReportCode
const (
	// 扫描分数
	SCORE_SUMMARIZE              = "ScoreSum"
	SCORE_CCID                   = "ScoreCCID"
	SCORE_SUMMARIZE_TREND        = "ScoreSumTrend"
	SCORE_SUMMARIZE_CLIENT_TOP10 = "ScoreSumClientTop10"
	SCORE_SUMMARIZE_CCID_TOP10   = "ScoreSumCCIDTop10"

	// 病毒分析
	VIRUS_SUMMARIZE                   = "VirusSum"
	VIRUS_CCID                        = "VirusCCID"                // 按控制中心统计
	VIRUS_CLIENT                      = "VirusClient"              // 按终端统计
	VIRUS_NAME                        = "VirusName"                // 按病毒统计
	VIRUS_SUMMARIZE_TREND_NAME        = "VirusSumTrendName"        // 汇总统计--趋势图--病毒名
	VIRUS_SUMMARIZE_TREND_KILLCOUNT   = "VirusSumTrendKillCount"   // 汇总统计--趋势图--查杀次数
	VIRUS_SUMMARIZE_TREND_ClientCOUNT = "VirusSumTrendClientCount" // 汇总统计--趋势图--查杀终端数
	VIRUS_SUMMARIZE_CAT_PER           = "VirusSummarizeCatPer"     // 汇总统计--病毒种类占比
	VIRUS_SUMMARIZE_OPTION_PER        = "VirusSummarizeOptionPer"  // 汇总统计--病毒处理占比
	VIRUS_SUMMARIZE_TASK_PER          = "VirusSummarizeTaskPer"    // 汇总统计--触发方式占比
	VIRUS_SUMMARIZE_CLIENT_TOP10      = "VirusSumClientTop10"      // 汇总统计--感染病毒最多[终端] TOP 10
	VIRUS_SUMMARIZE_CCID_TOP10        = "VirusSumCCIDTop10"        // 汇总统计--感染最多[控制中心] TOP 10
	VIRUS_SUMMARIZE_VNAME_TOP10       = "VirusSumVNameTop10"       // 汇总统计--感染[病毒] TOP 10

	// 漏洞分析
	LEAK_SUMMARIZE              = "LeakSum"
	LEAK_CCID                   = "LeakCCID"                // 按控制中心统计
	LEAK_CLIENT                 = "LeakClient"              // 按终端统计
	LEAK_PATCH                  = "LeakPatch"               // 按漏洞补丁统计
	LEAK_SUMMARIZE_TREND        = "LeakSumTrend"            // 汇总统计--趋势图--发现漏洞补丁、修复漏洞补丁、忽略漏洞补丁
	LEAK_SUMMARIZE_FAILURE_PER  = "LeakSummarizeFailurePer" // 汇总统计--漏洞修复失败占比
	LEAK_SUMMARIZE_LEVEL_PER    = "LeakSummarizeLevelPer"   // 汇总统计--已修复漏洞级别占比
	LEAK_SUMMARIZE_CLIENT_TOP10 = "LeakSumClientTop10"      // 汇总统计--安装漏洞补丁次数最多[终端] TOP 10
	LEAK_SUMMARIZE_CCID_TOP10   = "LeakSumCCIDTop10"        // 汇总统计--安装漏洞补丁次数最多[控制中心] TOP 10
	LEAK_SUMMARIZE_PATCH_TOP10  = "LeakSumPatchTop10"       // 汇总统计--安装漏洞补丁次数最多[补丁] TOP 10

	// 告警事件
	ALERT_SUMMARIZE            = "AlertSum"
	ALERT_SUMMARIZE_TREND      = "AlertSummarizeTrend"     // 汇总统计--趋势图--告警次数
	ALERT_SUMMARIZE_Type_PER   = "AlertSummarizeTypePer"   // 汇总统计--告警类型占比
	ALERT_SUMMARIZE_COUNTS_PER = "AlertSummarizeCountsPer" // 汇总统计--告警次数占比

	// 日志详情业务唯一标识Code
	LOG_SCORE_CODE = "LOG_Score_CODE"
	LOG_VIRUS_CODE = "LOG_Virus_CODE"
	LOG_LEAK_CODE  = "LOG_Leak_CODE"
	LOG_ALERT_CODE = "LOG_Alert_CODE"
	LOG_ASSET_CODE = "LOG_Asset_CODE"
	LOG_AUDIT_CODE = "LOG_Audit_CODE"
)

var GlobalDic = map[int]string{
	11: SCORE,
	12: VIRUS,
	13: LEAK,
	14: ALERT,
	15: ASSET,
	16: AUDIT,

	31: SUMMARIZE,
	32: CCID,
	33: CLIENT,
	34: VIRUS,
	35: PATCHES,

	51: NOW,
	52: DAILY,
	53: WEEKLY,
	54: MONTHLY,

	// 扫描分数
	1001: SCORE_CCID,
	1002: SCORE_SUMMARIZE_TREND,
	1003: SCORE_SUMMARIZE_CLIENT_TOP10,
	1004: SCORE_SUMMARIZE_CCID_TOP10,

	// 病毒分析
	2001: VIRUS_CCID,
	2002: VIRUS_CLIENT,
	2003: VIRUS_NAME,
	2004: VIRUS_SUMMARIZE_TREND_NAME,
	2005: VIRUS_SUMMARIZE_TREND_KILLCOUNT,
	2006: VIRUS_SUMMARIZE_TREND_ClientCOUNT,
	2007: VIRUS_SUMMARIZE_CAT_PER,
	2008: VIRUS_SUMMARIZE_OPTION_PER,
	2009: VIRUS_SUMMARIZE_TASK_PER,
	2010: VIRUS_SUMMARIZE_CLIENT_TOP10,
	2011: VIRUS_SUMMARIZE_CCID_TOP10,
	2012: VIRUS_SUMMARIZE_VNAME_TOP10,

	// 漏洞分析
	3001: LEAK_CCID,
	3002: LEAK_CLIENT,
	3003: LEAK_PATCH,
	3004: LEAK_SUMMARIZE_TREND,
	3005: LEAK_SUMMARIZE_FAILURE_PER,
	3006: LEAK_SUMMARIZE_LEVEL_PER,
	3007: LEAK_SUMMARIZE_CLIENT_TOP10,
	3008: LEAK_SUMMARIZE_CCID_TOP10,
	3009: LEAK_SUMMARIZE_PATCH_TOP10,

	// 告警事件
	4001: ALERT_SUMMARIZE_TREND,
	4002: ALERT_SUMMARIZE_Type_PER,
	4003: ALERT_SUMMARIZE_COUNTS_PER,
}

// 所属业务
var BusinessDic = map[string]int{
	SCORE: 11,
	VIRUS: 12,
	LEAK:  13,
	ALERT: 14,
	ASSET: 15,
	AUDIT: 16,
}

// ReportType
var ReportTypeDic = map[string]int{
	SUMMARIZE:         31, // 汇总统计
	CCID:              32, // 按控制中心统计
	CLIENT:            33, // 按终端统计
	VIRUS:             34, // 按病毒统计
	PATCHES:           35, // 按漏洞补丁统计
	BreakRuleCOUNT:    36, // 违规次数统计
	BreakRuleDURATION: 37, // 违规时长统计
}

var ReportResultTypeDic = map[string]int{
	// 扫描分数
	SCORE_CCID:                   1001,
	SCORE_SUMMARIZE_TREND:        1002,
	SCORE_SUMMARIZE_CLIENT_TOP10: 1003,
	SCORE_SUMMARIZE_CCID_TOP10:   1004,

	// 病毒分析
	VIRUS_CCID:                        2001,
	VIRUS_CLIENT:                      2002,
	VIRUS_NAME:                        2003,
	VIRUS_SUMMARIZE_TREND_NAME:        2004,
	VIRUS_SUMMARIZE_TREND_KILLCOUNT:   2005,
	VIRUS_SUMMARIZE_TREND_ClientCOUNT: 2006,
	VIRUS_SUMMARIZE_CAT_PER:           2007,
	VIRUS_SUMMARIZE_OPTION_PER:        2008,
	VIRUS_SUMMARIZE_TASK_PER:          2009,
	VIRUS_SUMMARIZE_CLIENT_TOP10:      2010,
	VIRUS_SUMMARIZE_CCID_TOP10:        2011,
	VIRUS_SUMMARIZE_VNAME_TOP10:       2012,

	// 漏洞分析
	LEAK_CCID:                   3001,
	LEAK_CLIENT:                 3002,
	LEAK_PATCH:                  3003,
	LEAK_SUMMARIZE_TREND:        3004,
	LEAK_SUMMARIZE_FAILURE_PER:  3005,
	LEAK_SUMMARIZE_LEVEL_PER:    3006,
	LEAK_SUMMARIZE_CLIENT_TOP10: 3007,
	LEAK_SUMMARIZE_CCID_TOP10:   3008,
	LEAK_SUMMARIZE_PATCH_TOP10:  3009,

	// 告警事件
	ALERT_SUMMARIZE_TREND:      4001,
	ALERT_SUMMARIZE_Type_PER:   4002,
	ALERT_SUMMARIZE_COUNTS_PER: 4003,
}

func ReportTypesContain(reportTypes []string, findType string) bool {
	for _, typ := range reportTypes {
		if typ == findType {
			return true
		}
	}

	return false
}
